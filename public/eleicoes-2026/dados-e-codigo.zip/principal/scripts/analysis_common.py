"""Verified inputs and bounded reads shared by the TSE analysis jobs."""
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

import boto3
from botocore.config import Config
from s3_archive import S3RangeReader

ROOT = Path(__file__).resolve().parents[1]
BUCKET = "tse-research"
PREFIX = "tse/2026-10-29"


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(8 * 1024**2), b""):
            h.update(block)
    return h.hexdigest()


def atomic_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    tmp.replace(path)


def inputs():
    audit = json.loads((ROOT / "reports/final-acquisition-audit.json").read_text())
    if audit["status"] != "passed_with_documented_gaps" or audit["object_issues"] or audit["collection_issues"]:
        raise RuntimeError("The final acquisition audit has not passed")
    records = ROOT / audit["records_path"]
    if digest(records) != audit["records_sha256"]:
        raise RuntimeError("The input audit records changed")
    return [json.loads(line) for line in records.open()]


def s3_client():
    return boto3.Session(profile_name="tse-research", region_name="auto").client(
        "s3", endpoint_url="https://t3.storage.dev",
        config=Config(retries={"max_attempts": 6, "mode": "standard"},
                      connect_timeout=20, read_timeout=90, max_pool_connections=8))


def require_disk(minimum=8 * 1024**3):
    if shutil.disk_usage(ROOT).free < minimum:
        raise RuntimeError("Local free space below analysis reserve; originals must be preserved")


@contextmanager
def archive(row, prefer_local=False, block_size=4 * 1024**2):
    """Use an existing, hash-matched local copy or an immutable remote range reader."""
    require_disk()
    local = ROOT / row["path"]
    if prefer_local and local.is_file():
        if local.stat().st_size != row["bytes"] or digest(local) != row["hashes"]["sha256"]:
            raise ValueError(f"Local input differs from audited input: {row['path']}")
        with zipfile.ZipFile(local) as z:
            yield z, {"mode": "existing_local_hash_matched", "path": row["path"]}
    else:
        with S3RangeReader(s3_client(), BUCKET, PREFIX + "/" + row["path"],
                           expected_size=row["bytes"], expected_etag=row["etag"],
                           block_size=block_size, cache_blocks=4) as reader:
            with zipfile.ZipFile(reader) as z:
                stats = {"mode": "s3_range", "path": row["path"]}
                yield z, stats
                stats.update(requests=reader.requests, bytes_fetched=reader.bytes_fetched)


def code_fingerprint(names):
    return {name: digest(ROOT / "scripts" / name) for name in names}
