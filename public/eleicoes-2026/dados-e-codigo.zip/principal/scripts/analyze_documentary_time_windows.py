"""Align observed completion minutes with documentary markers, not exposure."""
import json
import time

import pandas as pd

from analysis_common import ROOT, atomic_json, digest, now


def main():
    report = ROOT / 'reports/temporal-population-state.json'
    source = json.loads(report.read_text())
    p = ROOT / source['output_folder'] / 'minute-histograms.csv'
    if digest(p) != next(x['sha256'] for x in source['outputs'] if x['path'].endswith('minute-histograms.csv')):
        raise ValueError('Input histogram changed')
    h = pd.read_csv(p)
    h = h[(h.year == 2026) & (h['round'] == 2)]
    out = ROOT / 'analysis/derived/documentary-time-windows-v1' / str(time.time_ns())
    out.mkdir(parents=True, exist_ok=False)
    markers = [
        ('17:32:59', 32, 59, 'Carimbo RFC3161 embutido na primeira decisão; cadeia não validada'),
        ('17:49', 49, None, 'Minuto de assinatura da Circular 354/2026 segundo o TRE-AM'),
        ('18:05:21', 65, 21, 'Carimbo RFC3161 embutido na decisão de esclarecimento; cadeia não validada')]
    rows = []
    for uf, g in [('BR-domestic', h)] + list(h.groupby('uf')):
        for label, minute, second, meaning in markers:
            following = int(g.loc[g.minutes_after_ordinary_deadline > minute, 'completions'].sum())
            same = int(g.loc[g.minutes_after_ordinary_deadline == minute, 'completions'].sum())
            rows.append({'year': 2026, 'round': 2, 'territory': uf, 'marker_brasilia': label,
                         'documentary_meaning': meaning, 'completions_strictly_after_lower': following,
                         'completions_strictly_after_upper': following if second == 59 else following + same,
                         'events_in_unresolved_marker_minute': 0 if second == 59 else same,
                         'exact_at_available_precision': second == 59,
                         'is_section_exposure_time': False})
    pd.DataFrame(rows).to_csv(out / 'documentary-time-windows.csv', index=False)
    result = {'at': now(), 'status': 'descriptive_marker_alignment_not_treatment_assignment',
              'output_folder': str(out.relative_to(ROOT)), 'national': [x for x in rows if x['territory'] == 'BR-domestic'],
              'inputs': [{'path': str(report.relative_to(ROOT)), 'sha256': digest(report)},
                         {'path': str(p.relative_to(ROOT)), 'sha256': digest(p)}],
              'code_sha256': digest(ROOT / 'scripts/analyze_documentary_time_windows.py'),
              'limitations': ['Documentary markers do not establish actual notification or implementation by section.',
                  'Bounds bracket the unresolved seconds within one minute; they are deterministic measurement bounds, not confidence intervals.',
                  'They use recorded municipal-normalized clocks and retain the documented coverage and clock limitations.',
                  'The number of causal additional voters after any marker is not observed.']}
    atomic_json(out / 'analysis.json', result)
    atomic_json(ROOT / 'reports/documentary-time-window-state.json', result)
    print(json.dumps(result['national'], ensure_ascii=False))


if __name__ == '__main__':
    main()
