"""Descriptive intervals between completed voting procedures, not voter waiting times."""
import argparse,json,time
from collections import defaultdict
from pathlib import Path
import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from analysis_common import ROOT,digest,atomic_json,now


def qhist(h,q):
 n=int(h.sum())
 if not n:return None
 return int(np.searchsorted(np.cumsum(h),max(1,int(np.ceil(q*n)))))

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--years',default='2026');a=ap.parse_args();years={int(x) for x in a.years.split(',')}
 out=ROOT/'analysis/derived/intercompletion-v1'/str(time.time_ns());out.mkdir(parents=True,exist_ok=False)
 hist=defaultdict(lambda:np.zeros(902,dtype='int64'));rows=[];sources=[];coverage=[]
 for year in sorted(years):
  offices=pd.read_parquet(ROOT/f'analysis/derived/sections-v2/{year}/section-office.parquet',columns=['round','uf','municipality','zone','section','office'])
  gov={tuple(x) for x in offices[offices.office.eq(3)][['round','uf','municipality','zone','section']].itertuples(index=False,name=None)}
  root=ROOT/('analysis/derived/native-logs-v1' if year==2026 else 'analysis/derived/native-logs-history-v2')/str(year)
  for mp in sorted((ROOT/f'analysis/derived/temporal-reviewed-v1/{year}').glob('*/complete.json')):
   meta=json.loads(mp.read_text());uf=meta['uf'];turn=meta['round']
   if uf=='ZZ' or not meta.get('outputs'):continue
   f=pd.read_parquet(mp.parent/'sections.parquet');good=f[f.reviewed_strict_time_eligible & ~f.operational_context_contaminated]
   lookup=good.set_index(['municipality','zone','section'])
   sources.append({'path':str(mp.relative_to(ROOT)),'sha256':digest(mp)})
   npth=root/f'bu_imgbu_logjez_rdv_vscmr_{year}_{turn}t_{uf}'/'complete.json';native=json.loads(npth.read_text())
   sources.append({'path':str(npth.relative_to(ROOT)),'sha256':digest(npth)})
   target={2026:{1:'04/10/2026',2:'25/10/2026'},2022:{1:'02/10/2022',2:'30/10/2022'},2024:{1:'06/10/2024',2:'27/10/2024'}}[year][turn]
   seen=set();n=0
   for b in native['batches']:
    p=ROOT/b['path']
    if digest(p)!=b['sha256']:raise ValueError('Native batch changed')
    for r in pq.read_table(p,columns=['event_date','municipality','zone','section','computed_seconds']).to_pylist():
     if r['event_date']!=target:continue
     k=tuple(r[x] for x in ['municipality','zone','section'])
     if k not in lookup.index:continue
     if k in seen:raise ValueError('Duplicate section date')
     seen.add(k);s=lookup.loc[k];v=np.sort(np.asarray(r['computed_seconds'],dtype='int64'))
     if len(v)!=s.attendance:raise ValueError('Count does not reconcile')
     gaps=np.diff(v);n+=1
     setting=('municipal' if year==2024 else 'general_first_turn' if turn==1 else 'president_and_governor' if (turn,uf,*k) in gov else 'president_only')
     hist[(year,turn,uf,setting)]+=np.bincount(np.minimum(gaps,901),minlength=902)
     row={'year':year,'round':turn,'uf':uf,'municipality':k[0],'zone':k[1],'section':k[2],
          'setting':setting,'attendance':int(s.attendance),'intervals':len(gaps),'zero_second_intervals':int((gaps==0).sum()),
          'interval_seconds_sum':int(gaps.sum()),'active_span_seconds':int(v[-1]-v[0]) if len(v)>1 else None,
          'median_seconds':float(np.median(gaps)) if len(gaps) else None,'p90_seconds':float(np.percentile(gaps,90)) if len(gaps) else None,
          'median_gap_at_most_120_seconds':float(np.median(gaps[gaps<=120])) if (gaps<=120).any() else None,
          'median_gap_at_most_300_seconds':float(np.median(gaps[gaps<=300])) if (gaps<=300).any() else None}
     rows.append(row)
   if seen!=set(lookup.index):raise ValueError('Qualified sections not completely found')
   coverage.append({'year':year,'round':turn,'uf':uf,'all_sections':len(f),'included_sections':n,
                    'excluded_sections':len(f)-n,'included_attendance':int(good.attendance.sum()),'all_attendance':int(f.attendance.sum())})
   atomic_json(out/'progress.json',{'at':now(),'completed_archives':len(coverage),'completed_sections':len(rows),'last':[year,turn,uf]})
   print(json.dumps({'at':now(),'archive':[year,turn,uf],'sections':n}),flush=True)
 table=pd.DataFrame(rows);table.to_parquet(out/'section-intervals.parquet',index=False,compression='zstd')
 pd.DataFrame(coverage).to_csv(out/'coverage.csv',index=False)
 hrows=[];national=defaultdict(lambda:np.zeros(902,dtype='int64'))
 for (y,t,u,s),h in hist.items():
  national[(y,t,s)]+=h
  for i,c in enumerate(h):
   if c:hrows.append({'year':y,'round':t,'uf':u,'setting':s,'gap_seconds':i,'is_over900_bin':i==901,'intervals':int(c)})
 pd.DataFrame(hrows).to_parquet(out/'interval-histograms.parquet',index=False,compression='zstd')
 summaries=[]
 for (y,t,s),h in national.items():
  g=table[(table.year==y)&(table['round']==t)&(table.setting==s)]
  summaries.append({'year':y,'round':t,'setting':s,'sections':len(g),'attendance':int(g.attendance.sum()),'intervals':int(h.sum()),
       'median_interval_seconds':qhist(h,.5),'p90_interval_seconds':qhist(h,.9),'p95_interval_seconds':qhist(h,.95),
       'median_conditional_gap_le120':qhist(h[:121],.5),'median_conditional_gap_le300':qhist(h[:301],.5),
       'intervals_over900_seconds':int(h[901]),'zero_second_intervals':int(h[0]),
       'mean_interval_seconds':float(g.interval_seconds_sum.sum()/g.intervals.sum()),'mean_section_median_seconds':float(g.median_seconds.mean())})
 pd.DataFrame(summaries).to_csv(out/'national-intervals.csv',index=False)
 # Prespecified key match, but this operational comparison remains descriptive.
 pair=[]
 for year,g in table.groupby('year'):
  keys=['uf','municipality','zone','section'];l=g[g['round']==1];r=g[g['round']==2]
  p=l.merge(r,on=keys,suffixes=('_a','_b'),validate='one_to_one')
  if len(p):
   pair.append({'year':int(year),'paired_sections':len(p),'first_turn_only_in_qualified_set':len(l)-len(p),'second_turn_only_in_qualified_set':len(r)-len(p),
                'mean_section_change_median_seconds':float((p.median_seconds_b-p.median_seconds_a).mean()),
                'median_section_change_median_seconds':float((p.median_seconds_b-p.median_seconds_a).median())})
 pd.DataFrame(pair).to_csv(out/'paired-interval-change.csv',index=False)
 result={'at':now(),'status':'descriptive_intercompletion_intervals','output_folder':str(out.relative_to(ROOT)),'national':summaries,
  'input_manifests':sources,'code_sha256':digest(ROOT/'scripts/analyze_intercompletion.py'),
  'limitations':['Intervals between completed procedures combine service time, arrivals, idle time, interruptions and logging latency. They are not individual waiting times or isolated hardware speed.',
   'Only same-day, count-reconciled, clock/parse-clean sections without mixed-section operational context are included; coverage and matching losses are explicit.',
   'Zero-second intervals are retained. Histogram bin901 means greater than900seconds; quantiles landing in that bin are censored.',
   'The conditional short-gap medians are sensitivity summaries, not validated queue-presence indicators. No causal effect is estimated.',
   'Different offices on the ballot, municipalities, turnout and elections can change distributions. Descriptive paired changes do not isolate the judicial extension.'],
  'outputs':[{'path':str(p.relative_to(ROOT)),'sha256':digest(p)} for p in out.iterdir()]}
 atomic_json(out/'analysis.json',result);atomic_json(ROOT/'reports/intercompletion-state.json',result)
 print(json.dumps(summaries),flush=True)
if __name__=='__main__':main()
