"""Section-sharp conditional ballot-removal bounds, never candidate-time links."""
import json
import time

import duckdb
import numpy as np
import pandas as pd

from analysis_common import ROOT, atomic_json, digest, now
from derive_temporal_features import suffix


def cap_for_scenario(g, kind, shift=0):
    attendance=g.attendance.astype('int64').to_numpy()
    observed=g['reviewed_after_ordinary_'+suffix(-shift)].fillna(0).to_numpy(float)
    if shift==0:
        observed += g.reviewed_at_ordinary_deadline.fillna(0).to_numpy(float)
    if kind=='recorded_plus_gaps':
        cap=observed+g.reviewed_gap_if_no_spurious.fillna(g.attendance).to_numpy(float)
        unresolved=~g.context_known.fillna(False) | g.reviewed_observed_completions.gt(g.primary_attendance)
    elif kind=='strict_other_sections_all':
        cap=observed
        unresolved=~g.reviewed_strict_time_eligible.fillna(False)
    elif kind=='startup_allowed_other_sections_all':
        cap=observed
        unresolved=~g.reviewed_startup_allowed_time_eligible.fillna(False)
    else: raise ValueError(kind)
    cap=np.where(unresolved.to_numpy(),attendance,cap)
    # All overseas ballots are permitted in this deliberately conservative
    # presidential scenario; no overseas clock or exposure is assumed known.
    cap=np.where(g.uf.eq('ZZ').to_numpy(),attendance,cap)
    return np.minimum(attendance,np.maximum(0,cap)).astype('int64')


def main():
    out=ROOT/'analysis/derived/margin-scenarios-v1'/str(time.time_ns());out.mkdir(parents=True,exist_ok=False)
    files,sources=[],[]
    for mp in sorted((ROOT/'analysis/derived/bweb-v1/2026').glob('bweb_2t_*/complete.json')):
        m=json.loads(mp.read_text());sources.append({'path':str(mp.relative_to(ROOT)),'sha256':digest(mp)})
        for r in m['outputs']:
            p=ROOT/r['path']
            if digest(p)!=r['sha256']:raise ValueError('BWeb candidate input changed')
            files.append(str(p))
    if len(sources)!=28:raise ValueError('Need all28second-turn BWeb archives')
    con=duckdb.connect();con.execute("SET threads=2");con.execute("SET memory_limit='2GB'")
    con.from_parquet(files,union_by_name=True).create_view('raw')
    candidates=con.sql('''SELECT "SG_UF" AS uf,cast(CD_MUNICIPIO AS INTEGER) municipality,
        cast(NR_ZONA AS INTEGER) zone,cast(NR_SECAO AS INTEGER) section,
        cast(CD_CARGO_PERGUNTA AS INTEGER) office,cast(NR_VOTAVEL AS INTEGER) candidate,
        min(NM_VOTAVEL) candidate_name,sum(cast(QT_VOTOS AS BIGINT)) votes
        FROM raw WHERE CD_TIPO_VOTAVEL='1' AND NR_TURNO='2'
        GROUP BY uf,municipality,zone,section,office,candidate''').df()
    keys=['uf','municipality','zone','section','office']
    sections=pd.read_parquet(ROOT/'analysis/derived/sections-v2/2026/section-office.parquet')
    sections=sections[(sections['round']==2)&sections.office.isin([1,3])][keys+['attendance','nominal_votes','blank_votes','null_votes']]
    measures=[]
    for mp in sorted((ROOT/'analysis/derived/temporal-reviewed-v1/2026').glob('2t-*/complete.json')):
        m=json.loads(mp.read_text());p=mp.parent/'sections.parquet'
        if digest(p)!=next(x['sha256'] for x in m['outputs'] if x['path'].endswith('sections.parquet')):raise ValueError('Temporal input changed')
        cols=keys[:-1]+['attendance','reviewed_after_ordinary_p0','reviewed_after_ordinary_m60','reviewed_after_ordinary_m300',
             'reviewed_after_ordinary_m900','reviewed_at_ordinary_deadline','reviewed_gap_if_no_spurious','context_known',
             'reviewed_observed_completions','reviewed_strict_time_eligible','reviewed_startup_allowed_time_eligible']
        measures.append(pd.read_parquet(p,columns=cols).rename(columns={'attendance':'primary_attendance'}))
        sources.append({'path':str(mp.relative_to(ROOT)),'sha256':digest(mp)})
    if len(measures)!=28:raise ValueError('Need all28reviewed second-turn archives')
    temporal=pd.concat(measures,ignore_index=True)
    base=sections.merge(temporal,on=keys[:-1],how='left',validate='many_to_one')
    if base.primary_attendance.isna().any():raise ValueError('Office section lacks primary temporal row')
    base['race']=np.where(base.office==1,'BR-PRESIDENTE',base.uf+'-GOVERNADOR')
    candidates['race']=np.where(candidates.office==1,'BR-PRESIDENTE',candidates.uf+'-GOVERNADOR')
    results,section_outputs,race_totals=[],[],[]
    for race,g in base.groupby('race'):
        c=candidates[candidates.race==race]
        totals=c.groupby(['candidate','candidate_name']).votes.sum().sort_values(ascending=False)
        if len(totals)!=2:raise ValueError('Expected exactly two reconciled second-turn candidates')
        (winner,wname),(runner,rname)=totals.index
        pivot=c.pivot_table(index=keys,columns='candidate',values='votes',aggfunc='sum',fill_value=0).reset_index()
        g=g.merge(pivot[keys+[winner,runner]],on=keys,how='left',validate='one_to_one').fillna({winner:0,runner:0})
        a=g[winner].astype('int64').to_numpy();b=g[runner].astype('int64').to_numpy()
        other=g.attendance.to_numpy('int64')-a-b
        if (other<0).any() or (a+b!=g.nominal_votes.to_numpy()).any():raise ValueError('Candidate/attendance reconciliation failed')
        margin=int(a.sum()-b.sum())
        race_totals.append({'race':race,'winner':wname,'runner_up':rname,'winner_votes':int(a.sum()),'runner_up_votes':int(b.sum()),
                            'observed_margin':margin,'sections':len(g),'attendance':int(g.attendance.sum()),
                            'primary_office_attendance_differs':int(g.attendance.ne(g.primary_attendance).sum())})
        for kind in ['recorded_plus_gaps','strict_other_sections_all','startup_allowed_other_sections_all']:
            for shift in [0,60,300,900]:
                cap=cap_for_scenario(g,kind,shift)
                low=-np.minimum(a,cap);high=np.minimum(b,cap)
                if (cap>g.attendance.to_numpy()).any():raise ValueError('Impossible ballot cap')
                row={'race':race,'scenario':kind,'cutoff_shift_earlier_seconds':shift,
                     'deadline_boundary':'inclusive_exact17h' if shift==0 else 'strict_after_shifted_cutoff',
                     'overseas_policy':'all_overseas_attendance_allowed','winner':wname,'runner_up':rname,
                     'observed_margin':margin,'possible_added_voters_cap':int(cap.sum()),
                     'maximum_adverse_margin_change':int((-low).sum()),'maximum_favorable_margin_change':int(high.sum()),
                     'minimum_counterfactual_margin':margin+int(low.sum()),'maximum_counterfactual_margin':margin+int(high.sum()),
                     'reversal_ruled_out_under_scenario':margin+int(low.sum())>0,
                     'sections':len(g),'sections_with_positive_cap':int((cap>0).sum())}
                results.append(row)
                if shift==0:
                    x=g[keys].copy();x['race']=race;x['scenario']=kind;x['winner_votes']=a;x['runner_up_votes']=b
                    x['other_outcomes']=other;x['attendance']=g.attendance.to_numpy();x['additional_voter_cap']=cap
                    x['minimum_margin_change']=low;x['maximum_margin_change']=high;section_outputs.append(x)
    pd.DataFrame(results).to_csv(out/'conditional-margin-bounds.csv',index=False)
    pd.DataFrame(race_totals).to_csv(out/'reconciled-race-margins.csv',index=False)
    pd.concat(section_outputs,ignore_index=True).to_parquet(out/'section-bound-components.parquet',index=False,compression='zstd')
    result={'at':now(),'status':'conditional_finite_population_bounds','output_folder':str(out.relative_to(ROOT)),
        'race_totals':race_totals,'input_manifests':sources,'code_sha256':digest(ROOT/'scripts/analyze_margin_scenarios.py'),
        'assumptions':['The counterfactual removes0toK additional participants caused by the extension; ordinary preexisting queue rights remain.',
            'No predeadline anticipation effect, suppression of other participants, changes in other voters choices or other intervention mechanism is included.',
            'Recorded-time and clock/cutoff scenarios are conditional, not empirically certified clock-error bounds. Missing/unresolved cases are expanded as described.',
            'All overseas ballots are included in the conservative presidential cap, without claiming they were exposed.',
            'The primary-office completed-voting event can only upper-bound office-specific additional ballots; caps are limited to that office attendance.',
            'Final candidate counts constrain feasible extrema only; no individual preference or candidate-by-time assignment is inferred.',
            'One additional/removed ballot changes the two-candidate margin by at most1. A2-vote swing is a different switching mechanism.'],
        'not_identified':'Point causal effect, preferences of late voters, and outcomes under unrestricted behavioral effects.',
        'outputs':[{'path':str(p.relative_to(ROOT)),'sha256':digest(p),'bytes':p.stat().st_size} for p in out.iterdir()]}
    atomic_json(out/'analysis.json',result);atomic_json(ROOT/'reports/margin-scenario-state.json',result)
    print(json.dumps({'folder':result['output_folder'],'races':len(race_totals),'scenarios':len(results),'base_scenarios':[r for r in results if r['cutoff_shift_earlier_seconds']==0]}),flush=True)


if __name__=='__main__':main()
