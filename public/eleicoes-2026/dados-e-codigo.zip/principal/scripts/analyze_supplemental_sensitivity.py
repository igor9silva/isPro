"""Whole-sequence historical sensitivity, with no change to primary measurements.

Only a zero-completion reviewed primary can receive retained target events.
Positive primary sequences are never unioned by timestamps or count-fitting.
"""
import json
import time
from collections import Counter

import pandas as pd

from analysis_common import ROOT, atomic_json, digest, now
from derive_temporal_features import threshold_counts
from extract_native_logs import DATES


def decision(primary, case, context):
    if case['unknown_completions'] or case['conflicting_completions']:
        return 'unresolved_context'
    if case['secondary_clock_reversals'] or case['secondary_parse_flags']:
        return 'clock_or_parse_exception'
    if context['date'] != DATES[case['year']][1] or context['turn'] != 1:
        return 'different_date_or_turn'
    if any(context['target'][k] != case[k] for k in ['municipality', 'zone', 'section']):
        raise ValueError('Section identity differs')
    if primary.log_present and pd.isna(primary.reviewed_observed_completions):
        return 'unresolved_primary_count'
    if primary.log_present and int(primary.reviewed_observed_completions) != 0:
        return 'positive_primary_not_merged'
    if not context['completion_seconds']['target']:
        return 'no_target_completions'
    return 'accepted_whole_target_sequence'


def main():
    rp = ROOT / 'reports/supplemental-context-review-state.json'
    review = json.loads(rp.read_text())
    out = ROOT / 'analysis/derived/supplemental-sensitivity-v1' / str(time.time_ns())
    out.mkdir(parents=True, exist_ok=False)
    cache, sources, rows = {}, [], []
    for case in review['cases']:
        year, uf = case['year'], case['uf']
        key = (year, uf)
        if key not in cache:
            mp = ROOT / f'analysis/derived/temporal-reviewed-v1/{year}/1t-{uf}/complete.json'
            manifest = json.loads(mp.read_text())
            source = mp.parent / 'sections.parquet'
            if digest(source) != next(r['sha256'] for r in manifest['outputs'] if r['path'].endswith('sections.parquet')):
                raise ValueError('Reviewed source changed')
            cache[key] = pd.read_parquet(source).set_index(['municipality', 'zone', 'section'])
            sources.append({'path': str(mp.relative_to(ROOT)), 'sha256': digest(mp)})
        primary = cache[key].loc[tuple(case[k] for k in ['municipality', 'zone', 'section'])]
        cp = ROOT / case['evidence']
        if digest(cp) != case['evidence_sha256']:
            raise ValueError('Secondary context evidence changed')
        context = json.loads(cp.read_text())
        verdict = decision(primary, case, context)
        accepted = verdict == 'accepted_whole_target_sequence'
        deadline = primary.ordinary_deadline_local_seconds
        deadline = float(deadline) if pd.notna(deadline) else None
        secondary = threshold_counts(context['completion_seconds']['target'], deadline)
        before = int(primary.reviewed_observed_completions) if primary.log_present else 0
        after = secondary['observed_completions'] if accepted else before
        late_before = (int(primary.reviewed_after_ordinary_p0) if primary.log_present else 0) if deadline is not None else None
        late_after = (int(secondary['after_ordinary_p0']) if accepted else late_before) if deadline is not None else None
        attendance = int(primary.attendance)
        rows.append({k: case[k] for k in ['year', 'uf', 'municipality', 'zone', 'section']} | {
            'decision': verdict, 'primary_log_present': bool(primary.log_present),
            'primary_completions': before, 'retained_target_completions': secondary['observed_completions'],
            'secondary_foreign_excluded': case['foreign_completions'],
            'attendance': attendance, 'alternative_completions': after,
            'additional_reconstructed_completions': after - before,
            'primary_gap': max(0, attendance - before), 'alternative_gap': max(0, attendance - after),
            'alternative_excess': max(0, after - attendance),
            'primary_strict_late': late_before, 'alternative_strict_late': late_after,
            'additional_reconstructed_strict_late': late_after - late_before if deadline is not None else None,
            'repeated_second_events_retained': len(context['completion_seconds']['target']) - len(set(context['completion_seconds']['target'])),
            'primary_event_overlap_count': 0 if accepted else None,
            'evidence': case['evidence'], 'evidence_sha256': case['evidence_sha256']})
    data = pd.DataFrame(rows)
    data.to_csv(out / 'all-retention-decisions.csv', index=False)
    data.to_parquet(out / 'all-retention-decisions.parquet', index=False, compression='zstd')
    accepted = data[data.decision.eq('accepted_whole_target_sequence')]
    accepted.to_csv(out / 'accepted-alternatives.csv', index=False)
    report = {'at': now(), 'status': 'explicit_secondary_source_sensitivity_primary_unchanged',
              'output_folder': str(out.relative_to(ROOT)), 'cases_reviewed': len(rows),
              'decisions': dict(Counter(data.decision)), 'accepted': accepted.to_dict('records'),
              'additional_reconstructed_completions': int(accepted.additional_reconstructed_completions.sum()),
              'additional_reconstructed_strict_late_domestic_only': int(accepted.additional_reconstructed_strict_late.sum()),
              'overseas_alternative_completions': int(accepted.loc[accepted.uf.eq('ZZ'), 'additional_reconstructed_completions'].sum()),
              'alternative_excess': int(accepted.alternative_excess.sum()),
              'inputs': sources + [{'path': str(rp.relative_to(ROOT)), 'sha256': digest(rp)}],
              'code_sha256': digest(ROOT / 'scripts/analyze_supplemental_sensitivity.py'),
              'limitations': ['Only zero-completion primaries are substituted. No positive sequences are merged.',
                  'Retained first-turn events are used only after explicit section/date/context and clock/parse checks.',
                  'Same-second events remain distinct. No candidate or elector preference is inferred.',
                  'Count equality is a diagnostic, not an acceptance requirement. Partial recoveries remain partial.',
                  'This historical sensitivity does not change the primary population or 2026 findings.'],
              'outputs': [{'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size, 'sha256': digest(p)} for p in out.iterdir()]}
    atomic_json(out / 'analysis.json', report)
    atomic_json(ROOT / 'reports/supplemental-sensitivity-state.json', report)
    print(json.dumps({k: v for k, v in report.items() if k not in ['accepted', 'inputs', 'outputs', 'limitations']}))


if __name__ == '__main__':
    main()
