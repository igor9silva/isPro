"""Recorded-time census summaries and linked comparisons, without causal claims."""
import argparse
from collections import Counter
import json
import time

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

from analysis_common import ROOT, atomic_json, digest, now
from compare_election_sections import normalized_aggregates
from derive_temporal_features import DELTAS, suffix

KEYS = ['uf','municipality','zone','section']
BASE = ['year','round'] + KEYS + ['municipality_name','polling_place','aggregated_sections','eligible','attendance',
    'opened_elapsed_seconds','closed_elapsed_seconds','emitted_elapsed_seconds','ordinary_deadline_local_seconds',
    'open_seconds_after_ordinary_start','close_seconds_after_ordinary_deadline','log_present','context_audited',
    'context_known','context_qualified_change','context_foreign_completions','reviewed_observed_completions',
    'reviewed_count_matches_day','reviewed_gap_if_no_spurious','reviewed_strict_time_eligible',
    'reviewed_startup_allowed_time_eligible','reviewed_at_ordinary_deadline','reviewed_at_ordinary_plus_3600',
    'reviewed_at_ordinary_plus_7200','reviewed_first_completed_second','reviewed_last_completed_second',
    'day_log_boot_count','day_nested_archive_count','day_suspended_without_vote_count','day_closing_started_count',
    'day_clock_backwards_count','day_unparsed_target_date_lines','operational_context_contaminated',
    'clock_reversals_after_completion_in_text','following_observed_completions']
COUNTS = ['reviewed_after_ordinary_'+suffix(d) for d in DELTAS]


def totals(g):
    domestic = g.uf.ne('ZZ').all()
    d = {'sections':len(g),'eligible':int(g.eligible.sum()),'attendance':int(g.attendance.sum()),
        'sections_with_logs':int(g.log_present.sum()),'sections_count_reconciled':int(g.reviewed_count_matches_day.sum()),
        'missing_log_sections':int((~g.log_present).sum()),'missing_log_attendance':int(g.loc[~g.log_present,'attendance'].sum()),
        'count_mismatch_sections':int((g.log_present & ~g.reviewed_count_matches_day).sum()),
        'recorded_completions':int(g.reviewed_observed_completions.sum()),
        'unobserved_count_gap_if_no_spurious':int(g.reviewed_gap_if_no_spurious.sum()),
        'strict_time_sections':int(g.reviewed_strict_time_eligible.sum()),
        'startup_allowed_sections':int(g.reviewed_startup_allowed_time_eligible.sum()),
        'context_changed_sections':int(g.context_qualified_change.sum()),
        'context_foreign_events_removed':int(g.context_foreign_completions.sum()),
        'clock_reversal_sections':int(g.day_clock_backwards_count.gt(0).sum()),
        'clock_reversal_after_completion_sections':int(g.clock_reversals_after_completion_in_text.gt(0).sum())}
    d['turnout_percent'] = 100*d['attendance']/d['eligible'] if d['eligible'] else None
    if not domestic:
        return d
    a,b,c = (int(g['reviewed_after_ordinary_p'+str(t)].sum()) for t in [0,3600,7200])
    exact=int(g.reviewed_at_ordinary_deadline.sum())
    d.update(recorded_strict_post_deadline=a,recorded_inclusive_post_deadline=a+exact,exact_deadline_events=exact,
        recorded_17_18=a-b,recorded_18_19=b-c,recorded_after_19=c,
        post_deadline_sections=int(g.reviewed_after_ordinary_p0.gt(0).sum()),
        strict_subset_late=int(g.loc[g.reviewed_strict_time_eligible,'reviewed_after_ordinary_p0'].sum()),
        startup_allowed_subset_late=int(g.loc[g.reviewed_startup_allowed_time_eligible,'reviewed_after_ordinary_p0'].sum()),
        recorded_post_deadline_percent_of_attendance=100*a/d['attendance'] if d['attendance'] else None)
    return d


def paired(a,b,labels):
    keep=KEYS+['polling_place','aggregated_sections','eligible','attendance','reviewed_after_ordinary_p0',
               'reviewed_count_matches_day','reviewed_startup_allowed_time_eligible']
    q=a[keep].merge(b[keep],on=KEYS,how='outer',suffixes=('_a','_b'),indicator=True,validate='one_to_one')
    matched=q._merge.eq('both')
    stable=matched & q.polling_place_a.eq(q.polling_place_b) & q.aggregated_sections_a.map(normalized_aggregates).eq(q.aggregated_sections_b.map(normalized_aggregates))
    count_ok=q.reviewed_count_matches_day_a.fillna(False)&q.reviewed_count_matches_day_b.fillna(False)
    clock_ok=q.reviewed_startup_allowed_time_eligible_a.fillna(False)&q.reviewed_startup_allowed_time_eligible_b.fillna(False)
    output=[]
    for name,mask in [('exact_keys',matched),('stable_metadata',stable),('stable_count_reconciled',stable&count_ok),
                      ('stable_startup_allowed',stable&clock_ok),('stable_electorate_within_5pct',stable&count_ok&(q.eligible_b/q.eligible_a-1).abs().le(.05))]:
        x=q[mask]; ca=x.reviewed_after_ordinary_p0_a.fillna(0); cb=x.reviewed_after_ordinary_p0_b.fillna(0)
        output.append({**labels,'pair_definition':name,'paired_sections':len(x),'a_only_sections':int(q._merge.eq('left_only').sum()),
            'b_only_sections':int(q._merge.eq('right_only').sum()),'attendance_a':int(x.attendance_a.sum()),'attendance_b':int(x.attendance_b.sum()),
            'recorded_late_a':int(ca.sum()),'recorded_late_b':int(cb.sum()),
            'late_percent_attendance_a':100*ca.sum()/x.attendance_a.sum() if x.attendance_a.sum() else None,
            'late_percent_attendance_b':100*cb.sum()/x.attendance_b.sum() if x.attendance_b.sum() else None,
            'mean_section_late_fraction_a':(ca/x.attendance_a.where(x.attendance_a>0)).mean(),
            'mean_section_late_fraction_b':(cb/x.attendance_b.where(x.attendance_b>0)).mean(),
            'late_in_both':int((ca.gt(0)&cb.gt(0)).sum()),'late_only_a':int((ca.gt(0)&cb.eq(0)).sum()),
            'late_only_b':int((cb.gt(0)&ca.eq(0)).sum()),
            'interpretation':'descriptive association; missing logs are retained in unrestricted pairs and counted explicitly in coverage tables'})
    return output


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--years',default='2026,2022,2024');args=parser.parse_args()
    years=[int(y) for y in args.years.split(',')]
    out=ROOT/'analysis/derived/temporal-population-v1'/str(time.time_ns());out.mkdir(parents=True,exist_ok=False)
    frames, sources, histogram, coverage = [],[],[],[]
    for year in years:
        expected=pd.read_parquet(ROOT/f'analysis/derived/sections-v2/{year}/section-office.parquet',columns=['round','uf','office','municipality','zone','section'])
        expected=expected[expected.office.eq(11 if year==2024 else 1)]
        year_frames=[]
        for mp in sorted((ROOT/f'analysis/derived/temporal-reviewed-v1/{year}').glob('*/complete.json')):
            m=json.loads(mp.read_text());path=mp.parent/'sections.parquet'
            if digest(path)!=next(x['sha256'] for x in m['outputs'] if x['path'].endswith('sections.parquet')):raise ValueError('Reviewed table changed')
            f=pd.read_parquet(path,columns=BASE+COUNTS);year_frames.append(f)
            sources.append({'path':str(mp.relative_to(ROOT)),'sha256':digest(mp)})
            if m['uf']=='ZZ':continue
            primary=ROOT/m['input_manifest'];pm=json.loads(primary.read_text());hp=primary.parent/'minute-histogram.csv'
            if digest(hp)!=next(x['sha256'] for x in pm['outputs'] if x['path'].endswith('minute-histogram.csv')):raise ValueError('Histogram changed')
            h=pd.read_csv(hp);bins=Counter(h[h.date_group.eq('day')].groupby('minutes_after_ordinary_deadline').completions.sum().to_dict())
            indexed=f.set_index(['municipality','zone','section'])
            for row in f[f.context_qualified_change].itertuples(index=False):
                cp=ROOT/f'analysis/source-audit/log-context-v1/{year}-{row.round}t-{row.uf}/{row.municipality}-{row.zone}-{row.section}.json'
                c=json.loads(cp.read_text())
                for label in ['foreign','unknown','conflicting']:
                    for seconds in c['completion_seconds'][label]:bins[int((seconds-row.ordinary_deadline_local_seconds)//60)]-=1
            if min(bins.values(),default=0)<0 or sum(bins.values())!=int(f.reviewed_observed_completions.sum()):raise ValueError('Reviewed histogram count reconciliation failed')
            histogram += [{'year':year,'round':m['round'],'uf':m['uf'],'minutes_after_ordinary_deadline':int(k),'completions':int(v)} for k,v in sorted(bins.items())]
        if not year_frames:continue
        y=pd.concat(year_frames,ignore_index=True);frames.append(y)
        for turn,e in expected.groupby('round'):
            included=y[y['round'].eq(turn)]
            coverage.append({'year':year,'round':int(turn),'expected_sections':len(e),'included_sections':len(included),
                'expected_ufs':int(e.uf.nunique()),'included_ufs':int(included.uf.nunique()),'population_complete':len(included)==len(e),
                'missing_ufs':','.join(sorted(set(e.uf)-set(included.uf)))})
    f=pd.concat(frames,ignore_index=True)
    national,ufrows,munrows,sensitivity,operational,comparisons=[],[],[],[],[],[]
    for (year,turn),allg in f.groupby(['year','round']):
        for region,g in [('domestic',allg[allg.uf.ne('ZZ')]),('overseas',allg[allg.uf.eq('ZZ')])]:
            if len(g):national.append({'year':year,'round':turn,'scope':region,**totals(g)})
        g=allg[allg.uf.ne('ZZ')]
        for delta in DELTAS:
            for population,mask in [('all_recorded',g.log_present),('count_reconciled',g.reviewed_count_matches_day),
                                     ('strict_time',g.reviewed_strict_time_eligible),('startup_allowed',g.reviewed_startup_allowed_time_eligible)]:
                x=g[mask];sensitivity.append({'year':year,'round':turn,'cutoff_seconds_after_ordinary':delta,'population':population,
                    'sections':len(x),'attendance':int(x.attendance.sum()),'recorded_late':int(x['reviewed_after_ordinary_'+suffix(delta)].sum())})
        for uf,x in allg.groupby('uf'):ufrows.append({'year':year,'round':turn,'uf':uf,**totals(x)})
        for (uf,mun,name),x in g.groupby(['uf','municipality','municipality_name']):munrows.append({'year':year,'round':turn,'uf':uf,'municipality':mun,'municipality_name':name,**totals(x)})
        ops=g[g.log_present & ~g.operational_context_contaminated].copy()
        flags={'multiple_log_boots':ops.day_log_boot_count.gt(1),'nested_archive':ops.day_nested_archive_count.gt(0),
               'suspension_without_vote':ops.day_suspended_without_vote_count.gt(0),'opening_delay_over_5min':ops.open_seconds_after_ordinary_start.gt(300)}
        for label,flag in flags.items():
            for present in [False,True]:
                x=ops[flag.eq(present)];operational.append({'year':year,'round':turn,'indicator':label,'present':present,**totals(x)})
    for year,g in f[f.uf.ne('ZZ')].groupby('year'):
        if set(g['round'])=={1,2}:comparisons+=paired(g[g['round']==1],g[g['round']==2],{'comparison':'within_election','year_a':year,'year_b':year,'round_a':1,'round_b':2})
    for turn in [1,2]:
        a=f[(f.year==2022)&(f['round']==turn)&f.uf.ne('ZZ')];b=f[(f.year==2026)&(f['round']==turn)&f.uf.ne('ZZ')]
        if len(a) and len(b):comparisons+=paired(a,b,{'comparison':'general_election_2022_2026','year_a':2022,'year_b':2026,'round_a':turn,'round_b':turn})
    outputs={'national':national,'uf':ufrows,'municipality':munrows,'cutoff-sensitivity':sensitivity,
             'operational-associations':operational,'linked-comparisons':comparisons,'coverage':coverage,'minute-histograms':histogram}
    for name,rows in outputs.items():
        data=pd.DataFrame(rows);data.to_csv(out/f'{name}.csv',index=False)
        if name in ['municipality','minute-histograms']:data.to_parquet(out/f'{name}.parquet',index=False,compression='zstd')
    result={'at':now(),'status':'recorded_time_population_analysis','output_folder':str(out.relative_to(ROOT)),
            'coverage':coverage,'national':national,'input_manifests':sources,
            'code_sha256':digest(ROOT/'scripts/analyze_temporal_population.py'),
            'limitations':['Counts use recorded clocks; they do not identify votes caused by the extension.',
                'Historical coverage is explicit and can be incomplete while jobs run; compare only reported included/linked populations.',
                'Equal section keys do not prove unchanged physical membership. Stable polling/aggregation and exploratory5percent electorate restrictions are separate sensitivities.',
                'Operational associations are descriptive and can reflect reverse causation, selection and regional confounding.',
                'No sampling confidence intervals are attached to census counts. Clock/coverage sensitivities are scenarios, not empirically certified error bounds.'],
            'outputs':[{'path':str(p.relative_to(ROOT)),'sha256':digest(p),'bytes':p.stat().st_size} for p in out.iterdir()]}
    atomic_json(out/'analysis.json',result);atomic_json(ROOT/'reports/temporal-population-state.json',result)
    print(json.dumps({'folder':result['output_folder'],'coverage':coverage,'national':national}),flush=True)


if __name__=='__main__':main()
