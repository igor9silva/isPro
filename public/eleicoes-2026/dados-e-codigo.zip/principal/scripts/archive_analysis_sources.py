"""Retry small official context documents into a dated, append-only evidence folder."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time

import requests

from analysis_common import ROOT, atomic_json, now

EXTRA = [
    ("tse-votos-apos-17h-pdf", "https://www.tse.jus.br/comunicacao/noticias/arquivos/total-de-votos-apos-17h"),
    ("tse-secoes-apos-17h10-pdf", "https://www.tse.jus.br/comunicacao/noticias/arquivos/votos-computados-apos-17h10"),
    ("tse-secoes-apos-19h-pdf", "https://www.tse.jus.br/comunicacao/noticias/arquivos/votos-computados-apos-19h"),
    ("tre-am-horarios", "https://www.tre-am.jus.br/comunicacao/noticias/2026/Setembro/eleitorado-do-amazonas-deve-ficar-atento-aos-horarios-de-votacao-nas-eleicoes-2026"),
    ("stf-rcl101673-andamento", "https://portal.stf.jus.br/processos/detalhe.asp?incidente=7733125"),
]


def fetch(item, folder):
    result = {"name": item["name"], "url": item["url"], "retrieved_at": now()}
    try:
        with requests.get(item["url"], timeout=(15, 45), stream=True,
                          headers={"User-Agent": "TSE-public-data-research/1.0"}) as response:
            result.update(http_status=response.status_code, final_url=response.url,
                          content_type=response.headers.get("Content-Type"), etag=response.headers.get("ETag"),
                          last_modified=response.headers.get("Last-Modified"))
            response.raise_for_status()
            body = bytearray()
            for chunk in response.iter_content(65536):
                body.extend(chunk)
                if len(body) > 20 * 1024**2:
                    raise ValueError("Auxiliary document exceeds 20 MiB bounded download")
            if not body:
                raise ValueError("Empty response")
            ext = ".pdf" if body.startswith(b"%PDF") else ".zip" if body.startswith(b"PK") else ".html"
            path = folder / (item["name"].replace(".pdf", "").replace(".zip", "") + ext)
            if path.exists():
                raise ValueError("Refusing to overwrite a source snapshot")
            path.write_bytes(body)
            result.update(status="downloaded_http_body_pending_content_review", path=str(path.relative_to(ROOT)),
                          bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
    except Exception as e:
        result.update(status="not_downloaded", error=f"{type(e).__name__}: {e}")
    return result


def main():
    stamp = time.strftime("%Y%m%dT%H%M%S", time.gmtime())
    folder = ROOT / "analysis/source-audit/http-snapshots" / stamp
    folder.mkdir(parents=True, exist_ok=False)
    sources = json.loads((ROOT / "metadata/cloud-context.json").read_text())["context_not_downloaded"]
    sources += [{"name": name, "url": url} for name, url in EXTRA]
    results = []
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = [pool.submit(fetch, s, folder) for s in sources]
        for f in as_completed(futures):
            result = f.result()
            results.append(result)
            atomic_json(folder / "retrievals.json", {"at": now(), "records": results})
            print(json.dumps(result, ensure_ascii=False), flush=True)
    atomic_json(ROOT / "reports/analysis-source-retrieval-latest.json", {"at": now(), "records": results})


if __name__ == "__main__":
    main()
