#!/usr/bin/env python3
"""Audit a completed acquisition without downloading the large raw archives.

Read-only against S3. Credentials are resolved from the existing AWS profile.
Reports distinguish prior byte-level checks from this metadata/companion audit.
"""
import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import sys
import time

import boto3
from botocore.config import Config

from cloud_transfer import checksum_from_text, validate_url


MISSING_SHA1 = (
    "https://cdn.tse.jus.br/estatistica/sead/eleicoes/eleicoes2014/"
    "correspesp/cesp_2t_ZZ_26102014151223.zip.sha1"
)
METHODS = {
    "full_s3_readback_against_trusted_checksum",
    "source_hashes_and_server_validated_content_md5",
    "source_hashes_and_server_validated_content_md5_per_part",
}


def read(path):
    return json.loads(Path(path).read_text())


def stamp():
    return datetime.now(timezone.utc).isoformat()


def write(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    temporary.replace(path)


def receipt_issues(row, local, remote, head, bucket, prefix):
    """Pure identity and integrity-record checks, used by the live audit/tests."""
    problems = []
    expected = {"path": row["path"], "url": row["url"], "bucket": bucket,
                "key": prefix.rstrip("/") + "/" + row["path"], "status": "verified"}
    for field, value in expected.items():
        if local.get(field) != value or remote.get(field) != value:
            problems.append("identity:" + field)
    for field in ("bytes", "etag", "hashes", "official_checksums",
                  "official_checksums_unavailable", "verification_method"):
        if local.get(field) != remote.get(field):
            problems.append("local_remote_receipt:" + field)
    if remote.get("bytes") != head.get("ContentLength"):
        problems.append("stored_size")
    if not remote.get("etag") or remote["etag"] != head.get("ETag"):
        problems.append("stored_etag")
    if row.get("bytes_remote") is not None and remote.get("bytes") != row["bytes_remote"]:
        problems.append("catalog_size")
    hashes = remote.get("hashes", {})
    for algorithm, length in (("md5", 32), ("sha1", 40), ("sha256", 64), ("sha512", 128)):
        if not re.fullmatch(r"[0-9a-f]{%d}" % length, hashes.get(algorithm, "")):
            problems.append("digest_format:" + algorithm)
    if remote.get("verification_method") not in METHODS:
        problems.append("unknown_verification_method")
    for checksum in remote.get("official_checksums", []):
        if (checksum.get("matched") is not True
                or hashes.get(checksum.get("algorithm")) != checksum.get("digest")):
            problems.append("official_digest_record")
    for checksum in remote.get("official_checksums_unavailable", []):
        if checksum.get("source_url") != MISSING_SHA1 or checksum.get("http_status") != 404:
            problems.append("unexpected_unavailable_checksum")
    refresh = row.get("source_revision_refresh", {})
    if refresh:
        expected_headers = refresh.get("observed_headers", {})
        actual_headers = remote.get("source", {}).get("headers", {})
        for field in ("etag", "last-modified"):
            if expected_headers.get(field) and actual_headers.get(field) != expected_headers[field]:
                problems.append("approved_source_revision:" + field)
    return problems


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--queue", default="metadata/cloud-supervisor/queue.json")
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--wait-for-collection", action="store_true",
                        help="Wait for the existing supervisor; never start or restart transfers")
    args = parser.parse_args()
    if not 1 <= args.workers <= 12:
        parser.error("workers must be between 1 and 12")
    root = Path(__file__).resolve().parents[1]
    queue_path = Path(args.queue)
    if not queue_path.is_absolute():
        queue_path = root / queue_path
    queue = read(queue_path)
    bucket, prefix = queue["bucket"], queue["prefix"].rstrip("/")
    if bucket != "tse-research" or prefix != "tse/2026-10-29":
        raise ValueError("Unexpected acquisition destination")
    status = read(queue_path.parent / "collection-status.json")
    if args.wait_for_collection:
        announced = False
        while status["status"] == "running":
            if not announced:
                print(json.dumps({"at": stamp(), "event": "waiting_for_collection_and_reconciliation"}),
                      flush=True)
                announced = True
            time.sleep(30)
            status = read(queue_path.parent / "collection-status.json")
    if status["pending"] or status["failed"] or status["status"] not in ("finished", "finished_with_gaps"):
        raise SystemExit("Acquisition/reconciliation not finished; final audit not started")
    rows, local, gaps, manifest_hashes = {}, {}, [], []
    for job in queue["jobs"]:
        manifest_path = Path(job["manifest"])
        manifest = read(manifest_path)
        progress = read(Path(job["state_dir"]) / "progress.json")
        if progress["pending"] or progress["failed"]:
            raise SystemExit("Stage still has unfinished acquisition/reconciliation")
        if len(progress["files"]) != len(manifest["resources"]):
            raise ValueError("Stage report does not account for every selected resource")
        manifest_hashes.append({"path": str(manifest_path.relative_to(root)),
                                "sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest()})
        for row in manifest["resources"]:
            validate_url(row["url"])
            if row["path"] in rows:
                raise ValueError("Duplicate selected path")
            rows[row["path"]] = row
        for item in progress["files"]:
            if item["status"] == "verified":
                local[item["path"]] = item
            elif item["status"] == "unavailable" and item["url"] == MISSING_SHA1:
                gaps.append(item)
            else:
                raise ValueError("Unresolved or unexpected acquisition gap")
    if set(rows) != set(local) | {g["path"] for g in gaps}:
        raise ValueError("Resource/report path coverage mismatch")
    for recovery in queue.get("recoveries", []):
        progress = read(Path(recovery["state_dir"]) / "progress.json")
        if progress["failed"] or progress["pending"]:
            raise ValueError("Recovery not finished")
        for item in progress["files"]:
            if item["status"] != "verified" or item["path"] not in local:
                raise ValueError("Recovery has not been reconciled")
            if any(item[k] != local[item["path"]][k] for k in ("url", "bytes", "etag", "hashes")):
                raise ValueError("Reconciled recovery receipt mismatch")

    client = boto3.Session(profile_name="tse-research", region_name="auto").client(
        "s3", endpoint_url="https://t3.storage.dev", config=Config(
            connect_timeout=20, read_timeout=30, max_pool_connections=args.workers,
            retries={"max_attempts": 3}, request_checksum_calculation="when_required"))
    objects = {o["Key"]: o for page in client.get_paginator("list_objects_v2").paginate(
        Bucket=bucket, Prefix=prefix + "/") for o in page.get("Contents", [])}
    raw_keys = {key for key in objects if key.startswith(prefix + "/raw/")}
    expected_keys = {item["key"] for item in local.values()}
    collection_issues = []
    if raw_keys != expected_keys:
        collection_issues.append({"raw_inventory_missing": sorted(expected_keys - raw_keys),
                                  "raw_inventory_extra": sorted(raw_keys - expected_keys)})
    active_uploads = [u for page in client.get_paginator("list_multipart_uploads").paginate(
        Bucket=bucket, Prefix=prefix + "/") for u in page.get("Uploads", [])]
    if active_uploads:
        collection_issues.append({"unexpected_active_multipart_keys": [u["Key"] for u in active_uploads]})
    inventory_bytes = sum(o["Size"] for o in objects.values())
    if inventory_bytes >= min(queue["storage_limit_bytes"], 1_000_000_000_000):
        collection_issues.append({"storage_limit_exceeded": inventory_bytes})
    by_url = {row["url"]: row for row in rows.values()}

    def get_small(key, maximum=1024 * 1024):
        response = client.get_object(Bucket=bucket, Key=key)
        try:
            data = response["Body"].read(maximum + 1)
            if len(data) > maximum:
                raise ValueError("Unexpectedly large metadata/checksum object")
            return data
        finally:
            response["Body"].close()

    def inspect(path):
        row, item = rows[path], local[path]
        identity = hashlib.sha256(row["url"].encode()).hexdigest()
        try:
            receipt = json.loads(get_small(prefix + "/provenance/" + identity + ".json"))
            head = client.head_object(Bucket=bucket, Key=item["key"])
            issues = receipt_issues(row, item, receipt, head, bucket, prefix)
            companion_checks = []
            for checksum in receipt.get("official_checksums", []):
                companion = by_url.get(checksum["source_url"])
                if companion is None or companion["path"] not in local:
                    issues.append("official_companion_not_archived")
                    continue
                companion_receipt = local[companion["path"]]
                payload = get_small(companion_receipt["key"])
                if (len(payload) != companion_receipt["bytes"]
                        or hashlib.sha256(payload).hexdigest() != companion_receipt["hashes"]["sha256"]):
                    issues.append("official_companion_readback")
                digest = checksum_from_text(payload.decode("utf-8-sig"), checksum["algorithm"],
                                            PurePosixPath(path).name)
                if digest != checksum["digest"] or digest != receipt["hashes"][checksum["algorithm"]]:
                    issues.append("official_companion_digest")
                companion_checks.append({"path": companion["path"], "algorithm": checksum["algorithm"],
                                         "archived_payload_readback": True, "digest": digest})
            return {"path": path, "url": row["url"], "year": row.get("year"),
                    "category": row.get("category"), "bytes": item["bytes"], "etag": item["etag"],
                    "hashes": item["hashes"], "verification_method": item["verification_method"],
                    "official_companions": companion_checks, "issues": issues}
        except Exception as error:
            return {"path": path, "issues": ["audit_exception:" + type(error).__name__]}

    started = stamp()
    token = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
    directory = root / "reports" / ("acquisition-audit-" + token)
    directory.mkdir()
    records = []
    with (directory / "objects.jsonl").open("w") as out:
        with ThreadPoolExecutor(max_workers=args.workers) as pool:
            futures = [pool.submit(inspect, path) for path in sorted(local)]
            for future in as_completed(futures):
                record = future.result()
                records.append(record)
                out.write(json.dumps(record, ensure_ascii=False) + "\n")
                out.flush()
                if len(records) % 100 == 0 or len(records) == len(local):
                    progress = {"updated_at": stamp(), "checked": len(records), "expected": len(local),
                                "objects_with_issues": sum(bool(r["issues"]) for r in records)}
                    write(directory / "progress.json", progress)
                    print(json.dumps(progress), flush=True)
    failures = [r for r in records if r["issues"]]
    context = read(root / "metadata/cloud-context.json")
    report = {"schema_version": 1, "started_at": started, "finished_at": stamp(),
              "status": "passed_with_documented_gaps" if not failures and not collection_issues else "failed",
              "bucket": bucket, "prefix": prefix, "selected_resources": len(rows),
              "verified_objects": len(local), "verified_raw_bytes": sum(f["bytes"] for f in local.values()),
              "known_catalog_bytes": queue["planned_bytes_known"], "prefix_inventory_bytes": inventory_bytes,
              "storage_limit_bytes": queue["storage_limit_bytes"], "active_multipart_count": len(active_uploads),
              "verification_method_counts": dict(Counter(f["verification_method"] for f in local.values())),
              "objects_with_official_hash_comparison": sum(bool(r.get("official_companions")) for r in records),
              "official_companion_readbacks": sum(len(r.get("official_companions", [])) for r in records),
              "missing_official_checksums": gaps, "auxiliary_document_gaps": context["context_not_downloaded"],
              "manifest_hashes": manifest_hashes, "collection_issues": collection_issues, "object_issues": failures,
              "records_path": str((directory / "objects.jsonl").relative_to(root)),
              "records_sha256": hashlib.sha256((directory / "objects.jsonl").read_bytes()).hexdigest(),
              "scope": "All raw objects checked by HEAD against catalog and local/remote receipts; official companion payloads reread and parsed. Large raw payloads were not reread in this audit. Their prior full-readback or source-hash plus server-validated Content-MD5 verification methods are reported separately. Object ETags are identity validators, not assumed to be whole-file MD5 hashes."}
    write(directory / "summary.json", report)
    write(root / "reports/final-acquisition-audit.json", report)
    print(json.dumps({k: report[k] for k in ("status", "verified_objects", "verified_raw_bytes",
                                           "objects_with_official_hash_comparison", "records_path")}))
    return 0 if report["status"] == "passed_with_documented_gaps" else 1


if __name__ == "__main__":
    sys.exit(main())
