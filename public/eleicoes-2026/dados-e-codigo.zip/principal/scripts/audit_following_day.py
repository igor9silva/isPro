"""Explicit next-day context audit and sensitivity; primary same-day outputs stay intact."""
import datetime
import hashlib
import json
import time
from collections import defaultdict

import pandas as pd

from analysis_common import ROOT, archive, atomic_json, digest, inputs, now
from audit_log_context import audit
from extract_native_logs import DATES


def main():
    review = json.loads((ROOT / 'reports/measurement-exception-review-state.json').read_text())
    cases = pd.read_csv(ROOT / review['output_folder'] / 'all-measurement-exceptions.csv')
    cases = cases[cases.following_observed_completions.gt(0)]
    out = ROOT / 'analysis/source-audit/following-day-v1' / str(time.time_ns())
    out.mkdir(parents=True, exist_ok=False)
    index = {r['path']: r for r in inputs()}
    rows = []
    supplemental = json.loads((ROOT / 'reports/supplemental-sensitivity-state.json').read_text())
    skeys = {(r['year'], r['uf'], r['municipality'], r['zone'], r['section']) for r in supplemental['accepted']}
    for (year, turn, uf), g in cases.groupby(['year', 'round', 'uf']):
        year, turn = int(year), int(turn)
        source = f'raw/{year}/arquivos_urna/bu_imgbu_logjez_rdv_vscmr_{year}_{turn}t_{uf}.zip'
        fp = ROOT / f'analysis/derived/temporal-reviewed-v1/{year}/{turn}t-{uf}/sections.parquet'
        frame = pd.read_parquet(fp).set_index(['municipality', 'zone', 'section'])
        day = datetime.datetime.strptime(DATES[year][turn], '%d/%m/%Y').date() + datetime.timedelta(days=1)
        with archive(index[source], block_size=512*1024) as (z, stats):
            for c in g.to_dict('records'):
                key = tuple(int(c[k]) for k in ['municipality', 'zone', 'section']); f = frame.loc[key]
                payload = z.read(f.source_member)
                if hashlib.sha256(payload).hexdigest() != f.source_package_sha256:
                    raise ValueError('Package changed')
                result = audit(payload, f.source_member, day.strftime('%d/%m/%Y'), dict(zip(['municipality', 'zone', 'section'], key)), turn)
                if result['unique_completions_all_contexts'] != c['following_observed_completions']:
                    raise ValueError('Next-day population differs')
                ep = out / f'{year}-{turn}t-{uf}-{key[0]}-{key[1]}-{key[2]}.json'; atomic_json(ep, result)
                counts = {k: len(v) for k, v in result['completion_seconds'].items()}
                own = counts['target']; primary = int(c['reviewed_observed_completions'])
                overlap = (year, uf, *key) in skeys
                if overlap:
                    raise ValueError('Cross-midnight and secondary sensitivities overlap; explicit deduplication needed')
                rows.append({'year': year, 'round': turn, 'uf': uf, **dict(zip(['municipality', 'zone', 'section'], key)),
                    'attendance': int(c['attendance']), 'primary_same_day_completions': primary,
                    'following_day_target': own, 'following_day_foreign': counts['foreign'],
                    'following_day_unknown': counts['unknown'], 'following_day_conflicting': counts['conflicting'],
                    'alternative_total': primary + own, 'alternative_gap': max(0, int(c['attendance']) - primary - own),
                    'alternative_excess': max(0, primary + own - int(c['attendance'])),
                    'first_next_day_second': min(result['completion_seconds']['target'], default=None),
                    'last_next_day_second': max(result['completion_seconds']['target'], default=None),
                    'bweb_close_elapsed_seconds': f.closed_elapsed_seconds,
                    'source': source, 'source_member': f.source_member, 'source_package_sha256': f.source_package_sha256,
                    'evidence': str(ep.relative_to(ROOT)), 'evidence_sha256': digest(ep), 'secondary_sensitivity_overlap': overlap})
    table = pd.DataFrame(rows); table.to_csv(out / 'next-day-sensitivity.csv', index=False)
    result = {'at': now(), 'status': 'next_day_events_audited_as_separate_sensitivity', 'output_folder': str(out.relative_to(ROOT)),
              'cases': rows, 'target_events': int(table.following_day_target.sum()),
              'all_counts_reconcile_when_included': bool((table.alternative_gap.eq(0) & table.alternative_excess.eq(0)).all()),
              'unknown_or_conflicting_events': int(table.following_day_unknown.sum() + table.following_day_conflicting.sum()),
              'code_sha256': digest(ROOT / 'scripts/audit_following_day.py'),
              'limitations': ['Primary same-day measurements remain unchanged. This is an explicit cross-midnight recorded-time sensitivity.',
                  'Matching counts and context do not certify absolute clock accuracy or establish a causal reason for delay.',
                  'These cases are disjoint from retained-second-turn whole-source alternatives; no candidate-by-time linkage is attempted.']}
    atomic_json(out / 'analysis.json', result); atomic_json(ROOT / 'reports/following-day-review-state.json', result)
    print(json.dumps({k:v for k,v in result.items() if k not in ['cases','limitations']}))


if __name__ == '__main__':
    main()
