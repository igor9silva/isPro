"""Audit internal section context in nested/exception packages, in a new layer.

Production extracts stay immutable. This detects foreign section logs archived
inside the target package; it never selects a text merely by its vote total.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import re
import time

import pandas as pd

from analysis_common import ROOT, archive, atomic_json, code_fingerprint, digest, inputs, now
from extract_native_logs import DATES
from parse_urna_logs import HEADER, COMPLETED, texts_in_package
from parse_urna_logs_legacy import to_parser_container
from watch_analysis_validation import active_jobs

OUT = ROOT / 'analysis/source-audit/log-context-v1'
PATTERNS = {'municipality': re.compile(r'^Município:\s*(\d+)\s*$'),
            'zone': re.compile(r'^Zona Eleitoral:\s*(\d+)\s*$'),
            'section': re.compile(r'^Seção Eleitoral:\s*(\d+)\s*$')}


def context_class(context, target, turn):
    known = {k: context[k] for k in target if k in context}
    if any(v != target[k] for k, v in known.items() if not (k == 'section' and v == 0)):
        return 'foreign'
    if context.get('turn') is not None and context['turn'] != turn:
        return 'foreign'
    if context.get('phase') is not None and context['phase'].lower() != 'oficial':
        return 'foreign'
    if len(known) != len(target) or context.get('section') == 0:
        return 'unknown'
    return 'target'


def audit(payload, member, date, target, turn):
    converted = to_parser_container(payload, counters={})
    events, contexts, texts = {}, Counter(), []
    for label, data in texts_in_package(converted, member, Counter()):
        current = {}
        n = Counter()
        for line in data.splitlines():
            match = HEADER.fullmatch(line)
            if not match:
                continue
            date_b, h, minute, second, severity, machine, app, message_b, mac = match.groups()
            message = message_b.decode('latin1').strip()
            if message == 'Início das operações do logd':
                current = {}
            for field, pattern in PATTERNS.items():
                m = pattern.fullmatch(message)
                if m:
                    current[field] = int(m[1])
            if message.startswith('Fase da UE:'):
                current['phase'] = message.split(':', 1)[1].strip()
            if message.startswith('Turno da UE:'):
                m = re.search(r'\d+', message.split(':', 1)[1])
                if m:
                    current['turn'] = int(m[0])
            if date_b.decode() != date or message != COMPLETED:
                continue
            if int(h) > 23 or int(minute) > 59 or int(second) > 59:
                n['invalid_clock'] += 1
                continue
            kind = context_class(current, target, turn)
            sec = int(h)*3600+int(minute)*60+int(second)
            identity = hashlib.blake2b(line, digest_size=16).hexdigest()
            if identity not in events:
                events[identity] = {'second': sec, 'classes': set()}
            elif events[identity]['second'] != sec:
                raise ValueError('Event identity collision')
            events[identity]['classes'].add(kind)
            contexts[(current.get('municipality'), current.get('zone'), current.get('section'),
                      current.get('turn'), current.get('phase'), kind)] += 1
            n['raw_' + kind] += 1
        texts.append({'member': label, 'sha256': hashlib.sha256(data).hexdigest(), 'counts': dict(n)})
    classified = defaultdict(list)
    for event in events.values():
        classes = event['classes']
        if 'foreign' in classes and 'target' in classes:
            kind = 'conflicting'
        elif 'target' in classes:
            kind = 'target'
        elif 'foreign' in classes:
            kind = 'foreign'
        else:
            kind = 'unknown'
        classified[kind].append(event['second'])
    return {'package_sha256': hashlib.sha256(payload).hexdigest(), 'date': date, 'target': target, 'turn': turn,
        'unique_completions_all_contexts': len(events),
        'context_counts': [{'municipality': k[0], 'zone': k[1], 'section': k[2], 'turn': k[3], 'phase': k[4],
                            'classification': k[5], 'raw_completions': v} for k, v in contexts.items()],
        'completion_seconds': {k: sorted(classified[k]) for k in ['target', 'foreign', 'unknown', 'conflicting']},
        'texts': texts,
        'limitations': ['Matching means explicit municipality/zone/section agree; phase and turn are checked when recorded.',
            'Missing configuration context stays unknown. No candidate or voter identifier is retained.',
            'Production measurements are not modified by this diagnostic.']}


def pass_once():
    index = {r['path']: r for r in inputs()}
    completed, errors, totals = [], [], Counter()
    manifests = list((ROOT / 'analysis/derived/temporal-features-v1').glob('*/*/complete.json'))
    manifests.sort(key=lambda p: (-int(p.parent.parent.name), 0 if p.parent.name.startswith('2t') else 1, p.parent.name))
    for mp in manifests:
        meta = json.loads(mp.read_text())
        if not meta.get('outputs'):
            continue
        year, turn, uf = meta['year'], meta['round'], meta['uf']
        dest = OUT / f'{year}-{turn}t-{uf}'
        dest.mkdir(parents=True, exist_ok=True)
        if (dest / 'complete.json').exists():
            old = json.loads((dest / 'complete.json').read_text())
            if old['feature_manifest_sha256'] != digest(mp):
                raise ValueError('Feature manifest changed; choose a new audit version')
            completed.append(str((dest / 'complete.json').relative_to(ROOT)))
            totals.update(old['counts'])
            continue
        path = mp.parent / 'sections.parquet'
        if digest(path) != next(x['sha256'] for x in meta['outputs'] if x['path'].endswith('sections.parquet')):
            raise ValueError('Feature table changed')
        f = pd.read_parquet(path)
        available = f[f.log_present].copy()
        flagged = ((available.day_text_file_count > 1) | (available.day_nested_archive_count > 0)
                   | ~available.count_matches_day | (available.day_clock_backwards_count > 0)
                   | (available.day_unparsed_target_date_lines > 0) | (available.day_invalid_clock_lines > 0))
        available['diagnostic_scope'] = flagged.map({True: 'all_nested_or_exception', False: 'simple_sample'})
        simple = available[~flagged].copy()
        simple['deterministic_order'] = simple.source_member.map(lambda x: hashlib.sha256(x.encode()).hexdigest())
        chosen = pd.concat([available[flagged], simple.sort_values('deterministic_order').head(5)], ignore_index=True)
        chosen = chosen.sort_values('source_member')
        source = f'raw/{year}/arquivos_urna/bu_imgbu_logjez_rdv_vscmr_{year}_{turn}t_{uf}.zip'
        pending = []
        for row in chosen.to_dict('records'):
            file = dest / f"{int(row['municipality'])}-{int(row['zone'])}-{int(row['section'])}.json"
            if not file.exists():
                pending.append((row, file))
        # A smaller bounded block cache avoids fetching multi-MiB neighborhoods
        # for every sparsely selected package. Archive and member CRCs still apply.
        if pending:
            try:
                with archive(index[source], block_size=512*1024) as (z, read):
                    for position, (row, file) in enumerate(pending):
                        payload = z.read(row['source_member'])
                        target = {k: int(row[k]) for k in ['municipality', 'zone', 'section']}
                        result = audit(payload, row['source_member'], DATES[year][turn], target, turn)
                        if result['package_sha256'] != row['source_package_sha256']:
                            raise ValueError('Original package hash differs from production extract')
                        result.update(at=now(), year=year, round=turn, uf=uf, source=source, source_member=row['source_member'],
                            source_archive_sha256=index[source]['hashes']['sha256'], bweb_attendance=int(row['attendance']) if pd.notna(row['attendance']) else None,
                            primary_completions=int(row['day_observed_completions']), scope=row['diagnostic_scope'],
                            code=code_fingerprint(['audit_log_context.py']))
                        result['target_context_count_matches_bweb'] = result['bweb_attendance'] is not None and len(result['completion_seconds']['target']) == result['bweb_attendance']
                        atomic_json(file, result)
                        if (position+1) % 100 == 0:
                            atomic_json(dest / 'progress.json', {'at': now(), 'selected': len(chosen), 'newly_completed': position+1,
                                'pending_at_start': len(pending), 'source': source})
                            print(json.dumps({'at': now(), 'source': source, 'newly_audited': position+1, 'pending_at_start': len(pending)}), flush=True)
            except Exception as exc:
                errors.append({'source': source, 'error': repr(exc)})
                continue
        counts = Counter(selected_packages=len(chosen), all_nested_or_exception=int(flagged.sum()), simple_samples=min(5, len(simple)))
        cases = []
        for row in chosen.to_dict('records'):
            file = dest / f"{int(row['municipality'])}-{int(row['zone'])}-{int(row['section'])}.json"
            result = json.loads(file.read_text())
            for label, seconds in result['completion_seconds'].items():
                counts[label + '_completions'] += len(seconds)
                counts['packages_with_' + label] += int(bool(seconds))
            if result['completion_seconds']['foreign'] or result['completion_seconds']['conflicting']:
                cases.append(str(file.relative_to(ROOT)))
        info = {'at': now(), 'status': 'context_audit_complete_for_defined_scope', 'feature_manifest': str(mp.relative_to(ROOT)),
            'feature_manifest_sha256': digest(mp), 'counts': dict(counts), 'foreign_or_conflicting_cases': cases,
            'scope': 'All nested/multiple-text, count, clock or parse exceptions plus five deterministic simple-package samples per archive.',
            'not_claimed': 'This is not an internal-context census of every simple single-text package.'}
        atomic_json(dest / 'complete.json', info)
        totals.update(counts);completed.append(str((dest / 'complete.json').relative_to(ROOT)))
    return completed, errors, dict(totals)


def main():
    p=argparse.ArgumentParser();p.add_argument('--watch',action='store_true');args=p.parse_args()
    while True:
        completed, errors, totals = pass_once()
        active = active_jobs() if args.watch else []
        atomic_json(ROOT / 'reports/log-context-audit-state.json', {'at': now(), 'status': 'running' if active else 'finished_for_available_features',
            'archives': len(completed), 'complete_reports': completed, 'totals': totals, 'execution_errors': errors,
            'active_extractions': active})
        if not active:
            break
        time.sleep(300)


if __name__=='__main__':main()
