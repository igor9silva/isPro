"""Check missing2026section logs against immutable ZIP central directories only."""
import json,time
from pathlib import Path
import re
import pandas as pd
from analysis_common import ROOT,archive,inputs,digest,atomic_json,now

def main():
 out=ROOT/'analysis/source-audit/missing-log-members-v1'/str(time.time_ns());out.mkdir(parents=True,exist_ok=False)
 index={r['path']:r for r in inputs()};cases=[];archives=[]
 for mp in sorted((ROOT/'analysis/derived/temporal-reviewed-v1/2026').glob('*/complete.json')):
  m=json.loads(mp.read_text());g=pd.read_parquet(mp.parent/'sections.parquet');missing=g[g.bweb_present & ~g.log_present]
  if not len(missing):continue
  uf=m['uf'];turn=m['round'];key=f'raw/2026/arquivos_urna/bu_imgbu_logjez_rdv_vscmr_2026_{turn}t_{uf}.zip'
  lookup={f'{int(r.municipality):05d}{int(r.zone):04d}{int(r.section):04d}':r for r in missing.itertuples()}
  found={k:[] for k in lookup}
  with archive(index[key]) as (z,stats):
   for i in z.infolist():
    name=Path(i.filename).name
    match=re.match(r'o\d{5}[a-z]{2}(\d{13})-',name,re.I)
    if match and match[1] in lookup:
     found[match[1]].append({'name':i.filename,'bytes':i.file_size,'compressed_bytes':i.compress_size,'crc32':i.CRC})
  archives.append({'path':key,'sha256':index[key]['hashes']['sha256'],'read':stats,'missing_sections':len(missing)})
  for k,r in lookup.items():
   ms=found[k];logs=[x for x in ms if x['name'].lower().endswith(('-log.jez','.logjez'))]
   cases.append({'uf':uf,'round':turn,'municipality':int(r.municipality),'zone':int(r.zone),'section':int(r.section),
       'attendance':int(r.attendance),'bweb_opened':r.opened,'bweb_closed':r.closed,'apuration_status_code':int(r.apuration_status_code),
       'archive_matching_members':ms,'matching_log_members':logs,'missing_log_confirmed_in_central_directory':not logs})
  print(json.dumps({'at':now(),'archive':key,'checked_missing':len(missing)}),flush=True)
 result={'at':now(),'status':'missing_log_central_directory_audit','output_folder':str(out.relative_to(ROOT)),
  'checked_sections':len(cases),'absences_confirmed':sum(x['missing_log_confirmed_in_central_directory'] for x in cases),
  'unexpected_log_members':sum(len(x['matching_log_members']) for x in cases),'cases':cases,'archives':archives,
  'notes':['ZIPs were read by Range in RAM; no full large ZIP was saved locally.',
   'Absence of a matching log member is a coverage gap. The reason is not inferred from apuration status or missing time fields.',
   'Presence of other BU/RDV/image members does not supply a missing voter-completion clock.'],
  'code_sha256':digest(ROOT/'scripts/audit_missing_log_members.py')}
 atomic_json(out/'audit.json',result);atomic_json(ROOT/'reports/missing-log-member-audit.json',result)
 print(json.dumps({k:result[k] for k in ['checked_sections','absences_confirmed','unexpected_log_members']}))
if __name__=='__main__':main()
