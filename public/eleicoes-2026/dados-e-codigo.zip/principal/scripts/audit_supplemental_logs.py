"""Retained cross-round evidence and date-specific malformed-line diagnostics.

No primary measurement is changed. Never merge completion arrays across source
packages: identical timestamps are insufficient to decide event identity.
"""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

import pandas as pd
import pyarrow.parquet as pq

from analysis_common import ROOT, archive, atomic_json, digest, inputs, now
from derive_temporal_features import native_metrics
from extract_native_logs import DATES
from parse_urna_logs import HEADER, COMPLETED, texts_in_package
from parse_urna_logs_legacy import to_parser_container

OUT = ROOT / 'analysis/source-audit/supplemental-log-review-v1'


def native_folder(year, turn, uf):
    root = ROOT / ('analysis/derived/native-logs-v1' if year == 2026 else 'analysis/derived/native-logs-history-v2')
    return root / str(year) / f'bu_imgbu_logjez_rdv_vscmr_{year}_{turn}t_{uf}'


def malformed(payload, member):
    converted = to_parser_container(payload, counters={})
    rows = []
    for name, data in texts_in_package(converted, member, Counter()):
        for lineno, line in enumerate(data.splitlines(), 1):
            if HEADER.fullmatch(line):
                continue
            date_match = re.match(rb'^(\d{2}/\d{2}/\d{4})(?: (\d{2}:\d{2}:\d{2}))?', line)
            if not date_match:
                continue
            fields = line.split(b'\t')
            message = fields[5] if len(fields) >= 6 else line
            lower = message.decode('latin1').lower()
            rows.append({'text_member': name, 'line': lineno, 'date': date_match[1].decode(),
                'time': date_match[2].decode() if date_match[2] else None,
                'bytes': len(line), 'sha256': hashlib.sha256(line).hexdigest(), 'tab_fields': len(fields),
                'nul_bytes': line.count(b'\x00'), 'completion_event_phrase': COMPLETED.encode('latin1') in line,
                'clock_or_adjustment_phrase': any(x in lower for x in ['relógio', 'relogio', 'ajust']),
                'office_confirmation_phrase': 'voto confirmado para' in lower,
                'final_field_length': len(fields[-1]),
                'final_field_is_hex': bool(re.fullmatch(rb'[0-9a-fA-F]+', fields[-1]))})
    return rows


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    index = {r['path']: r for r in inputs()}
    supplement, malformed_outputs, pending = [], [], []
    for mp in sorted((ROOT / 'analysis/derived/temporal-features-v1').glob('*/*/complete.json')):
        meta = json.loads(mp.read_text())
        if not meta.get('outputs'):
            continue
        year, turn, uf = meta['year'], meta['round'], meta['uf']
        feature = mp.parent / 'sections.parquet'
        assert digest(feature) == next(x['sha256'] for x in meta['outputs'] if x['path'].endswith('sections.parquet'))
        f = pd.read_parquet(feature)
        unusual = f[f.log_present & ((f.day_unparsed_target_date_lines > 0) | (f.day_invalid_clock_lines > 0))]
        dest = OUT / f'{year}-{turn}t-{uf}-malformed.json'
        if len(unusual):
            if not dest.exists():
                source = f'raw/{year}/arquivos_urna/bu_imgbu_logjez_rdv_vscmr_{year}_{turn}t_{uf}.zip'
                cases = []
                with archive(index[source]) as (z, stats):
                    for row in unusual.to_dict('records'):
                        payload = z.read(row['source_member'])
                        cases.append({'section': [int(row[k]) for k in ['municipality', 'zone', 'section']],
                            'source_member': row['source_member'], 'source_package_sha256': hashlib.sha256(payload).hexdigest(),
                            'bweb_attendance': int(row['attendance']), 'computed_count': int(row['day_observed_completions']),
                            'malformed_lines': malformed(payload, row['source_member'])})
                atomic_json(dest, {'at': now(), 'source': source, 'source_sha256': index[source]['hashes']['sha256'],
                    'cases': cases, 'read': stats, 'note': 'Package-level flags can include other dates. Diagnostics retain hashes and structure, not message identifiers.'})
            malformed_outputs.append(str(dest.relative_to(ROOT)))
        if turn != 1:
            continue
        bad = f[f.bweb_present & (~f.log_present | f.count_difference_day.ne(0))]
        if bad.empty:
            continue
        secondary_manifest = native_folder(year, 2, uf) / 'complete.json'
        if not secondary_manifest.exists():
            pending.append({'year': year, 'uf': uf, 'cases': len(bad), 'reason': 'second_turn_package_not_yet_extracted'})
            continue
        secondary = json.loads(secondary_manifest.read_text())
        if secondary['status'] == 'complete_no_sections':
            pending.append({'year': year, 'uf': uf, 'cases': len(bad), 'reason': 'no_second_turn_election_for_this_UF'})
            continue
        bykey = {tuple(int(r[k]) for k in ['municipality', 'zone', 'section']): r for r in bad.to_dict('records')}
        target = OUT / f'{year}-1t-{uf}-secondary-source.json'
        if target.exists():
            supplement.append(str(target.relative_to(ROOT)))
            continue
        records = []
        for batch in secondary['batches']:
            path = ROOT / batch['path']
            if digest(path) != batch['sha256']:
                raise ValueError('Secondary extract changed')
            for group in pq.ParquetFile(path).iter_batches(batch_size=200):
                for r in group.to_pylist():
                    key = tuple(int(r[k]) for k in ['municipality', 'zone', 'section'])
                    if key not in bykey or r['event_date'] != DATES[year][1]:
                        continue
                    b = bykey[key]
                    deadline = b['ordinary_deadline_local_seconds']
                    deadline = None if pd.isna(deadline) else float(deadline)
                    met, _ = native_metrics(r, 0, deadline)
                    acceptable = (met['observed_completions'] == b['attendance'] and met['clock_backwards_count'] == 0
                                  and met['unparsed_target_date_lines'] == 0 and met['invalid_clock_lines'] == 0)
                    records.append({'section': list(key), 'event_date': r['event_date'],
                        'primary_log_present': bool(b['log_present']), 'primary_count': int(b['day_observed_completions']) if b['log_present'] else None,
                        'bweb_attendance': int(b['attendance']), 'secondary_package_sha256': r['package_sha256'],
                        'secondary_member': r['source_member'], 'secondary_batch': batch, 'metrics': met,
                        'header_ids': r['machine_ids'], 'header_matches_first_turn_bweb': int(b['machine']) in r['machine_ids'],
                        'candidate_for_supplemental_sensitivity': bool(acceptable),
                        'note': 'Not merged with or substituted into primary results. Header identity is separately reported; known2022constant-header caveat applies.'})
        found = {tuple(r['section']) for r in records}
        atomic_json(target, {'at': now(), 'year': year, 'round': 1, 'uf': uf,
            'primary_feature_manifest': str(mp.relative_to(ROOT)), 'primary_feature_manifest_sha256': digest(mp),
            'secondary_manifest': str(secondary_manifest.relative_to(ROOT)), 'secondary_manifest_sha256': digest(secondary_manifest),
            'requested_cases': len(bad), 'secondary_records': records, 'missing_from_secondary': [list(k) for k in bykey if k not in found],
            'acceptable_supplemental_cases': sum(r['candidate_for_supplemental_sensitivity'] for r in records),
            'limitations': ['First-turn event date is selected from a second-turn envelope. A count match alone is not proof of all clock values.',
                            'Supplemental sensitivity is distinct from the primary archived first-turn analysis.']})
        supplement.append(str(target.relative_to(ROOT)))
    result = {'at': now(), 'status': 'partial_completed_archives_reviewed', 'supplemental_reports': supplement,
              'malformed_line_reports': malformed_outputs, 'pending_archives': pending}
    atomic_json(ROOT / 'reports/supplemental-log-review-state.json', result)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
