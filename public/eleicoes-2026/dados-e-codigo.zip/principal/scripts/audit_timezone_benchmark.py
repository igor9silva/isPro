"""Exploratory falsification of uniform-UF timezone handling against municipal rules."""
import json,time
import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from analysis_common import ROOT,atomic_json,digest,now

def main():
 out=ROOT/'analysis/source-audit/timezone-benchmark-v1'/str(time.time_ns());out.mkdir(parents=True,exist_ok=False)
 records=[];sources=[]
 for uf in ['AM','PE']:
  mp=next((ROOT/'analysis/derived/native-logs-v1/2026').glob(f'*2t*{uf}/complete.json'));m=json.loads(mp.read_text())
  g=pd.read_parquet(ROOT/f'analysis/derived/temporal-reviewed-v1/2026/2t-{uf}/sections.parquet').set_index(['municipality','zone','section'])
  if g.context_qualified_change.any():raise ValueError('Must explicitly account for reviewed context changes')
  sources.append({'path':str(mp.relative_to(ROOT)),'sha256':digest(mp)})
  seen=set()
  for b in m['batches']:
   p=ROOT/b['path']
   if digest(p)!=b['sha256']:raise ValueError('Native batch changed')
   batch=pq.read_table(p,columns=['event_date','municipality','zone','section','computed_seconds']).to_pylist()
   for r in batch:
    if r['event_date']!='25/10/2026':continue
    key=(r['municipality'],r['zone'],r['section'])
    if key in seen:raise ValueError('Duplicate target section')
    seen.add(key)
    if key not in g.index:raise ValueError('Section outside BWeb')
    x=g.loc[key];secs=np.asarray(r['computed_seconds'],dtype='int64')
    if len(secs)!=int(x.reviewed_observed_completions):raise ValueError('Event population differs')
    for mapping,deadline in [('municipality_rules',int(x.ordinary_deadline_local_seconds)),('uniform_uf_diagnostic',16*3600 if uf=='AM' else 17*3600)]:
     counts=[int((secs>=deadline+s).sum()) for s in [0,3600,7200]]
     row={'uf':uf,'municipality':key[0],'zone':key[1],'section':key[2],'municipality_name':x.municipality_name,
          'mapping':mapping,'deadline_seconds':deadline,'opened_seconds':x.opened_elapsed_seconds,
          'first_completed_second':x.reviewed_first_completed_second,'count':len(secs),'after17':counts[0],
          '17_18':counts[0]-counts[1],'18_19':counts[1]-counts[2],'after19':counts[2]}
     for field in ['closed_elapsed_seconds','emitted_elapsed_seconds','day_closing_started_last','day_closing_confirmed_last']:
      for delta in [0,600,7200]:row[f'{field}_gt{delta}']=bool(x[field]>deadline+delta)
     records.append(row)
 a=pd.DataFrame(records);a.to_parquet(out/'section-diagnostic.parquet',index=False,compression='zstd')
 national=a.groupby(['uf','mapping'])[['after17','17_18','18_19','after19']].sum().reset_index()
 national.to_csv(out/'uf-timezone-totals.csv',index=False)
 results=[]
 for (uf,mapping),g in a.groupby(['uf','mapping']):
  for field in ['closed_elapsed_seconds','emitted_elapsed_seconds','day_closing_started_last','day_closing_confirmed_last']:
   for delta in [0,600,7200]:
    x=g[g[f'{field}_gt{delta}']]
    results.append({'uf':uf,'mapping':mapping,'timestamp':field,'delta_seconds':delta,'sections':len(x),**{k:int(x[k].sum()) for k in ['after17','17_18','18_19','after19']}})
 pd.DataFrame(results).to_csv(out/'uf-cohort-diagnostic.csv',index=False)
 changed=a.pivot(index=['uf','municipality','zone','section'],columns='mapping',values='after17').reset_index()
 changed=changed[changed.municipality_rules!=changed.uniform_uf_diagnostic]
 changed.to_csv(out/'section-count-changes.csv',index=False)
 summary={'at':now(),'status':'exploratory_timezone_diagnostic_not_primary_measurement','output_folder':str(out.relative_to(ROOT)),
          'input_manifests':sources,'totals':json.loads(national.to_json(orient='records')),
          'interpretation':['Primary clock conversion uses official municipality-specific schedules corroborated by local opening times.',
           'Uniform-UF conversion is a diagnostic deliberately conflicting with known within-UF zones; it does not replace primary counts.',
           'Agreement of aggregates under the diagnostic would be consistent with a timezone aggregation difference, not proof of the TSE internal algorithm.'],
          'code_sha256':digest(ROOT/'scripts/audit_timezone_benchmark.py'),
          'outputs':[{'path':str(p.relative_to(ROOT)),'sha256':digest(p)} for p in out.iterdir()]}
 atomic_json(out/'audit.json',summary);atomic_json(ROOT/'reports/timezone-benchmark-audit.json',summary)
 print(national.to_json(orient='records'))
if __name__=='__main__':main()
