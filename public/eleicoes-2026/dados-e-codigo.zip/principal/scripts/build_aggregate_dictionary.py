"""Describe each aggregate CSV field, denominator and observational unit."""
import csv
import json
import time
from analysis_common import ROOT, atomic_json, digest, now

REPORTS = ['temporal-population-state', 'margin-scenario-state', 'intercompletion-state',
           'election-comparison-state', 'closure-selection-state', 'context-sampling-bounds-state',
           'supplemental-sensitivity-state', 'documentary-time-window-state']

# Definitions are shared only where the measure has the same semantics.
TEXT = {
    'year': 'Ano da eleição.', 'round': 'Turno eleitoral (1 ou 2).',
    'uf': 'UF; ZZ identifica exterior, que recebe tratamento temporal separado.',
    'scope': 'Universo territorial: doméstico ou exterior.',
    'municipality': 'Código eleitoral do município, não código IBGE.',
    'municipality_name': 'Nome do município no BWeb.',
    'zone': 'Zona eleitoral.', 'section': 'Seção eleitoral; unidade do arquivo pode agregar outras seções.',
    'sections': 'Número de seções presentes no grupo ou cenário definido na linha.',
    'eligible': 'Soma do eleitorado apto nas seções do grupo.',
    'attendance': 'Soma do comparecimento nas seções e cargo de referência do grupo.',
    'abstention': 'Soma das abstenções; aptos menos comparecimento.',
    'sections_with_logs': 'Seções com membro de log presente no arquivo nativo.',
    'sections_count_reconciled': 'Seções cujo total de conclusões próprias no dia coincide com comparecimento.',
    'missing_log_sections': 'Seções BWeb sem membro de log localizado.',
    'missing_log_attendance': 'Comparecimento total nas seções sem log.',
    'count_mismatch_sections': 'Seções com log e contagem de conclusões diferente do comparecimento.',
    'recorded_completions': 'Conclusões de votação na data do pleito, após revisão de contexto.',
    'unobserved_count_gap_if_no_spurious': 'Soma de max(comparecimento menos conclusões próprias, 0); inclui comparecimento integral sem log e supõe ausência de eventos espúrios.',
    'strict_time_sections': 'Seções com contexto/contagem/dia corretos, sem flags de parsing ou reversão de relógio; não certifica tempo absoluto.',
    'startup_allowed_sections': 'Como conjunto estrito, admitindo reversões observadas apenas antes da primeira conclusão no texto.',
    'context_changed_sections': 'Seções cuja medição primária foi alterada pela revisão explícita de identidade interna.',
    'context_foreign_events_removed': 'Conclusões de outro contexto de seção removidas da medida revisada.',
    'clock_reversal_sections': 'Seções com ao menos uma reversão temporal registrada.',
    'clock_reversal_after_completion_sections': 'Seções com reversão após uma conclusão no mesmo texto inspecionado.',
    'turnout_percent': '100 vezes comparecimento dividido por aptos; razão de somas, não média das taxas.',
    'recorded_strict_post_deadline': 'Conclusões estritamente posteriores ao prazo ordinário municipal convertido para a escala comum.',
    'recorded_inclusive_post_deadline': 'Conclusões no instante exato do prazo ordinário ou posteriores.',
    'exact_deadline_events': 'Conclusões com timestamp exatamente no prazo ordinário.',
    'recorded_17_18': 'Conclusões em (17h,18h] na escala do prazo ordinário doméstico.',
    'recorded_18_19': 'Conclusões em (18h,19h] na escala do prazo ordinário doméstico.',
    'recorded_after_19': 'Conclusões estritamente depois de 19h na escala doméstica.',
    'post_deadline_sections': 'Seções com uma ou mais conclusões estritamente tardias.',
    'strict_subset_late': 'Conclusões tardias somente no conjunto de qualidade temporal estrito.',
    'startup_allowed_subset_late': 'Conclusões tardias no conjunto que admite reversões apenas iniciais.',
    'recorded_post_deadline_percent_of_attendance': '100 vezes conclusões estritamente tardias dividido por comparecimento do grupo completo.',
    'comparison': 'Família descritiva de comparação, sem interpretação causal.',
    'pair_definition': 'Regra de vinculação/exclusão: chaves, metadados, reconciliação, relógios ou estabilidade de eleitorado.',
    'paired_sections': 'Seções com par válido segundo a regra da linha.',
    'a_only_sections': 'Chaves existentes apenas no universo A antes das restrições de qualidade.',
    'b_only_sections': 'Chaves existentes apenas no universo B antes das restrições de qualidade.',
    'recorded_late': 'Conclusões posteriores ao corte da linha no subconjunto especificado.',
    'late_percent_attendance': '100 vezes conclusões tardias dividido por comparecimento no conjunto vinculado.',
    'mean_section_late_fraction': 'Média não ponderada de conclusões tardias / comparecimento; omite denominador zero.',
    'late_in_both': 'Pares com conclusões tardias em ambos os momentos.',
    'late_only_a': 'Pares com conclusões tardias apenas em A.',
    'late_only_b': 'Pares com conclusões tardias apenas em B.',
    'interpretation': 'Ressalva ou regra de interpretação da linha.',
    'expected_sections': 'Seções esperadas no BWeb para o cargo de referência.',
    'included_sections': 'Seções efetivamente incluídas no estimador ou camada indicada.',
    'excluded_sections': 'Seções fora do conjunto de qualidade do estimador.',
    'all_sections': 'Seções do universo de referência antes das exclusões.',
    'included_attendance': 'Comparecimento das seções incluídas no estimador.',
    'all_attendance': 'Comparecimento de todo o universo de referência.',
    'expected_ufs': 'Número de UFs esperadas no BWeb.', 'included_ufs': 'Número de UFs incluídas.',
    'population_complete': 'Igualdade entre contagem esperada e incluída; acompanhada das verificações de chaves do pipeline.',
    'missing_ufs': 'UFs esperadas sem tabela incluída.',
    'cutoff_seconds_after_ordinary': 'Deslocamento do corte em segundos após o prazo ordinário; negativo antecipa.',
    'population': 'Subconjunto de qualidade; na tabela de auditoria, tamanho N da população finita previamente não inspecionada.',
    'minutes_after_ordinary_deadline': 'Piso de (timestamp menos prazo ordinário) / 60; cada bin inclui seu início e exclui o próximo.',
    'completions': 'Contagem de conclusões de votação no bin temporal.',
    'indicator': 'Indicador operacional observado: boots múltiplos, arquivo aninhado, suspensão sem voto ou abertura mais de cinco minutos atrasada.',
    'present': 'Se o indicador operacional está presente no grupo.',
    'race': 'Disputa: Brasil/presidente ou UF/governador.', 'winner': 'Nome do candidato com mais votos nominais finais.',
    'runner_up': 'Nome do segundo candidato nos votos nominais finais.',
    'winner_votes': 'Votos nominais finais do vencedor; não são votos em faixa horária.',
    'runner_up_votes': 'Votos nominais finais do segundo colocado; não são votos em faixa horária.',
    'observed_margin': 'Votos nominais finais do vencedor menos os do segundo colocado.',
    'primary_office_attendance_differs': 'Seções cuja contagem de comparecimento do cargo difere do cargo de referência temporal.',
    'scenario': 'Regra de teto por seção: registros mais lacunas, ou casos não qualificados admitidos integralmente.',
    'cutoff_shift_earlier_seconds': 'Segundos de antecipação do corte em relação ao prazo ordinário (0,60,300,900).',
    'deadline_boundary': 'Convenção inclusiva/estrita do corte; zero inclui o instante exato do prazo.',
    'overseas_policy': 'Regra conservadora do exterior: todo comparecimento pode integrar o teto presidencial.',
    'possible_added_voters_cap': 'Soma dos tetos K_i de participantes adicionais sob hipóteses do cenário; não é efeito estimado.',
    'maximum_adverse_margin_change': 'Soma de min(votos finais do vencedor na seção, K_i).',
    'maximum_favorable_margin_change': 'Soma de min(votos finais do segundo colocado na seção, K_i).',
    'minimum_counterfactual_margin': 'Margem observada menos maior redução admissível sob remoção de participantes adicionais.',
    'maximum_counterfactual_margin': 'Margem observada mais maior aumento admissível sob remoção de participantes adicionais.',
    'reversal_ruled_out_under_scenario': 'Margem contrafactual inferior positiva, somente sob as hipóteses do cenário.',
    'sections_with_positive_cap': 'Seções com K_i maior que zero.',
    'setting': 'Configuração de cargos: primeiro turno geral, presidente e governador, apenas presidente ou municipal.',
    'intervals': 'Número de intervalos entre conclusões consecutivas ordenadas na mesma seção e data.',
    'median_interval_seconds': 'Mediana dos intervalos agrupados, ponderada pelo número de intervalos; bin acima de 900s censurado.',
    'p90_interval_seconds': 'Percentil 90 dos intervalos agrupados; bin acima de 900s censurado.',
    'p95_interval_seconds': 'Percentil 95 dos intervalos agrupados; bin acima de 900s censurado.',
    'median_conditional_gap_le120': 'Mediana dos intervalos condicionada a intervalo até 120 segundos; não mede fila.',
    'median_conditional_gap_le300': 'Mediana dos intervalos condicionada a intervalo até 300 segundos; não mede fila.',
    'intervals_over900_seconds': 'Intervalos estritamente superiores a 900 segundos.',
    'zero_second_intervals': 'Pares de conclusões consecutivas no mesmo segundo, preservados.',
    'mean_interval_seconds': 'Soma exata de durações / número de intervalos; a média não usa o bin censurado.',
    'mean_section_median_seconds': 'Média não ponderada das medianas de cada seção.',
    'first_turn_only_in_qualified_set': 'Seções qualificadas apenas no primeiro turno.',
    'second_turn_only_in_qualified_set': 'Seções qualificadas apenas no segundo turno.',
    'mean_section_change_median_seconds': 'Média não ponderada da mudança da mediana por seção, segundo menos primeiro turno.',
    'median_section_change_median_seconds': 'Mediana da mudança da mediana por seção, segundo menos primeiro turno.',
    'turnout_weighted': 'Comparecimento / aptos, escala 0 a 1, razão das somas.',
    'turnout_section_mean': 'Média não ponderada de comparecimento / aptos entre seções com aptos positivos.',
    'zero_eligible_sections': 'Seções cujo eleitorado apto é zero.',
    'zero_attendance_sections': 'Seções cujo comparecimento é zero.',
    'usable_close_time_sections': 'Seções com encerramento BWeb interpretável.',
    'closed_more_than_10m_after_deadline': 'Seções encerradas mais de 600s após prazo ordinário do respectivo ano.',
    'closed_more_than_2h_after_deadline': 'Seções encerradas mais de 7200s após prazo ordinário do respectivo ano.',
    'median_close_seconds_after_deadline': 'Mediana do encerramento BWeb menos prazo ordinário em segundos.',
    'old_year': 'Ano anterior na comparação municipal.', 'new_year': 'Ano posterior na comparação municipal.',
    'linked': 'Municípios vinculados por UF e código eleitoral.', 'old_only': 'Municípios encontrados apenas no ano anterior.',
    'new_only': 'Municípios encontrados apenas no ano posterior.',
    'name_changed_in_linked': 'Vínculos de código cujo nome municipal difere.',
    'pairs': 'Seções vinculadas sob a definição especificada.',
    'weighted_turnout_change_pp': 'Diferença segundo menos primeiro turno entre razões de somas, em pontos percentuais.',
    'mean_section_turnout_change_pp': 'Média das mudanças individuais de participação de seção, em pontos percentuais.',
    'median_section_turnout_change_pp': 'Mediana das mudanças de participação de seção, em pontos percentuais.',
    'median_close_time_change_seconds': 'Mediana da mudança de encerramento em segundos entre turnos.',
    'same_eligible_pairs': 'Pares com eleitorado apto idêntico nos dois turnos.',
    'round1_only_sections': 'Seções apenas no primeiro turno antes de restrições.',
    'round2_only_sections': 'Seções apenas no segundo turno antes de restrições.',
    'late_closure_cutoff_seconds': 'Corte em segundos depois do prazo ordinário para definir coorte de encerramento tardio.',
    'weighting': 'Ponderação: seção, aptos ou comparecimento segundo o arquivo de origem.',
    'first_round_variable': 'Variável medida no primeiro turno para comparar coortes definidas no segundo.',
    'late_group_n': 'Seções da coorte de encerramento tardio com medida válida.',
    'earlier_group_n': 'Seções da coorte restante com medida válida.',
    'late_mean': 'Média ponderada da variável anterior na coorte tardia.',
    'earlier_mean': 'Média ponderada da variável anterior na coorte restante.',
    'difference': 'Média da coorte tardia menos média da restante, na unidade da variável.',
    'standardized_mean_difference': 'Diferença entre médias dividida pelo desvio padrão combinado; descrição de seleção, não teste de tratamento.',
    'cutoff_seconds': 'Corte após prazo ordinário para a coorte de encerramento.',
    'late_sections': 'Seções da coorte tardia na UF.',
    'late_fraction': 'Seções tardias / seções vinculadas na UF.',
    'eligible_round1': 'Aptos no primeiro turno nas seções vinculadas.',
    'eligible_round1_in_late_cohort': 'Aptos no primeiro turno apenas na futura coorte tardia.',
    'unsampled_sections': 'Complemento da amostra no quadro de contextos antes não auditados.',
    'upper_identity_errors': 'Limite superior de número de falhas de identidade no estrato, por inversão hipergeométrica.',
    'extra_adverse_votes': 'Soma das maiores contribuições presidenciais residuais possíveis nas seções do complemento, até o limite de falhas.',
    'base_conditional_adverse_bound': 'Maior redução de margem no cenário básico de qualidade estrita, antes da incerteza amostral.',
    'additional_adverse_bound_from_context_sampling': 'Acréscimo conservador por possíveis falhas de contexto nas seções não amostradas.',
    'minimum_counterfactual_margin_with_audit_uncertainty': 'Margem observada menos limite básico e acréscimo da auditoria; condicionado ao mecanismo.',
    'audit_joint_coverage_level': 'Cobertura simultânea nominal do procedimento para falhas de identidade, não para efeito causal.',
    'not_an_effect_confidence_interval': 'Marcador explícito de que a faixa não é um intervalo de confiança do efeito causal.',
    'sample_size': 'Pacotes inspecionados no estrato (n).',
    'observed_identity_failures': 'Pacotes que falharam na regra de detecção de identidade/contexto.',
    'is_census': 'Todos os N pacotes do quadro do estrato foram inspecionados.',
    'alpha': 'Nível unilateral usado na inversão; 0,05/21 na família doméstica amostral do segundo turno.',
    'upper_possible_identity_failures': 'Maior total K não rejeitado pela cauda hipergeométrica unilateral.',
    'simultaneous_domestic_second_turn_family': 'Estrato integra a família doméstica do segundo turno; censos são determinísticos.',
    'family_probability_strata': 'Número de estratos probabilísticos da família simultânea (21).',
    'phase_not_explicit': 'Pacotes inspecionados sem declaração explícita de fase, preservada como ressalva.',
    'turn_not_explicit': 'Pacotes inspecionados sem declaração explícita de turno, preservada como ressalva.',
    'decision': 'Decisão da regra de sensibilidade histórica; não altera a medida primária.',
    'primary_log_present': 'O pacote primário de primeiro turno existe.',
    'primary_completions': 'Conclusões próprias da camada primária revisada.',
    'retained_target_completions': 'Conclusões do primeiro turno e seção corretos no pacote retido do segundo turno.',
    'secondary_foreign_excluded': 'Conclusões de outras seções presentes na retenção e excluídas.',
    'alternative_completions': 'Conclusões na sensibilidade separada de fonte secundária.',
    'additional_reconstructed_completions': 'Conclusões adicionais reconstruídas na sensibilidade, sem interpretação causal.',
    'primary_gap': 'Déficit de conclusões primárias em relação ao comparecimento, limitado inferiormente por zero.',
    'alternative_gap': 'Déficit de conclusões na sensibilidade em relação ao comparecimento.',
    'alternative_excess': 'Excesso de conclusões alternativas sobre comparecimento; não é truncado na sequência original.',
    'primary_strict_late': 'Conclusões estritamente tardias na camada primária.',
    'alternative_strict_late': 'Conclusões estritamente tardias na sensibilidade.',
    'additional_reconstructed_strict_late': 'Mudança de conclusões tardias por recuperação histórica, não efeito eleitoral.',
    'repeated_second_events_retained': 'Eventos com segundo já observado na mesma sequência; preservados como eventos distintos.',
    'primary_event_overlap_count': 'Zero nos casos aceitos, pois só primários com zero conclusões recebem substituição; indefinido nos outros.',
    'evidence': 'Caminho relativo do registro de evidência.', 'evidence_sha256': 'SHA256 do registro de evidência.',
    'territory': 'UF ou conjunto doméstico nacional.', 'marker_brasilia': 'Horário documental na escala de Brasília, não comunicação por seção.',
    'documentary_meaning': 'Natureza e ressalva do marcador documental.',
    'completions_strictly_after_lower': 'Conclusões após o minuto do marcador; limite inferior conservador para os segundos não resolvidos.',
    'completions_strictly_after_upper': 'Limite superior incluindo o minuto do marcador quando os segundos não estão resolvidos.',
    'events_in_unresolved_marker_minute': 'Conclusões no minuto que gera a diferença entre limites.',
    'exact_at_available_precision': 'O marcador cai no último segundo do minuto, permitindo contagem estrita exata com os bins.',
    'is_section_exposure_time': 'Sempre falso: o marcador não identifica exposição causal por seção.'
}


def describe(field):
    if field in TEXT:
        return TEXT[field]
    for suffix, label in [('_a', 'momento A'), ('_b', 'momento B'), ('_1', 'primeiro turno'), ('_2', 'segundo turno')]:
        if field.endswith(suffix) and field[:-len(suffix)] in TEXT:
            return TEXT[field[:-len(suffix)]] + ' Referente ao ' + label + '.'
    raise ValueError('Undefined aggregate field: ' + field)


def main():
    out = ROOT / 'analysis/dictionaries/aggregate-v1' / str(time.time_ns())
    out.mkdir(parents=True, exist_ok=False)
    records, datasets = [], []
    for name in REPORTS:
        rp = ROOT / f'reports/{name}.json'
        state = json.loads(rp.read_text())
        folder = ROOT / state.get('output_folder', state.get('folder'))
        for p in sorted(folder.glob('*.csv')):
            with p.open() as f:
                reader = csv.reader(f)
                columns = next(reader)
                count = sum(1 for _ in reader)
            dataset = name + '/' + p.name
            datasets.append({'dataset': dataset, 'path': str(p.relative_to(ROOT)), 'sha256': digest(p), 'rows': count,
                'row_unit': 'Uma combinação das chaves e/ou cenário indicados nas colunas; nenhuma linha representa preferência individual.'})
            for field in columns:
                definition = describe(field)
                if field == 'population' and name == 'context-sampling-bounds-state':
                    definition = 'N: tamanho finito do quadro do estrato antes da amostra, excluídas as inspeções anteriores.'
                records.append({'dataset': dataset, 'field': field, 'definition_pt': definition,
                    'missing_convention': 'Campo vazio significa indefinido, não observado ou não aplicável; nunca converter automaticamente em zero.',
                    'denominator_policy': 'Taxas usam o denominador definido no campo; contagens de eventos não são efeito causal.'})
    with (out / 'aggregate-data-dictionary.csv').open('w') as f:
        writer = csv.DictWriter(f, fieldnames=list(records[0])); writer.writeheader(); writer.writerows(records)
    atomic_json(out / 'aggregate-data-dictionary.json', {'fields': records, 'datasets': datasets})
    result = {'at': now(), 'status': 'all_aggregate_csv_columns_defined', 'output_folder': str(out.relative_to(ROOT)),
              'datasets': len(datasets), 'entries': len(records), 'unique_fields': len({r['field'] for r in records}),
              'code_sha256': digest(ROOT / 'scripts/build_aggregate_dictionary.py'), 'dataset_manifest': datasets}
    atomic_json(out / 'manifest.json', result)
    atomic_json(ROOT / 'reports/aggregate-data-dictionary-state.json', result)
    print(json.dumps({k:v for k,v in result.items() if k != 'dataset_manifest'}))


if __name__ == '__main__':
    main()
