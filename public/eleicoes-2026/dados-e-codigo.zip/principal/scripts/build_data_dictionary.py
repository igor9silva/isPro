"""Explicit definitions for canonical section and reviewed temporal columns."""
import json,re,time
import pandas as pd
import pyarrow.parquet as pq
from analysis_common import ROOT,atomic_json,digest,now

BASE={
'year':'Ano eleitoral.', 'round':'Turno eleitoral (1 ou 2).', 'uf':'UF; ZZ identifica o exterior.',
'election':'Código da eleição no produto BWeb.', 'municipality':'Código de município eleitoral do TSE; não presumir código IBGE.',
'zone':'Número da zona eleitoral.', 'section':'Número da seção eleitoral dentro da zona e município.',
'office':'Código do cargo: 1 presidente, 3 governador, 11 prefeito nos derivados executivos.',
'pleito':'Código do pleito no BWeb.', 'municipality_name':'Nome do município no produto de origem.',
'polling_place':'Código do local de votação no BWeb.', 'office_name':'Descrição do cargo no BWeb.',
'eligible':'Eleitorado apto informado para a seção e cargo.', 'attendance':'Comparecimento informado para a seção e cargo; pode diferir entre cargos.',
'abstention':'Abstenção informada na seção e cargo.', 'machine':'Número de urna informado no BWeb; correspondência com cabeçalho de log exige validação.',
'machine_type':'Código de situação de apuração (CD_TIPO_URNA), não modelo físico de hardware.',
'apuration_status_code':'Alias explícito de CD_TIPO_URNA: 1 apurada; 2 não apurada; 3 anulada/apurada separado; 4 anulada; 5 não instalada.',
'opened':'Data/hora local de abertura registrada no BWeb.', 'closed':'Data/hora local de encerramento registrada no BWeb.',
'emitted':'Data/hora local de emissão do BU no BWeb.', 'received':'Data/hora de recebimento registrada no produto BWeb; não presumir horário de voto ou comunicação judicial.',
'election_date':'Data eleitoral no produto de origem.', 'aggregated_sections':'Representação das seções agregadas no BWeb.',
'biometry_without_auth':'Quantidade indicada no BWeb de habilitações biométricas sem autenticação.',
'candidate_rows':'Número de linhas de votáveis na agregação seção-cargo.', 'distinct_votables':'Quantidade de códigos de votável distintos.',
'total_votes':'Soma de votos de todas as categorias na seção-cargo.', 'nominal_votes':'Soma dos votos nominais em candidatos.',
'blank_votes':'Soma dos votos em branco.', 'null_votes':'Soma dos votos nulos, conforme classificação do produto.',
'invalid_vote_rows':'Linhas com votos inválidos para agregação, após revisão explícita dos placeholders de zero voto.',
'source_archives':'Quantidade de arquivos BWeb de origem da seção-cargo.', 'source_path':'Caminho do arquivo de origem no catálogo privado.',
'metadata_conflict':'Indicador de mais de um valor incompatível nos metadados agrupados da seção-cargo.',
'duplicate_votable_rows':'Repetições de códigos de votável após revisão dos placeholders de zero voto; não é automaticamente duplicação de votos.',
'electorate_identity_ok':'Verifica a identidade aptos = comparecimento + abstenção.',
'votes_attendance_identity_ok':'Verifica a identidade soma de votos por categoria = comparecimento do cargo.',
'usable_turnout':'Flag original de qualidade para participação; na versão 2, consultar usable_turnout_rate após revisão dos placeholders.',
'turnout_rate':'Razão comparecimento/aptos, sem interpretação causal.',
'usable_turnout_rate':'Flag revista de qualidade para análise de participação, após revisão dos placeholders.',
'offset_to_brasilia_seconds':'Segundos somados ao relógio local para obter Brasília no território doméstico; exterior não inferido.',
'ordinary_deadline_local_seconds':'Prazo ordinário em segundos após meia-noite local; regra varia por ano e município.',
'timing_convention':'Rótulo da convenção temporal armazenado no estágio original; a validação posterior está na trilha metodológica, não altera silenciosamente esse texto.',
'opened_elapsed_seconds':'Segundos entre a abertura BWeb e a meia-noite da data eleitoral local.',
'closed_elapsed_seconds':'Segundos entre o encerramento BWeb e a meia-noite da data eleitoral local.',
'emitted_elapsed_seconds':'Segundos entre a emissão BWeb e a meia-noite da data eleitoral local.',
'close_seconds_after_ordinary_deadline':'Encerramento BWeb menos prazo ordinário, em segundos.',
'open_seconds_after_ordinary_start':'Abertura BWeb menos início ordinário equivalente (prazo menos nove horas), em segundos.',
'usable_timing':'Flag de disponibilidade/coerência temporal BWeb doméstica; não certifica a exatidão do relógio.',
'legacy_duplicate_votable_rows':'Contagem original de repetições de votável, preservada antes da revisão dos placeholders.',
'legacy_invalid_vote_rows':'Contagem original de linhas inválidas, preservada antes da revisão dos placeholders.',
'zero_vote_placeholder':'Indicador de registro com zero voto e código ausente tratado explicitamente como placeholder.',
'source_member':'Nome do membro dentro do arquivo nativo.', 'source_package_sha256':'SHA256 calculado dos bytes do pacote de log; não é automaticamente comparação oficial.',
'coverage':'Resultado do vínculo: both, left_only (apenas BWeb), right_only (apenas log).',
'log_present':'Há pacote de log correspondente à seção.', 'bweb_present':'Há linha BWeb correspondente à seção.',
'count_matches_day':'Conclusões primárias no dia eleitoral iguais ao comparecimento do cargo primário.',
'count_matches_two_days':'Conclusões primárias no dia eleitoral e seguinte iguais ao comparecimento.',
'count_difference_day':'Conclusões primárias no dia eleitoral menos comparecimento.',
'unobserved_completions_if_no_spurious':'Lacuna positiva de comparecimento menos conclusões, sob ausência de eventos espúrios; não imputa horário.',
'strict_same_day_time_eligible':'Conjunto primário doméstico: contagens reconciliadas, nenhum evento no dia seguinte, reversão de relógio ou erro de parsing/horário.',
'last_vote_minus_bweb_close':'Última conclusão primária menos encerramento BWeb, em segundos.',
'first_vote_minus_bweb_open':'Primeira conclusão primária menos abertura BWeb, em segundos.',
'context_audited':'Conteúdo interno inspecionado pela auditoria inicial de exceções/nesting e amostra determinística; não inclui automaticamente auditoria probabilística posterior.',
'context_known':'Nas seções auditadas, ausência de conclusões com contexto desconhecido/conflitante; nas não auditadas, pressupõe vínculo externo existente. Não significa censo de contexto.',
'context_foreign_completions':'Conclusões explicitamente atribuídas a outra seção/fase/turno na auditoria de contexto.',
'context_unknown_completions':'Conclusões sem contexto interno suficiente na auditoria.',
'context_conflicting_completions':'Conclusões com identidade interna conflitante na auditoria.',
'context_qualified_change':'A medição primária foi substituída pela camada de conclusões do contexto alvo com evidência explícita.',
'clock_diagnostic_available':'Há inspeção específica dos pontos de reversão de relógio.',
'clock_reversals_after_completion_in_text':'Número de reversões que ocorrem depois de ao menos uma conclusão no mesmo texto.',
'startup_reversal_only':'Reversões inspecionadas ocorreram antes de qualquer conclusão no texto e nenhuma ocorreu depois; não garante sincronização absoluta.',
'reviewed_count_matches_day':'Conclusões revistas iguais ao comparecimento, com vínculo presente e contexto não desconhecido/conflitante.',
'reviewed_gap_if_no_spurious':'Máximo entre comparecimento menos conclusões revistas e zero; usa todo comparecimento se não há log. Pressupõe ausência de conclusões espúrias.',
'reviewed_strict_time_eligible':'Conjunto revisto doméstico com contagem reconciliada, sem conclusões no dia seguinte, sem erros de parsing/horário e sem reversões.',
'reviewed_startup_allowed_time_eligible':'Sensibilidade do conjunto revisto que admite somente reversões anteriores à primeira conclusão em cada texto.',
'reviewed_last_vote_minus_bweb_close':'Última conclusão do contexto alvo menos encerramento BWeb, em segundos.',
'operational_context_contaminated':'Há conclusões de contexto estrangeiro, desconhecido ou conflitante; os demais horários operacionais primários não foram corrigidos automaticamente.'}

METRICS={
'observed_completions':'Quantidade de conclusões deduplicadas segundo a identidade dos eventos, sem reduzir eventos distintos no mesmo segundo.',
'at_ordinary_deadline':'Conclusões no segundo exato do prazo ordinário.',
'at_ordinary_plus_3600':'Conclusões no segundo exato de prazo ordinário mais uma hora.',
'at_ordinary_plus_7200':'Conclusões no segundo exato de prazo ordinário mais duas horas.',
'first_completed_second':'Primeiro horário de conclusão, em segundos após meia-noite local da data eleitoral.',
'last_completed_second':'Último horário de conclusão, em segundos após meia-noite local da data eleitoral.',
'raw_computed_count':'Número bruto de eventos de conclusão antes da deduplicação de cópias.',
'duplicate_computed_count':'Cópias repetidas de eventos de conclusão excluídas na deduplicação.',
'clock_backwards_count':'Quantidade de reversões na sequência temporal detectadas pelo parser.',
'largest_backward_seconds':'Maior reversão detectada, em segundos.',
'line_count':'Quantidade de linhas no conjunto de eventos da data.',
'duplicate_line_count':'Quantidade de cópias repetidas de linhas detectadas.',
'alert_error_lines':'Quantidade de linhas com nível de alerta ou erro; não equivale a falha eleitoral comprovada.',
'clock_message_count':'Mensagens reconhecidas sobre relógio.',
'contingency_message_count':'Mensagens reconhecidas sobre contingência; não identificam por si só substituição física.',
'suspension_message_count':'Mensagens reconhecidas sobre suspensão.',
'manual_authorization_count':'Mensagens reconhecidas de habilitação manual.',
'biometric_authorization_count':'Mensagens reconhecidas de habilitação biométrica.',
'text_file_count':'Quantidade de textos de log lidos no pacote; pode incluir outras datas retidas.',
'nested_archive_count':'Quantidade de contêineres aninhados do pacote.',
'unparsed_target_date_lines':'Linhas não interpretadas associadas à data; certos diagnósticos de pacote podem reter outra data, examinada no relatório de exceções.',
'invalid_clock_lines':'Linhas com horário inválido conforme o parser.',
'header_matches_bweb':'Ao menos um identificador do cabeçalho coincide com o número informado no BWeb; não é autenticação física da urna.',
'header_ids_json':'Lista JSON dos identificadores de cabeçalho observados; a constante histórica de 2022 não é serial físico presumido.'}
EVENTS={
'all_present_voted_confirmed':'confirmação de que todos os presentes votaram',
'closing_confirmed':'confirmação de encerramento', 'closing_started':'início do encerramento',
'suspended_without_vote':'suspensão sem voto', 'log_boot':'inicialização do log'}


def meaning(column):
    if column in BASE:return BASE[column]
    if column.startswith('distinct_'):
        name=column[9:]
        if name in BASE:return 'Número de valores distintos de '+name+' na agregação. '+BASE[name]
    for prefix,scope in [('day_','Medição primária no dia do pleito.'),('following_','Medição primária no dia seguinte; horários acrescidos de 86.400 segundos.'),('reviewed_','Medição revisada do contexto alvo no dia do pleito; se não houve auditoria específica, preserva a medição primária.')]:
        if not column.startswith(prefix):continue
        stem=column[len(prefix):]
        if stem in METRICS:return scope+' '+METRICS[stem]
        m=re.fullmatch(r'after_ordinary_([mp])(\d+)',stem)
        if m:
            delta=int(m[2])*(-1 if m[1]=='m' else 1)
            return scope+f' Conclusões estritamente posteriores a prazo ordinário {delta:+d} segundos. Não é efeito causal.'
        for event,label in EVENTS.items():
            if not stem.startswith(event+'_'):continue
            tail=stem[len(event)+1:]
            d={'count':'Quantidade de eventos de '+label+'.',
               'first':'Primeiro horário de '+label+', em segundos após meia-noite local da data eleitoral.',
               'last':'Último horário de '+label+', em segundos após meia-noite local da data eleitoral.',
               'matches_bweb_close':'Algum horário de '+label+' coincide exatamente com o encerramento BWeb.'}
            if tail in d:return scope+' '+d[tail]
    return None


def main():
    out=ROOT/'analysis/dictionaries/core-v1'/str(time.time_ns());out.mkdir(parents=True,exist_ok=False)
    paths=[ROOT/'analysis/derived/sections-v2/2026/section-office.parquet',ROOT/'analysis/derived/temporal-reviewed-v1/2026/2t-AC/sections.parquet']
    rows=[];missing=[]
    for p in paths:
        dataset='canonical_section_office' if 'sections-v2' in p.parts else 'reviewed_section_time'
        for field in pq.read_schema(p):
            definition=meaning(field.name)
            if definition is None:missing.append(field.name);continue
            rows.append({'dataset':dataset,'variable':field.name,'arrow_type':str(field.type),'definition_pt':definition,
                         'missingness':'Ausente/desconhecido ou não aplicável é distinto de zero; consultar presença e cobertura. Campos temporais de 2014 e corte doméstico do exterior não são imputados.',
                         'schema_example':str(p.relative_to(ROOT))})
    if missing:raise ValueError('Definitions missing: '+','.join(sorted(set(missing))))
    pd.DataFrame(rows).to_csv(out/'data-dictionary.csv',index=False)
    atomic_json(out/'data-dictionary.json',rows)
    result={'at':now(),'status':'core_schemas_documented_aggregate_specific_dictionary_pending','output_folder':str(out.relative_to(ROOT)),
            'dataset_variable_entries':len(rows),'distinct_variables':len({r['variable'] for r in rows}),
            'scope':'All canonical section-office and reviewed section-time columns; aggregate estimator-specific columns still require their own dictionary.',
            'inputs':[{'path':str(p.relative_to(ROOT)),'sha256':digest(p)} for p in paths],
            'code_sha256':digest(ROOT/'scripts/build_data_dictionary.py')}
    atomic_json(out/'manifest.json',result);atomic_json(ROOT/'reports/data-dictionary-state.json',result);print(json.dumps(result))
if __name__=='__main__':main()
