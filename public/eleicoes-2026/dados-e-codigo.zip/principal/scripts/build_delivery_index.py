"""Build the human-readable entry point and portable, compact result selection."""
import html
import json
import os
from pathlib import Path
from urllib.parse import quote
from analysis_common import ROOT, atomic_json, digest, now


def main():
    final = json.loads((ROOT / 'reports/scientific-report-final-state.json').read_text())
    out = ROOT / final['output_folder']
    files = set(p for p in out.iterdir() if p.is_file() and p.suffix != ".zip")
    labels = {
        'temporal-population-state': 'Conclusões, cobertura, território e vínculos',
        'election-comparison-state': 'Participação e pares BWeb de cinco eleições',
        'intercompletion-state': 'Intervalos entre conclusões e sua cauda',
        'margin-scenario-state': 'Limites por disputa e cenário',
        'context-sampling-bounds-state': 'Auditoria probabilística e margem ampliada',
        'closure-selection-state': 'Seleção das coortes de fechamento',
        'supplemental-sensitivity-state': 'Sensibilidade com sequências históricas retidas',
        'following-day-review-state': 'Sensibilidade de passagem de data',
        'measurement-exception-review-state': 'Déficits, excessos e exceções de mensuração',
        'documentary-time-window-state': 'Contagens em torno de marcos documentais',
        'data-dictionary-state': 'Dicionário dos campos centrais',
        'aggregate-data-dictionary-state': 'Dicionário dos estimadores agregados',
        'evidence-matrix-state': 'Matriz de evidências e checklist das doze frentes',
        'scientific-final-figures-state': 'Figuras em PNG, SVG e PDF',
        'reproduction-environment-state': 'Ambiente, argumentos e histórico de código'
    }
    def link(path, label):
        path = Path(path)
        if not path.is_absolute():
            path = ROOT / path
        if not path.is_file():
            raise ValueError('Missing delivery artifact: ' + str(path))
        return '<a href="' + quote(os.path.relpath(path, out)) + '">' + html.escape(label) + '</a>'
    doc = ['<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">',
        '<title>Estudo da prorrogação eleitoral de 2026</title>',
        '<style>body{font:16px/1.6 system-ui;color:#183342;background:#f4f7f8;margin:0}main{max-width:1060px;margin:auto;padding:45px 24px}h1{font-size:32px;line-height:1.2}h2{margin-top:36px}a{color:#12627d}section{background:white;padding:22px 27px;border-radius:8px;margin:22px 0}li{margin:7px 0}.lead{font-size:20px}.muted{color:#526875;font-size:14px}code{overflow-wrap:anywhere}</style><main>',
        '<p class="muted">Estudo privado · Dados oficiais preservados · 31 de outubro de 2026</p>',
        '<h1>Votação após o prazo ordinário e prorrogação judicial</h1>',
        '<p class="lead">34.050 conclusões de votação após 17h no segundo turno doméstico. Os registros não identificam quantas foram causadas pela prorrogação.</p>',
        '<p>Os limites para as sete disputas permanecem positivos dentro do mecanismo restrito de participantes adicionais. A sensibilidade presidencial mais conservadora apresentada, incluindo a auditoria de contexto e corte 15 minutos anterior, mantém margem mínima de 2.262.970 votos. Isso não é uma estimativa de efeito causal nem exclui mecanismos fora das hipóteses.</p>',
        '<section><h2>Leitura principal</h2><ul>']
    for name, label in [('relatorio-cientifico.pdf', 'Relatório científico — PDF, 13 páginas'),
                        ('relatorio-cientifico.html', 'Relatório científico — HTML'),
                        ('apendice-tecnico.pdf', 'Apêndice técnico — PDF, 8 páginas'),
                        ('apendice-tecnico.html', 'Apêndice técnico — HTML'),
                        ('matriz-de-evidencias.html', 'Matriz pergunta–evidência–resultado–incerteza–limitação'),
                        ('guia-de-reproducao.html', 'Guia de reprodução e restauração'),
                        ('guia-de-reproducao.txt', 'Guia de reprodução em texto')]:
        doc.append('<li>' + link(out / name, label) + '</li>')
    doc.append('</ul></section><section><h2>Força e limites da evidência</h2><p>Foram processados 2.517.612 pacotes de log de seção por turno, sem confundi-los com pessoas ou seções físicas únicas. As contagens são censitárias dos registros disponíveis. A auditoria adicional inspecionou 63.362 pacotes; sua incerteza amostral foi separada das incertezas de relógio, cobertura e identificação causal. A revisão é interna, sem avaliação externa por pares.</p><p>A coleta contém 3.388 objetos e 521.157.604.697 bytes. Persistem um companheiro SHA1 de 2014 indisponível, com ZIP preservado, e dez auxiliares sem cópia binária originalmente arquivada. Há lacunas de membros e contagens explicitadas por seção e ano. Texto consultado na web não equivale a arquivo original preservado.</p></section>')
    for name, label in labels.items():
        rp = ROOT / f'reports/{name}.json'
        r = json.loads(rp.read_text()); files.add(rp)
        folder = ROOT / r.get('output_folder', r.get('folder', ''))
        selected = sorted(p for p in folder.rglob('*') if p.is_file() and p.suffix in ['.csv', '.parquet', '.json', '.png', '.svg', '.pdf', '.py'])
        files.update(selected)
        doc.append('<section><h2>' + html.escape(label) + '</h2><ul>')
        for p in selected:
            if '-before-' not in p.name and (p.suffix in ['.csv', '.parquet'] or (name in ['evidence-matrix-state','scientific-final-figures-state'] and p.suffix in ['.json','.pdf'])):
                doc.append('<li>' + link(p, str(p.relative_to(folder))) + '</li>')
        doc.append('<li>' + link(rp, 'Manifesto e proveniência da etapa') + '</li></ul></section>')
    checks = ['reports/scientific-computation-review.json', 'reports/scientific-final-visual-review.json',
              'reports/analysis-numerical-verification-state.json', 'reports/date-correction-verification.json',
              'reports/final-acquisition-audit.json', 'reports/analysis-test-suite-final.log']
    doc.append('<section><h2>Conferências</h2><ul>')
    for p in checks:
        files.add(ROOT / p); doc.append('<li>' + link(p, Path(p).name) + '</li>')
    doc.append('</ul><p>Os scripts e as dependências fixadas acompanham o pacote. Os derivados completos e registros de auditoria estão nos bundles privados, com inventário por membro e SHA256. Não há credenciais no pacote.</p></section></main></html>')
    index = out / 'index.html'; index.write_text('\n'.join(doc)); files.add(index)
    files.update(p for p in (ROOT / 'reports').rglob('*') if p.is_file() and p.name not in ['final-delivery-selection.json', 'final-portable-package.json'])
    files.update(p for p in (ROOT / 'scripts').iterdir() if p.is_file() and p.suffix in ['.py','.txt'])
    files.update(p for p in (ROOT / 'analysis/report-source').glob('*.json'))
    files.update([ROOT/'analysis/analysis-plan.json', ROOT/'analysis/analysis-plan-v1.json', ROOT/'analysis/plan-amendments.jsonl',
                  ROOT/'analysis/source-audit/source-ledger.json', ROOT/'analysis/findings/causal-identification-v2.json'])
    # This compact package excludes native logs and full canonical section tables;
    # their complete preservation is in the separately verified private bundles.
    selection = {'at': now(), 'status': 'reviewed_delivery_selection', 'output_folder': final['output_folder'],
        'files': [{'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size, 'sha256': digest(p)} for p in sorted(files)],
        'code_sha256': digest(__file__), 'complete_derivative_preservation': 'reports/completed-evidence-bundle-state.json'}
    atomic_json(ROOT / 'reports/final-delivery-selection.json', selection)
    print(json.dumps({'index': str(index.relative_to(ROOT)), 'files': len(files), 'bytes': sum(r['bytes'] for r in selection['files'])}))


if __name__ == '__main__':
    main()
