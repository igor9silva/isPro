"""Aggregate BWeb candidate rows with explicit consistency and duplicate diagnostics.

The output is an audited section-office table, not a causal analysis. It keeps
conflicting sections with flags and never sums repeated attendance denominators.
"""
import argparse
import json
from pathlib import Path
import time
import unicodedata

import duckdb
import pandas as pd

from analysis_common import ROOT, atomic_json, code_fingerprint, digest, now

AM_WEST = {"AMATURA", "ATALAIA DO NORTE", "BENJAMIN CONSTANT", "EIRUNEPE", "ENVIRA", "GUAJARA",
           "IPIXUNA", "ITAMARATI", "JUTAI", "SAO PAULO DE OLIVENCA", "TABATINGA"}
TIMEZONE_SOURCE = "https://www.tre-am.jus.br/comunicacao/noticias/2026/Setembro/eleitorado-do-amazonas-deve-ficar-atento-aos-horarios-de-votacao-nas-eleicoes-2026"


def plain(value):
    return "".join(c for c in unicodedata.normalize("NFD", str(value).upper()) if not unicodedata.combining(c)).strip()


def offset_to_brasilia(uf, municipality_name):
    """Domestic wall-clock offset, provisional until log/BWeb opening audit."""
    name = plain(municipality_name)
    if uf == "ZZ":
        return None
    if uf == "AC" or (uf == "AM" and name in AM_WEST):
        return 7200
    if uf in ["AM", "MT", "MS", "RO", "RR"]:
        return 3600
    if uf == "PE" and name == "FERNANDO DE NORONHA":
        return -3600
    return 0


def build(year, output_root):
    manifests = sorted((ROOT / "analysis/derived/bweb-v1" / str(year)).glob("*/complete.json"))
    if year == 2014:
        manifests = sorted((ROOT / "analysis/derived/bweb-2014-v1" / str(year)).glob("*/complete.json"))
    expected = 52 if year == 2024 else 56
    if len(manifests) != expected:
        raise ValueError(f"Wait for all {expected} BWeb archives of {year}; {len(manifests)} complete")
    files, manifest_records = [], []
    for p in manifests:
        m = json.loads(p.read_text())
        manifest_records.append({"path": str(p.relative_to(ROOT)), "sha256": digest(p)})
        for f in m["outputs"]:
            path = ROOT / f["path"]
            if digest(path) != f["sha256"]:
                raise ValueError("BWeb extract changed")
            files.append(str(path))
    out = ROOT / output_root / f"{year}-{time.time_ns()}"
    out.mkdir(parents=True, exist_ok=False)
    con = duckdb.connect()
    con.execute("SET threads=2")
    con.execute("SET memory_limit='4GB'")
    con.from_parquet(files, union_by_name=True).create_view("raw")
    columns = set(con.table("raw").columns)
    aliases = {"uf": ["SG_UF", "SG_ UF"], "aggregated_sections": ["DS_SECOES_AGREGADAS", "DS_AGREGADAS"],
               "biometry_without_auth": ["QT_ELEI_BIOM_SEM_HABILITACAO", "QT_ELEITORES_BIOMETRIA_NH"]}
    mapping = {"year": "ANO_ELEICAO", "round": "NR_TURNO", "election": "CD_ELEICAO", "pleito": "CD_PLEITO",
               "municipality": "CD_MUNICIPIO", "municipality_name": "NM_MUNICIPIO", "zone": "NR_ZONA", "section": "NR_SECAO",
               "polling_place": "NR_LOCAL_VOTACAO", "office": "CD_CARGO_PERGUNTA", "office_name": "DS_CARGO_PERGUNTA",
               "eligible": "QT_APTOS", "attendance": "QT_COMPARECIMENTO", "abstention": "QT_ABSTENCOES",
               "machine": "NR_URNA_EFETIVADA", "machine_type": "CD_TIPO_URNA", "votable": "NR_VOTAVEL",
               "votable_type": "CD_TIPO_VOTAVEL", "votable_name": "NM_VOTAVEL", "votes": "QT_VOTOS",
               "opened": "DT_ABERTURA", "closed": "DT_ENCERRAMENTO", "emitted": "DT_EMISSAO_BU", "received": "DT_BU_RECEBIDO",
               "election_date": "DT_PLEITO", "source_path": "source_path", "source_row": "source_row"}
    numeric = {"year", "round", "election", "pleito", "municipality", "zone", "section", "polling_place", "office",
               "eligible", "attendance", "abstention", "machine", "machine_type", "votable", "votable_type", "votes",
               "biometry_without_auth", "source_row"}
    expressions, missing = [], []
    for key in list(mapping) + list(aliases):
        options = aliases[key] if key in aliases else [mapping[key]]
        source = next((s for s in options if s in columns), None)
        expr = '"' + source.replace('"', '""') + '"' if source else "NULL"
        if source is None:
            missing.append(key)
        if key in numeric:
            expr = f"try_cast({expr} AS BIGINT)"
        expressions.append(expr + ' AS "' + key + '"')
    con.sql("CREATE VIEW normalized AS SELECT " + ",".join(expressions) + " FROM raw")
    keys = ["year", "round", "uf", "election", "municipality", "zone", "section", "office"]
    stable = ["pleito", "municipality_name", "polling_place", "office_name", "eligible", "attendance", "abstention", "machine",
              "machine_type", "opened", "closed", "emitted", "received", "election_date", "aggregated_sections", "biometry_without_auth"]
    selects = [f'min("{c}") AS "{c}"' for c in stable]
    selects += [f'count(DISTINCT coalesce(cast("{c}" AS VARCHAR),\'<NULL>\')) AS "distinct_{c}"' for c in stable]
    selects += ["count(*) AS candidate_rows", "count(DISTINCT votable) AS distinct_votables", "sum(votes) AS total_votes",
                "sum(CASE WHEN votable_type=1 THEN votes ELSE 0 END) AS nominal_votes",
                "sum(CASE WHEN votable_type=2 THEN votes ELSE 0 END) AS blank_votes",
                "sum(CASE WHEN votable_type=3 THEN votes ELSE 0 END) AS null_votes",
                "count(*) FILTER (WHERE votes IS NULL OR votable IS NULL) AS invalid_vote_rows",
                "count(DISTINCT source_path) AS source_archives", "min(source_path) AS source_path"]
    sql = "SELECT " + ",".join('"' + k + '"' for k in keys) + "," + ",".join(selects) + " FROM normalized GROUP BY " + ",".join('"' + k + '"' for k in keys)
    table = con.sql(sql).df()
    critical = ["eligible", "attendance", "abstention", "machine", "polling_place", "opened", "closed", "election_date", "aggregated_sections"]
    table["metadata_conflict"] = table[["distinct_" + c for c in critical]].gt(1).any(axis=1)
    table["duplicate_votable_rows"] = table["candidate_rows"] - table["distinct_votables"]
    table["electorate_identity_ok"] = table["eligible"] == table["attendance"] + table["abstention"]
    table["votes_attendance_identity_ok"] = table["total_votes"] == table["attendance"]
    table["usable_turnout"] = (~table["metadata_conflict"]) & (table["duplicate_votable_rows"] == 0) & table["electorate_identity_ok"] & table["votes_attendance_identity_ok"] & (table["invalid_vote_rows"] == 0)
    table["turnout_rate"] = table["attendance"].div(table["eligible"].where(table["eligible"] > 0))
    zones = table[["uf", "municipality_name"]].drop_duplicates()
    zones["offset_to_brasilia_seconds"] = [offset_to_brasilia(u, n) for u, n in zones.itertuples(index=False, name=None)]
    table = table.merge(zones, on=["uf", "municipality_name"], how="left", validate="many_to_one")
    # Before 2022 the ordinary deadline was local, not the synchronized 17h Brasília deadline.
    table["ordinary_deadline_local_seconds"] = 61200 - (table["offset_to_brasilia_seconds"] if year >= 2022 else 0)
    table["timing_convention"] = "local_clock_with_domestic_Brasilia_offset_pending_validation" if year >= 2022 else "ordinary_deadline_local_17h_pending_year_rule_review"
    for c in ["opened", "closed", "emitted"]:
        dt = pd.to_datetime(table[c], format="mixed", dayfirst=True, errors="coerce")
        day = pd.to_datetime(table["election_date"], format="mixed", dayfirst=True, errors="coerce").dt.normalize()
        table[c + "_elapsed_seconds"] = (dt - day).dt.total_seconds()
    table["close_seconds_after_ordinary_deadline"] = table["closed_elapsed_seconds"] - table["ordinary_deadline_local_seconds"]
    table["open_seconds_after_ordinary_start"] = table["opened_elapsed_seconds"] - (table["ordinary_deadline_local_seconds"] - 9 * 3600)
    table["usable_timing"] = table["usable_turnout"] & (table["uf"] != "ZZ") & table["closed_elapsed_seconds"].between(0, 172800)
    target = out / "section-office.parquet"
    table.to_parquet(target, index=False, compression="zstd")
    # Candidate margins remain aggregated election results, with no time-to-candidate link.
    totals = con.sql('SELECT year, "round", uf, office, election, votable, votable_type, min(votable_name) AS votable_name, sum(votes) AS votes FROM normalized GROUP BY ALL').df()
    totals.to_parquet(out / "candidate-totals-uf.parquet", index=False, compression="zstd")
    qc = {"created_at": now(), "year": year, "status": "section_tables_built_pending_population_reconciliation",
          "source_archive_count": len(manifests), "section_office_rows": len(table),
          "metadata_conflicts": int(table["metadata_conflict"].sum()),
          "duplicate_votable_rows": int(table["duplicate_votable_rows"].sum()),
          "electorate_identity_failures": int((~table["electorate_identity_ok"]).sum()),
          "votes_attendance_identity_failures": int((~table["votes_attendance_identity_ok"]).sum()),
          "unusable_turnout_rows": int((~table["usable_turnout"]).sum()),
          "missing_source_fields": missing, "timezone_source": TIMEZONE_SOURCE,
          "input_manifests": manifest_records, "code": code_fingerprint(["build_section_tables.py", "analysis_common.py"]),
          "outputs": [{"path": str(p.relative_to(ROOT)), "bytes": p.stat().st_size, "sha256": digest(p)} for p in out.glob("*.parquet")],
          "limitations": ["Provisional wall-clock interpretation must be checked against log opening and closing events and year-specific rules.",
                          "Keep metadata conflicts and duplicate candidate rows flagged; do not silently use them as valid observations.",
                          "Candidate totals include all extracted rows and require official result reconciliation before use."]}
    atomic_json(out / "quality.json", qc)
    print(json.dumps({k: v for k, v in qc.items() if k not in ["input_manifests", "code"]}, ensure_ascii=False), flush=True)
    return qc


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--years", default="2026")
    p.add_argument("--output", default="analysis/derived/sections-v1")
    a = p.parse_args()
    for year in a.years.split(","):
        build(int(year), a.output)
