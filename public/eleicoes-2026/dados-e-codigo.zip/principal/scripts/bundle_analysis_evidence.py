"""Snapshot completed derived tables and source audits into bounded private bundles.

These are locally generated derivatives, never downloaded original ZIPs. Each
member is hashed before packing and reread from its tar before publication.
"""
import hashlib
import json
import shutil
import tarfile
import time
from pathlib import Path
from analysis_common import ROOT, atomic_json, digest, now


def main():
    roots = [ROOT / 'analysis/derived', ROOT / 'analysis/source-audit']
    files = sorted(p for root in roots for p in root.rglob('*') if p.is_file())
    if any(p.is_symlink() or not p.resolve().is_relative_to(ROOT / 'analysis') for p in files):
        raise ValueError('Unexpected symlink or external path')
    total = sum(p.stat().st_size for p in files)
    if shutil.disk_usage(ROOT).free < total * 1.15 + 8 * 1024**3:
        raise ValueError('Insufficient space to preserve bounded derivative bundles')
    stamp = str(time.time_ns())
    out = ROOT / 'analysis/evidence-bundles' / ('completed-analysis-' + stamp)
    out.mkdir(parents=True, exist_ok=False)
    batches, batch, size = [], [], 0
    for p in files:
        n = p.stat().st_size
        if n > 480 * 1024**2:
            raise ValueError('One derivative exceeds the bounded artifact cap')
        if batch and size + n > 220 * 1024**2:
            batches.append(batch); batch, size = [], 0
        batch.append(p); size += n
    if batch:
        batches.append(batch)
    manifest, publications = [], []
    for index, group in enumerate(batches, 1):
        target = out / f'evidence-{index:03d}.tar'
        expected = {}
        with tarfile.open(target, 'w', format=tarfile.PAX_FORMAT) as archive:
            for p in group:
                relative = str(p.relative_to(ROOT))
                record = {'path': relative, 'bytes': p.stat().st_size, 'sha256': digest(p),
                          'bundle': str(target.relative_to(ROOT))}
                expected[relative] = record
                info = archive.gettarinfo(str(p), arcname=relative)
                info.uid = info.gid = 0; info.uname = info.gname = ''; info.mtime = 0
                with p.open('rb') as stream:
                    archive.addfile(info, stream)
        with tarfile.open(target, 'r') as archive:
            members = archive.getmembers()
            assert len(members) == len(group)
            for member in members:
                sha = hashlib.sha256(); count = 0
                with archive.extractfile(member) as stream:
                    while block := stream.read(8 * 1024**2):
                        sha.update(block); count += len(block)
                assert sha.hexdigest() == expected[member.name]['sha256']
                assert count == expected[member.name]['bytes']
        manifest.extend(expected.values())
        publications.append({'local': str(target.relative_to(ROOT)), 'bytes': target.stat().st_size,
                             'sha256': digest(target)})
        atomic_json(out / 'progress.json', {'at': now(), 'completed_bundles': index,
            'total_bundles': len(batches), 'verified_members': len(manifest), 'total_members': len(files)})
        print(json.dumps({'bundle': index, 'total_bundles': len(batches), 'verified_members': len(manifest)}), flush=True)
    member_manifest = out / 'members.jsonl'
    with member_manifest.open('w') as stream:
        for r in manifest:
            stream.write(json.dumps(r, ensure_ascii=False) + '\n')
    publications.append({'local': str(member_manifest.relative_to(ROOT)), 'bytes': member_manifest.stat().st_size,
                         'sha256': digest(member_manifest)})
    publication_path = ROOT / 'reports' / ('completed-evidence-publication-' + stamp + '.json')
    publication_manifest = ROOT / 'reports' / ('completed-evidence-manifest-' + stamp + '.json')
    atomic_json(publication_manifest, {'at': now(), 'records': publications,
        'publication_report': str(publication_path.relative_to(ROOT))})
    result = {'at': now(), 'status': 'all_members_readback_verified_pending_private_publication',
        'output_folder': str(out.relative_to(ROOT)), 'source_files': len(manifest), 'source_bytes': total,
        'bundles': len(batches), 'bundle_bytes': sum(r['bytes'] for r in publications),
        'member_manifest': str(member_manifest.relative_to(ROOT)), 'member_manifest_sha256': digest(member_manifest),
        'publication_manifest': str(publication_manifest.relative_to(ROOT)),
        'publication_report': str(publication_path.relative_to(ROOT)), 'code_sha256': digest(__file__)}
    atomic_json(out / 'bundle-manifest.json', result)
    atomic_json(ROOT / 'reports/completed-evidence-bundle-state.json', result)


if __name__ == '__main__':
    main()
