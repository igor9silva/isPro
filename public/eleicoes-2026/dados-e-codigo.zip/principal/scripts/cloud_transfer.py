#!/usr/bin/env python3
"""Copy official TSE originals to S3 with bounded RAM and resumable multipart uploads.

Only explicitly selected public source URLs and sanitized provenance are uploaded.
Neither source archives nor credentials are written into the transfer directory.
"""
import argparse
import base64
import concurrent.futures as futures
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import signal
import threading
import time
from urllib.parse import urlparse

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError, ConnectionError as S3ConnectionError
import requests

PART_BYTES = 16 * 1024 * 1024
SOURCE_CONNECTION_BYTES = 256 * 1024 * 1024
STOP = threading.Event()
PRINT_LOCK = threading.Lock()
ALLOWED_SOURCE_HOSTS = {"cdn.tse.jus.br"}
HASH_LENGTHS = {"sha512": 128, "sha256": 64, "sha1": 40, "md5": 32}


def now():
    return datetime.now(timezone.utc).isoformat()


def log(event, **values):
    with PRINT_LOCK:
        print(json.dumps({"at": now(), "event": event, **values}, ensure_ascii=False), flush=True)


def encode(data):
    return (json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode()


def atomic_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_bytes(encode(data))
    tmp.replace(path)


def missing(error):
    return isinstance(error, ClientError) and str(error.response["Error"]["Code"]) in {
        "404", "NoSuchKey", "NotFound", "NoSuchUpload"
    }


def validate_url(url):
    parsed = urlparse(url)
    if parsed.scheme != "https" or parsed.hostname not in ALLOWED_SOURCE_HOSTS or parsed.username:
        raise ValueError("Source is outside the allowlisted official TSE host")


def validate_row(row):
    validate_url(row["url"])
    path = PurePosixPath(row["path"])
    if path.is_absolute() or ".." in path.parts or not row["path"].startswith("raw/"):
        raise ValueError("Invalid archive object path")


def checksum_from_text(text, algorithm, filename):
    length = HASH_LENGTHS[algorithm]
    for line in text.splitlines():
        match = re.match(r"^([0-9a-fA-F]{%d})\s+[* ]?(.+?)\s*$" % length, line)
        if match and PurePosixPath(match[2].replace("\\", "/")).name == filename:
            return match[1].lower()
        match = re.match(r"^\w+\s*\((.+)\)\s*=\s*([0-9a-fA-F]{%d})\s*$" % length, line)
        if match and PurePosixPath(match[1]).name == filename:
            return match[2].lower()
        if re.fullmatch(r"[0-9a-fA-F]{%d}" % length, line.strip()):
            return line.strip().lower()
    raise ValueError("Official checksum does not name the expected file")


class Source:
    def __init__(self, url):
        validate_url(url)
        self.url = url
        self.http = requests.Session()
        self.http.headers.update({"Accept-Encoding": "identity", "User-Agent": "TSE-research-archive/1.0"})
        self.response = None
        self.connection_bytes = 0

    def inspect(self):
        response = self.http.head(self.url, timeout=(20, 90), allow_redirects=True)
        response.raise_for_status()
        validate_url(response.url)
        self.headers = {k.lower(): v for k, v in response.headers.items()
                        if k.lower() in {"content-length", "content-type", "etag", "last-modified", "date", "accept-ranges"}}
        self.size = int(self.headers.get("content-length", 0))
        self.identity = {k: self.headers[k] for k in ("etag", "last-modified") if k in self.headers}
        return {"url": self.url, "size": self.size, "headers": self.headers, "checked_at": now()}

    def connect(self, offset):
        if self.response is not None:
            self.response.close()
        headers = {"Range": f"bytes={offset}-"} if offset else {}
        if self.identity.get("etag") and not self.identity["etag"].startswith("W/"):
            headers["If-Match"] = self.identity["etag"]
        elif self.identity.get("last-modified"):
            headers["If-Unmodified-Since"] = self.identity["last-modified"]
        self.response = self.http.get(self.url, headers=headers, stream=True, timeout=(20, 120))
        self.response.raise_for_status()
        validate_url(self.response.url)
        if offset:
            match = re.match(r"bytes (\d+)-(\d+)/(\d+)", self.response.headers.get("Content-Range", ""))
            if self.response.status_code != 206 or not match or int(match[1]) != offset:
                raise ValueError("Source did not honor the resume byte range")
            if self.size and int(match[3]) != self.size:
                raise ValueError("Source size changed during transfer")
        for key, expected in self.identity.items():
            actual = self.response.headers.get(key)
            if actual and actual != expected:
                raise ValueError("Source validator changed during transfer")
        self.connection_bytes = 0

    def read(self, offset, count):
        for attempt in range(6):
            try:
                # Long-lived CDN streams became much slower than fresh range
                # reads during collection. Rotate without changing validators
                # or the byte offset used for hashing and multipart resume.
                if self.response is not None and self.connection_bytes >= SOURCE_CONNECTION_BYTES:
                    self.response.close()
                    self.response = None
                if self.response is None:
                    self.connect(offset)
                data = self.response.raw.read(count, decode_content=False)
                if len(data) != count:
                    raise IOError(f"Short source read at {offset}: {len(data)} of {count}")
                self.connection_bytes += len(data)
                return data
            except ValueError:
                raise
            except Exception:
                if self.response is not None:
                    self.response.close()
                self.response = None
                if attempt == 5 or STOP.is_set():
                    raise
                time.sleep(min(2 ** attempt, 20))

    def read_small(self, limit=1024 * 1024):
        response = self.http.get(self.url, stream=True, timeout=(20, 90))
        try:
            response.raise_for_status()
            validate_url(response.url)
            data = response.raw.read(limit + 1, decode_content=False)
            if len(data) > limit:
                raise ValueError("Unknown-sized source exceeds the small-file limit")
            return data
        finally:
            response.close()

    def close(self):
        if self.response is not None:
            self.response.close()
        self.http.close()


class Transfer:
    def __init__(self, client, manifest, state_dir, workers=3):
        self.s3 = client
        self.manifest = manifest
        self.bucket = manifest["bucket"]
        self.prefix = manifest["prefix"].strip("/") + "/"
        self.catalog_key = self.prefix + manifest.get("catalog_relative_path", "catalog/selection.json")
        self.progress_key = self.prefix + manifest.get("progress_relative_path", "reports/transfer-progress.json")
        self.state_dir = Path(state_dir)
        self.workers = workers
        self.lock = threading.Lock()
        self.rows = manifest["resources"]
        self.by_url = {row["url"]: row for row in self.rows}
        self.results = {}
        self.reservations = {self.key(r): r.get("bytes_remote") or 1024 * 1024 for r in self.rows}
        self.limit = min(manifest["storage_limit_bytes"], 1_000_000_000_000)
        self.extra_bytes = 0
        for row in self.rows:
            validate_row(row)
        if len(self.reservations) != len(self.rows):
            raise ValueError("Manifest has duplicate object paths")

    def key(self, row):
        return self.prefix + row["path"]

    def identity(self, row):
        return hashlib.sha256(row["url"].encode()).hexdigest()

    def json_key(self, row, kind):
        return self.prefix + kind + "/" + self.identity(row) + ".json"

    def get_json(self, key):
        try:
            response = self.s3.get_object(Bucket=self.bucket, Key=key)
            try:
                return json.load(response["Body"])
            finally:
                response["Body"].close()
        except ClientError as error:
            if missing(error):
                return None
            raise

    def put_json(self, key, data):
        body = encode(data)
        self.s3.put_object(Bucket=self.bucket, Key=key, Body=body,
                           ContentType="application/json", ContentMD5=base64.b64encode(hashlib.md5(body).digest()).decode())

    def head(self, key):
        try:
            return self.s3.head_object(Bucket=self.bucket, Key=key)
        except ClientError as error:
            if missing(error):
                return None
            raise

    def preflight(self):
        other = 0
        objects = 0
        for page in self.s3.get_paginator("list_objects_v2").paginate(Bucket=self.bucket):
            for obj in page.get("Contents", []):
                objects += 1
                if obj["Key"] not in self.reservations:
                    other += obj["Size"]
        # Leave 10 GB for receipts, interrupted parts, and metadata versions.
        self.extra_bytes = other + 10_000_000_000
        if sum(self.reservations.values()) + self.extra_bytes > self.limit:
            raise ValueError("Planned collection would exceed the 1 TB storage ceiling")
        log("preflight", planned_files=len(self.rows), planned_bytes=sum(self.reservations.values()),
            existing_objects=objects, storage_limit_bytes=self.limit, metadata_reserve_bytes=10_000_000_000)

    def reserve(self, key, actual_size):
        with self.lock:
            previous = self.reservations[key]
            proposed = sum(self.reservations.values()) - previous + actual_size + self.extra_bytes
            if proposed > self.limit:
                raise ValueError("Source size would exceed the storage ceiling")
            self.reservations[key] = actual_size

    def expected_checksums(self, row):
        expected = dict(row.get("local_hashes", {}))
        official = list(row.get("official_checksums", []))
        for algorithm in ("sha512", "sha256", "sha1", "md5"):
            companion = self.by_url.get(row["url"] + "." + algorithm)
            if not companion or any(x["algorithm"] == algorithm for x in official):
                continue
            if companion.get("http_status") == "404":
                row.setdefault("official_checksums_unavailable", []).append({
                    "algorithm": algorithm, "source_url": companion["url"], "http_status": 404})
                continue
            source = Source(companion["url"])
            try:
                value = checksum_from_text(source.read_small().decode("utf-8-sig"), algorithm,
                                           PurePosixPath(row["path"]).name)
                official.append({"algorithm": algorithm, "digest": value, "source_url": companion["url"]})
            except requests.HTTPError as error:
                status = error.response.status_code
                if status not in (404, 410):
                    raise
                # A missing checksum must not prevent preserving its available
                # source archive. Record the verification gap explicitly.
                row.setdefault("official_checksums_unavailable", []).append({
                    "algorithm": algorithm, "source_url": companion["url"], "http_status": status})
            finally:
                source.close()
        for item in official:
            if item["algorithm"] in expected and expected[item["algorithm"]] != item["digest"]:
                raise ValueError("Local and official checksum disagree")
            expected[item["algorithm"]] = item["digest"]
        return expected, official

    @staticmethod
    def check_hashes(digests, expected):
        for algorithm, digest in expected.items():
            if digests[algorithm] != digest:
                raise ValueError(f"{algorithm} checksum mismatch")

    def save_state(self, row, state):
        atomic_json(self.state_dir / "multipart" / (self.identity(row) + ".json"), state)
        self.put_json(self.json_key(row, "transfer-state"), state)

    def existing(self, row, head, expected, official):
        receipt = self.get_json(self.json_key(row, "provenance"))
        if receipt and receipt.get("status") == "verified" and receipt.get("etag") == head["ETag"]:
            self.check_hashes(receipt["hashes"], expected)
            if receipt["bytes"] != head["ContentLength"]:
                raise ValueError("Existing receipt size disagrees with stored object")
            return {**receipt, "reused": True}
        if not expected:
            checkpoint = self.get_json(self.json_key(row, "transfer-state"))
            if checkpoint and checkpoint.get("all_parts_uploaded") and checkpoint.get("size") == head["ContentLength"]:
                expected = checkpoint["hashes"]
            else:
                raise ValueError("Existing object has no trusted checksum or receipt; refusing to overwrite it")
        hashes = {algorithm: hashlib.new(algorithm) for algorithm in HASH_LENGTHS}
        response = self.s3.get_object(Bucket=self.bucket, Key=self.key(row), IfMatch=head["ETag"])
        count = 0
        try:
            for block in iter(lambda: response["Body"].read(4 * 1024 * 1024), b""):
                for digest in hashes.values():
                    digest.update(block)
                count += len(block)
        finally:
            response["Body"].close()
        digests = {k: h.hexdigest() for k, h in hashes.items()}
        self.check_hashes(digests, expected)
        if count != head["ContentLength"]:
            raise ValueError("Stored object read was incomplete")
        return self.receipt(row, count, head, digests, official, "full_s3_readback_against_trusted_checksum")

    def receipt(self, row, size, head, digests, official, method, source=None):
        result = {"schema_version": 1, "status": "verified", "url": row["url"], "path": row["path"],
                  "dataset_url": row.get("dataset_url"), "bucket": self.bucket, "key": self.key(row),
                  "bytes": size, "etag": head["ETag"], "hashes": digests,
                  "official_checksums": [{**v, "matched": True} for v in official],
                  "official_checksums_unavailable": row.get("official_checksums_unavailable", []),
                  "verification_method": method, "verified_at": now()}
        if source:
            result["source"] = source
        self.put_json(self.json_key(row, "provenance"), result)
        return result

    def copy(self, row):
        key = self.key(row)
        source = None
        try:
            if STOP.is_set():
                return {"path": row["path"], "status": "pending"}
            if str(row.get("http_status")) == "404":
                return {"path": row["path"], "url": row["url"], "status": "unavailable",
                        "error": "Official catalogue URL returned HTTP 404 during discovery", "at": now()}
            expected, official = self.expected_checksums(row)
            head = self.head(key)
            if head:
                self.reserve(key, head["ContentLength"])
                return self.existing(row, head, expected, official)
            source = Source(row["url"])
            info = source.inspect()
            size = info["size"]
            small_body = None
            if not size:
                small_body = source.read_small()
                size = len(small_body)
                info["size"] = size
            if row.get("bytes_remote") and size != row["bytes_remote"]:
                raise ValueError("Official source length changed since cataloguing")
            self.reserve(key, size)
            hashes = {algorithm: hashlib.new(algorithm) for algorithm in HASH_LENGTHS}
            if size <= PART_BYTES:
                body = small_body if small_body is not None else source.read(0, size)
                for digest in hashes.values():
                    digest.update(body)
                digests = {k: h.hexdigest() for k, h in hashes.items()}
                self.check_hashes(digests, expected)
                if row["path"].endswith(".zip") and not body.startswith(b"PK"):
                    raise ValueError("ZIP source does not start with a ZIP signature")
                self.s3.put_object(Bucket=self.bucket, Key=key, Body=body, IfNoneMatch="*",
                    ContentMD5=base64.b64encode(hashlib.md5(body).digest()).decode(),
                    Metadata={"sha256": digests["sha256"], "sha512": digests["sha512"]})
                method = "source_hashes_and_server_validated_content_md5"
            else:
                state = self.get_json(self.json_key(row, "transfer-state"))
                if state and state.get("status") == "uploading":
                    if state["size"] != size or state.get("source_identity") != source.identity:
                        raise ValueError("Source changed since interrupted upload; retained checkpoint for review")
                    try:
                        server_parts = {}
                        for page in self.s3.get_paginator("list_parts").paginate(
                                Bucket=self.bucket, Key=key, UploadId=state["upload_id"]):
                            server_parts.update({p["PartNumber"]: p for p in page.get("Parts", [])})
                        for part in state["parts"]:
                            if part["number"] not in server_parts or server_parts[part["number"]]["ETag"] != part["etag"]:
                                raise ValueError("Multipart checkpoint disagrees with stored parts")
                    except ClientError as error:
                        if not missing(error):
                            raise
                        state = None
                else:
                    state = None
                if state is None:
                    upload = self.s3.create_multipart_upload(Bucket=self.bucket, Key=key,
                        Metadata={"source-url-sha256": self.identity(row)})
                    state = {"status": "uploading", "key": key, "size": size,
                             "source_identity": source.identity, "upload_id": upload["UploadId"],
                             "parts": [], "started_at": now()}
                    self.save_state(row, state)
                offset, number = 0, 1
                for_start = len(state["parts"])
                log("streaming", path=row["path"], bytes=size, resume_parts=for_start)
                while offset < size:
                    if STOP.is_set():
                        return {"path": row["path"], "status": "paused", "uploaded_parts": len(state["parts"])}
                    body = source.read(offset, min(PART_BYTES, size - offset))
                    if offset == 0 and row["path"].endswith(".zip") and not body.startswith(b"PK"):
                        raise ValueError("ZIP source does not start with a ZIP signature")
                    block_hash = hashlib.sha256(body).hexdigest()
                    for digest in hashes.values():
                        digest.update(body)
                    if number <= for_start:
                        if block_hash != state["parts"][number - 1]["sha256"]:
                            raise ValueError("Source prefix differs from uploaded multipart data")
                    else:
                        part = self.s3.upload_part(Bucket=self.bucket, Key=key, UploadId=state["upload_id"],
                            PartNumber=number, Body=body,
                            ContentMD5=base64.b64encode(hashlib.md5(body).digest()).decode())
                        state["parts"].append({"number": number, "etag": part["ETag"],
                                               "bytes": len(body), "sha256": block_hash})
                        state["updated_at"] = now()
                        self.save_state(row, state)
                    offset += len(body)
                    number += 1
                    if number % 16 == 0:
                        log("progress", path=row["path"], bytes=offset, total_bytes=size)
                digests = {k: h.hexdigest() for k, h in hashes.items()}
                self.check_hashes(digests, expected)
                # Persist final digests before completion, so a lost completion
                # response can be recovered by a full object read-back.
                state["hashes"] = digests
                state["all_parts_uploaded"] = True
                self.save_state(row, state)
                if self.head(key):
                    raise ValueError("Object appeared during transfer; refusing to overwrite it")
                self.s3.complete_multipart_upload(Bucket=self.bucket, Key=key, UploadId=state["upload_id"],
                    MultipartUpload={"Parts": [{"PartNumber": p["number"], "ETag": p["etag"]} for p in state["parts"]]})
                state.update(status="completed", completed_at=now(), hashes=digests)
                self.save_state(row, state)
                method = "source_hashes_and_server_validated_content_md5_per_part"
            head = self.head(key)
            if not head or head["ContentLength"] != size:
                raise ValueError("Completed S3 object has an unexpected size")
            return self.receipt(row, size, head, digests, official, method, info)
        except Exception as error:
            http_status = getattr(getattr(error, "response", None), "status_code", None)
            unavailable = http_status in (404, 410)
            retryable = isinstance(error, (requests.RequestException, S3ConnectionError, OSError)) and not unavailable
            if isinstance(error, ClientError):
                retryable = error.response.get("ResponseMetadata", {}).get("HTTPStatusCode", 0) >= 500
            result = {"path": row["path"], "url": row["url"], "status": "failed",
                      "error": f"{type(error).__name__}: {error}", "at": now(), "retryable": retryable}
            if unavailable:
                result["status"] = "unavailable"
            return result
        finally:
            if source:
                source.close()

    def run(self):
        self.preflight()
        self.put_json(self.catalog_key, self.manifest)
        pending = list(self.rows)
        for attempt in range(3):
            if attempt:
                if STOP.wait(30 * attempt):
                    break
                log("retry_pass", number=attempt + 1, files=len(pending))
            with futures.ThreadPoolExecutor(max_workers=self.workers) as pool:
                jobs = {pool.submit(self.copy, row): row for row in pending}
                for future in futures.as_completed(jobs):
                    result = future.result()
                    self.results[result["path"]] = result
                    log("file", path=result["path"], status=result["status"],
                        bytes=result.get("bytes", 0), error=result.get("error"),
                        completed=len(self.results), selected=len(self.rows))
                    report = self.report()
                    atomic_json(self.state_dir / "progress.json", report)
                    if len(self.results) % 10 == 0 or result["status"] == "failed":
                        self.put_json(self.progress_key, report)
            pending = [row for row in self.rows if self.results.get(row["path"], {}).get("retryable")]
            if STOP.is_set() or not pending:
                break
        report = self.report()
        self.put_json(self.progress_key, report)
        log("finished", **{k: v for k, v in report.items() if k != "files"})
        return report

    def report(self):
        results = list(self.results.values())
        return {"updated_at": now(), "selected": len(self.rows),
                "verified": sum(r["status"] == "verified" for r in results),
                "verified_bytes": sum(r.get("bytes", 0) for r in results if r["status"] == "verified"),
                "failed": sum(r["status"] == "failed" for r in results),
                "unavailable": sum(r["status"] == "unavailable" for r in results),
                "pending": len(self.rows) - sum(r["status"] in ("verified", "failed", "unavailable") for r in results),
                "storage_limit_bytes": self.limit, "files": results}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--state-dir", required=True)
    parser.add_argument("--workers", type=int, default=3)
    parser.add_argument("--profile")
    parser.add_argument("--only", help="Regular expression selecting resource paths")
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()
    manifest = json.loads(Path(args.manifest).read_text())
    if args.only:
        manifest["resources"] = [r for r in manifest["resources"] if re.search(args.only, r["path"])]
    if args.limit:
        manifest["resources"] = manifest["resources"][:args.limit]
    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, lambda *_: STOP.set())
    session = boto3.Session(profile_name=args.profile, region_name="auto")
    client = session.client("s3", endpoint_url="https://t3.storage.dev", config=Config(
        signature_version="s3v4", connect_timeout=20, read_timeout=120,
        retries={"mode": "standard", "max_attempts": 8}, max_pool_connections=max(10, args.workers * 3),
        request_checksum_calculation="when_required", response_checksum_validation="when_required"))
    transfer = Transfer(client, manifest, args.state_dir, args.workers)
    report = transfer.run()
    return 0 if report["failed"] == 0 and report["pending"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
