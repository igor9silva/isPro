#!/usr/bin/env python3
"""Preserve official TSE downloads, source metadata and integrity evidence."""
import argparse
import concurrent.futures as cf
import datetime as dt
import hashlib
import html.parser
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import threading
import time
import urllib.parse
import zipfile

ROOT = Path(__file__).resolve().parents[1]
API = 'https://dadosabertos.tse.jus.br/api/3/action/'
LOCK = threading.Lock()

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temp.replace(path)

def curl(url, output, head=False, resume=False):
    output.parent.mkdir(parents=True, exist_ok=True)
    cmd = ['curl', '--location', '--fail', '--silent', '--show-error',
           '--connect-timeout', '20', '--max-time', '10800' if resume else ('30' if head else '90'),
           '--retry', '1' if head else '3', '--retry-delay', '2', '--proto', '=https',
           '--proto-redir', '=https', '--user-agent', 'TSE-research-archive/1.0',
           '--dump-header', str(output) + '.headers', '--output', str(output)]
    if head:
        cmd.append('--head')
    if resume:
        cmd.extend(['--continue-at', '-'])
    result = subprocess.run(cmd + [url], capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(result.stderr.strip()[-1500:])

class Links(html.parser.HTMLParser):
    def __init__(self):
        super().__init__()
        self.urls = set()
    def handle_starttag(self, tag, attrs):
        if tag == 'a':
            href = dict(attrs).get('href', '')
            if href.startswith('https://cdn.tse.jus.br/'):
                self.urls.add(href)

def wanted(name, year):
    if name.startswith(f'resultados-{year}'):
        return True
    return name in [f'eleitorado-{year}', f'comparecimento-e-abstencao-{year}',
                    f'candidatos-{year}', f'mesarias-mesarios-e-funcoes-especiais-{year}']

def category(url):
    path = urllib.parse.urlparse(url).path.lower()
    if '/arqurnatot/' in path:
        return 'arquivos_urna'
    if '/buweb/' in path or '/bweb/' in path:
        return 'boletins_urna'
    if 'gedai' in path:
        return 'gedai'
    if 'correspond' in path or '/corresp' in path:
        return 'correspondencias'
    return path.split('/')[-2]

def catalog(years):
    resources = {}
    errors = []
    def get_year(year):
        path = ROOT / 'metadata' / f'catalog-search-{year}.json'
        curl(API + 'package_search?' + urllib.parse.urlencode({'q': year, 'rows': 100}), path)
        data = json.loads(path.read_text())
        if not data.get('success'):
            raise ValueError(data)
        if data['result']['count'] > 100:
            raise ValueError('Catalog pagination required')
        return year, [p for p in data['result']['results'] if wanted(p['name'], year)]
    packages = []
    with cf.ThreadPoolExecutor(max_workers=4) as pool:
        for year, ps in pool.map(get_year, years):
            packages.extend((year, p) for p in ps)
    def get_package(item):
        year, p = item
        slug = p['name']
        data_path = ROOT / 'metadata' / 'packages' / (slug + '.json')
        page_path = ROOT / 'metadata' / 'pages' / (slug + '.html')
        try:
            curl(API + 'package_show?' + urllib.parse.urlencode({'id': slug}), data_path)
            data = json.loads(data_path.read_text())
            if data.get('success'):
                p = data['result']
        except Exception as e:
            with LOCK:
                errors.append({'dataset': slug, 'stage': 'package_show', 'error': str(e)})
        urls = {r['url']: r for r in p['resources'] if r.get('url', '').startswith('https://cdn.tse.jus.br/')}
        try:
            curl('https://dadosabertos.tse.jus.br/dataset/' + slug, page_path)
            parser = Links()
            parser.feed(page_path.read_text(errors='replace'))
            for url in parser.urls:
                urls.setdefault(url, {'url': url, 'name': Path(urllib.parse.urlparse(url).path).name,
                                      'discovered_in': 'official_dataset_html'})
        except Exception as e:
            with LOCK:
                errors.append({'dataset': slug, 'stage': 'dataset_html', 'error': str(e)})
        return year, p, list(urls.values())
    with cf.ThreadPoolExecutor(max_workers=4) as pool:
        for year, p, rs in pool.map(get_package, packages):
            print(f'CATALOG {year} {p["name"]}: {len(rs)} resources', flush=True)
            for r in rs:
                url = r['url']
                filename = Path(urllib.parse.urlparse(url).path).name
                cat = category(url)
                entry = {'url': url, 'year': year, 'category': cat, 'name': r.get('name'),
                         'resource_id': r.get('id'), 'dataset': p['name'],
                         'dataset_url': 'https://dadosabertos.tse.jus.br/dataset/' + p['name'],
                         'discovery': r.get('discovered_in', 'official_ckan_api'),
                         'path': f'raw/{year}/{cat}/{filename}', 'discovered_at': now()}
                if url not in resources:
                    resources[url] = entry
    save_json(ROOT / 'metadata' / 'resources.json', sorted(resources.values(), key=lambda r: (r['year'],r['category'],r['url'])))
    save_json(ROOT / 'metadata' / 'catalog-errors.json', errors)
    print(f'CATALOG COMPLETE: {len(resources)} resources, {len(errors)} errors', flush=True)

def probe(workers):
    resources = json.loads((ROOT / 'metadata/resources.json').read_text())
    def one(r):
        key = hashlib.sha256(r['url'].encode()).hexdigest()[:24]
        path = ROOT / 'metadata' / 'heads' / key
        try:
            curl(r['url'], path, head=True)
            text = path.read_text(errors='replace')
            sizes = re.findall(r'^content-length:\s*(\d+)', text, re.I|re.M)
            r['bytes_remote'] = int(sizes[-1]) if sizes else None
            r['http_status'] = re.findall(r'^HTTP/\S+\s+(\d+)', text, re.M)[-1]
            r['probe_at'] = now()
        except Exception as e:
            r['probe_error'] = str(e)
        return r
    out = []
    with cf.ThreadPoolExecutor(max_workers=workers) as pool:
        for r in pool.map(one, resources):
            out.append(r)
            if len(out) % 100 == 0:
                print(f'PROBE {len(out)}/{len(resources)}', flush=True)
    save_json(ROOT / 'metadata/resources.json', out)
    grouped = {}
    for r in out:
        key = f'{r["year"]}/{r["category"]}'
        group = grouped.setdefault(key, {'files':0,'bytes':0,'unknown_size':0,'errors':0})
        group['files'] += 1
        group['bytes'] += r.get('bytes_remote') or 0
        group['unknown_size'] += r.get('bytes_remote') is None
        group['errors'] += bool(r.get('probe_error'))
    save_json(ROOT / 'reports/remote-sizes.json', grouped)
    print(json.dumps(grouped, ensure_ascii=False, indent=2), flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['catalog','probe'])
    parser.add_argument('--years', nargs='+', type=int, default=[2026,2022,2018,2014,2010,2006,2002])
    parser.add_argument('--workers', type=int, default=4)
    args = parser.parse_args()
    if args.action == 'catalog':
        catalog(args.years)
    elif args.action == 'probe':
        probe(args.workers)
