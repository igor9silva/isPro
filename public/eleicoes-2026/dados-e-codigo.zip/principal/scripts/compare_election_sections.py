"""Descriptive, denominator-preserving comparisons; no causal effect estimated."""
import json
import re
import time

import numpy as np
import pandas as pd

from analysis_common import ROOT, atomic_json, digest, now

YEARS = [2014, 2018, 2022, 2024, 2026]
KEYS = ['uf', 'municipality', 'zone', 'section']


def normalized_aggregates(value):
    if value is None or pd.isna(value) or str(value).strip() in ['', '#NULO#', '#NE']:
        return ''
    # Preserve every listed section while ignoring whitespace/order formatting.
    tokens = re.findall(r'\d+', str(value))
    if not tokens:
        raise ValueError('Unknown nonempty aggregated-section description')
    return ','.join(str(x) for x in sorted({int(v) for v in tokens}))


def weighted_turnout(g):
    eligible = g.eligible.sum()
    return float(g.attendance.sum() / eligible) if eligible > 0 else None


def summary(g):
    return {'sections': len(g), 'eligible': int(g.eligible.sum()), 'attendance': int(g.attendance.sum()),
        'abstention': int(g.abstention.sum()), 'turnout_weighted': weighted_turnout(g),
        'turnout_section_mean': float(g.turnout_rate.mean()), 'zero_eligible_sections': int(g.eligible.eq(0).sum()),
        'zero_attendance_sections': int(g.attendance.eq(0).sum()),
        'usable_close_time_sections': int(g.usable_timing.sum()),
        'closed_more_than_10m_after_deadline': int((g.usable_timing & g.close_seconds_after_ordinary_deadline.gt(600)).sum()),
        'closed_more_than_2h_after_deadline': int((g.usable_timing & g.close_seconds_after_ordinary_deadline.gt(7200)).sum()),
        'median_close_seconds_after_deadline': float(g.loc[g.usable_timing, 'close_seconds_after_ordinary_deadline'].median())}


def within_year(s, year, folder):
    if s.duplicated(KEYS + ['round']).any():
        raise ValueError('Multiple elections for a section-round require explicit selection')
    cols = KEYS + ['polling_place', 'aggregated_sections', 'eligible', 'attendance', 'abstention',
                   'turnout_rate', 'close_seconds_after_ordinary_deadline', 'open_seconds_after_ordinary_start',
                   'usable_timing', 'usable_turnout_rate', 'municipality_name']
    pair = s[s['round'] == 1][cols].merge(s[s['round'] == 2][cols], how='outer', on=KEYS,
                                          suffixes=('_1', '_2'), indicator='coverage', validate='one_to_one')
    pair['exact_key_pair'] = pair.coverage.eq('both')
    pair['same_polling_place'] = pair.polling_place_1.eq(pair.polling_place_2) & pair.polling_place_1.notna()
    pair['same_aggregation'] = pair.aggregated_sections_1.map(normalized_aggregates).eq(pair.aggregated_sections_2.map(normalized_aggregates))
    pair['strict_metadata_pair'] = pair.exact_key_pair & pair.same_polling_place & pair.same_aggregation
    pair['eligible_difference'] = pair.eligible_2 - pair.eligible_1
    pair['attendance_difference'] = pair.attendance_2 - pair.attendance_1
    pair['turnout_change_pp'] = 100 * (pair.turnout_rate_2 - pair.turnout_rate_1)
    pair['close_time_change_seconds'] = pair.close_seconds_after_ordinary_deadline_2 - pair.close_seconds_after_ordinary_deadline_1
    pair['eligible_relative_change'] = pair.eligible_difference / pair.eligible_1.where(pair.eligible_1.gt(0))
    pair['coverage'] = pair.coverage.astype(str)
    pair.to_parquet(folder / f'{year}-within-year-pairs.parquet', index=False, compression='zstd')
    result = []
    for scope, scope_mask in [('domestic', pair.uf.ne('ZZ')), ('overseas', pair.uf.eq('ZZ'))]:
        for label, mask in [('exact_keys', pair.exact_key_pair), ('stable_polling_and_aggregation', pair.strict_metadata_pair),
                            ('stable_metadata_eligible_within_5pct', pair.strict_metadata_pair & pair.eligible_relative_change.abs().le(.05))]:
            q = pair[scope_mask & mask]
            e1, e2 = q.eligible_1.sum(), q.eligible_2.sum()
            result.append({'year': year, 'scope': scope, 'pair_definition': label, 'pairs': len(q),
                'eligible_1': int(e1), 'eligible_2': int(e2), 'attendance_1': int(q.attendance_1.sum()), 'attendance_2': int(q.attendance_2.sum()),
                'weighted_turnout_change_pp': float(100 * (q.attendance_2.sum()/e2 - q.attendance_1.sum()/e1)) if e1 and e2 else None,
                'mean_section_turnout_change_pp': float(q.turnout_change_pp.mean()),
                'median_section_turnout_change_pp': float(q.turnout_change_pp.median()),
                'median_close_time_change_seconds': float(q.close_time_change_seconds.median()),
                'same_eligible_pairs': int(q.eligible_difference.eq(0).sum()),
                'round1_only_sections': int((scope_mask & pair.coverage.eq('left_only')).sum()),
                'round2_only_sections': int((scope_mask & pair.coverage.eq('right_only')).sum())})
    return result


def main():
    folder = ROOT / 'analysis/derived/election-comparisons-v1' / str(time.time_ns())
    folder.mkdir(parents=True, exist_ok=False)
    totals, uf_totals, pairs, municipalities, sources = [], [], [], [], []
    for year in YEARS:
        p = ROOT / f'analysis/derived/sections-v2/{year}/section-office.parquet'
        s = pd.read_parquet(p)
        s = s[s.office.eq(11 if year == 2024 else 1)].copy()
        sources.append({'year': year, 'path': str(p.relative_to(ROOT)), 'sha256': digest(p)})
        for turn, g in s.groupby('round'):
            for scope, q in [('domestic', g[g.uf.ne('ZZ')]), ('overseas', g[g.uf.eq('ZZ')])]:
                if len(q): totals.append({'year': year, 'round': int(turn), 'scope': scope, **summary(q)})
        for (turn, uf), g in s.groupby(['round', 'uf']):
            uf_totals.append({'year': year, 'round': int(turn), 'uf': uf, **summary(g)})
        pairs.extend(within_year(s, year, folder))
        mg = s.groupby(['round', 'uf', 'municipality']).agg(municipality_name=('municipality_name', 'first'),
            municipality_names=('municipality_name', 'nunique'), sections=('section', 'size'), eligible=('eligible', 'sum'),
            attendance=('attendance', 'sum'), abstention=('abstention', 'sum'),
            median_close_seconds_after_deadline=('close_seconds_after_ordinary_deadline', 'median')).reset_index()
        mg['turnout_rate'] = mg.attendance / mg.eligible.where(mg.eligible.gt(0))
        mg['year'] = year
        municipalities.append(mg)
    m = pd.concat(municipalities, ignore_index=True)
    m.to_parquet(folder / 'municipality-participation.parquet', index=False, compression='zstd')
    cross = []
    for old, new in [(2014, 2018), (2018, 2022), (2022, 2026)]:
        a = m[m.year.eq(old)]; b = m[m.year.eq(new)]
        j = a.merge(b, on=['round', 'uf', 'municipality'], how='outer', suffixes=('_old', '_new'), indicator='coverage', validate='one_to_one')
        j['turnout_change_pp'] = 100*(j.turnout_rate_new-j.turnout_rate_old)
        j['municipality_name_changed'] = j.municipality_name_old.ne(j.municipality_name_new)
        j['coverage'] = j.coverage.astype(str)
        j.to_parquet(folder / f'{old}-{new}-municipality-pairs.parquet', index=False, compression='zstd')
        for turn, g in j.groupby('round'):
            cross.append({'old_year': old, 'new_year': new, 'round': int(turn), 'linked': int(g.coverage.eq('both').sum()),
                'old_only': int(g.coverage.eq('left_only').sum()), 'new_only': int(g.coverage.eq('right_only').sum()),
                'name_changed_in_linked': int((g.coverage.eq('both') & g.municipality_name_changed).sum())})
    pd.DataFrame(totals).to_csv(folder / 'national-participation.csv', index=False)
    pd.DataFrame(uf_totals).to_csv(folder / 'uf-participation.csv', index=False)
    pd.DataFrame(pairs).to_csv(folder / 'within-year-pair-summary.csv', index=False)
    pd.DataFrame(cross).to_csv(folder / 'cross-year-linkage-summary.csv', index=False)
    result = {'at': now(), 'status': 'descriptive_bweb_comparisons_complete_pending_log_comparisons',
        'folder': str(folder.relative_to(ROOT)), 'inputs': sources,
        'limitations': ['Exact section identifiers and stable polling-place codes do not guarantee identical voters or physical addresses.',
            'Restricting to unchanged electorate metadata is a sensitivity selection, not a preferred causal sample.',
            '2014 has no opening/closure timestamps in the collected BWeb schema; missing timing is not zero late activity.',
            'The 2024 municipal second turn covers selected municipalities; it is not a presidential national comparison.',
            'Year and round differences combine contest load, electorate, campaign, operational conditions and selection. No causal extension effect is estimated.',
            'Turnout denominators use the BWeb section universe. Official totalization includes some uninstalled/overseas electorate absent here; see separate reconciliation.',
            '2018MAmunicipality8591zone17 first turn differs by94 votes between BWeb and totalization; retained transparently, not silently corrected.'],
        'outputs': [{'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size, 'sha256': digest(p)} for p in folder.iterdir()]}
    atomic_json(folder / 'comparison.json', result)
    atomic_json(ROOT / 'reports/election-comparison-state.json', result)
    print(json.dumps({'folder': result['folder'], 'outputs': len(result['outputs']), 'status': result['status']}), flush=True)


if __name__ == '__main__':
    main()
