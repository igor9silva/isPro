"""Compare explicitly different operational timestamps with public TSE cohorts."""
import json
from pathlib import Path
import time

import pandas as pd

from analysis_common import ROOT, atomic_json, digest, now


def main():
    folder = ROOT / 'analysis/derived/time-benchmark-comparison-v1' / str(time.time_ns())
    folder.mkdir(parents=True, exist_ok=False)
    section_path = ROOT / 'analysis/derived/sections-v2/2026/section-office.parquet'
    s = pd.read_parquet(section_path)
    s = s[(s['round'] == 2) & (s.office == 1) & s.uf.ne('ZZ')]
    benchmarks = ROOT / 'analysis/source-audit/official-benchmarks'
    records, vote_records, sources = [], [], []
    for delta, name in [(600, 'late-close-1710'), (7200, 'late-close-1900')]:
        official = pd.read_csv(benchmarks / (name + '.csv')).set_index('uf')
        # The 19h table lists only UFs with sections in that cohort. Keep absent
        # rows as missing rather than invent a zero benchmark for those UFs.
        for uf, g in s.groupby('uf'):
            for field in ['closed_elapsed_seconds', 'emitted_elapsed_seconds']:
                selected = g[field] > g.ordinary_deadline_local_seconds + delta
                records.append({'uf': uf, 'cohort_cutoff_after_17_seconds': delta,
                                'measure': field, 'bweb_sections': len(g), 'measured_cohort_sections': int(selected.sum()),
                                'official_cohort_sections': int(official.loc[uf, 'sections']) if uf in official.index else None,
                                'available_timestamp_sections': int(g[field].notna().sum()), 'population': 'all_domestic_bweb'})
        for mp in sorted((ROOT / 'analysis/derived/temporal-features-v1/2026').glob('2t-*/complete.json')):
            meta = json.loads(mp.read_text())
            if meta['uf'] == 'ZZ' or not meta.get('outputs'):
                continue
            src = ROOT / next(x['path'] for x in meta['outputs'] if x['path'].endswith('sections.parquet'))
            if digest(src) != next(x['sha256'] for x in meta['outputs'] if x['path'].endswith('sections.parquet')):
                raise ValueError('Feature output changed')
            sources.append({'path': str(mp.relative_to(ROOT)), 'sha256': digest(mp)})
            g = pd.read_parquet(src)
            uf = meta['uf']
            if uf not in official.index:
                continue
            fields = ['closed_elapsed_seconds', 'emitted_elapsed_seconds', 'day_closing_started_last',
                      'day_closing_confirmed_last', 'day_all_present_voted_confirmed_last', 'day_last_completed_second']
            for field in fields:
                if field not in g:
                    continue
                selected = g[field] > g.ordinary_deadline_local_seconds + delta
                for population, good in [('all_available_logs', g.log_present),
                                         ('count_and_clock_clean', g.strict_same_day_time_eligible)]:
                    cohort = selected & good
                    x = g.loc[cohort]
                    for inclusive in [False, True]:
                        post17 = x.day_after_ordinary_p0.sum()
                        post18 = x.day_after_ordinary_p3600.sum()
                        post19 = x.day_after_ordinary_p7200.sum()
                        if inclusive:
                            post17 += x.day_at_ordinary_deadline.sum()
                            post18 += x.day_at_ordinary_plus_3600.sum()
                            post19 += x.day_at_ordinary_plus_7200.sum()
                        vote_records.append({'uf': uf, 'measure': field, 'cohort_cutoff_after_17_seconds': delta,
                            'population': population, 'vote_cutoff_inclusive': inclusive,
                            'bweb_cohort_sections': int(selected.sum()), 'cohort_sections_with_usable_logs': int(cohort.sum()),
                            'cohort_sections_missing_logs': int((selected & ~g.log_present).sum()),
                            'measured_completed_17_18': int(post17 - post18),
                            'measured_completed_18_19': int(post18 - post19),
                            'measured_completed_after_19': int(post19), 'measured_total_completed_after_17': int(post17),
                            **{'official_' + k: int(v) for k, v in official.loc[uf].items()},
                            'exact_deadline_events_in_cohort': int(x.day_at_ordinary_deadline.sum()),
                            'count_gap_if_no_spurious_completions': int(x.unobserved_completions_if_no_spurious.sum())})
    a = pd.DataFrame(records)
    a['section_difference'] = a.measured_cohort_sections - a.official_cohort_sections
    b = pd.DataFrame(vote_records)
    b['post17_vote_difference'] = b.measured_total_completed_after_17 - b.official_total_completed_after_17
    a.to_csv(folder / 'bweb-cohort-comparison.csv', index=False)
    b.to_csv(folder / 'native-cohort-vote-comparison.csv', index=False)
    national = a.groupby(['cohort_cutoff_after_17_seconds', 'measure']).agg(
        measured_sections=('measured_cohort_sections', 'sum'), official_listed_sections=('official_cohort_sections', 'sum')).reset_index()
    national.to_csv(folder / 'bweb-cohort-national.csv', index=False)
    result = {'at': now(), 'status': 'definition_and_coverage_differences_remain', 'source_bweb_sha256': digest(section_path),
        'native_archives_included': len({s['path'] for s in sources}), 'native_manifests': list({s['path']: s for s in sources}.values()),
        'output_folder': str(folder.relative_to(ROOT)), 'national_bweb_comparison': json.loads(national.to_json(orient='records')),
        'interpretation': ['The public cohort label is not a documented per-section implementation time.',
                          'Closure, BU emission, last recorded completed vote and distinct log closure events remain separate measurements.',
                          'The closest numerical match is not proof of the TSE operational definition. No thresholds were fitted to force agreement.',
                          'Native comparisons are partial until all UFs complete; keep their exact denominators.',
                          'Missing UFs in the19h public table are not automatically imputed as zero benchmark rows.',
                          'Boundary-inclusive versus strict counting is a measurement sensitivity, not evidence of treatment.'],
        'outputs': [{'path': str(p.relative_to(ROOT)), 'sha256': digest(p)} for p in folder.glob('*.csv')]}
    atomic_json(folder / 'comparison.json', result)
    atomic_json(ROOT / 'reports/time-benchmark-comparison-latest.json', result)
    print(json.dumps({k: v for k, v in result.items() if k not in ['native_manifests', 'outputs', 'interpretation']}))


if __name__ == '__main__':
    main()
