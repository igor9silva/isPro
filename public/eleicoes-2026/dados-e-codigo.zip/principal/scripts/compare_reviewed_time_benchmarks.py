"""Complete 2026 comparison: operational cohort and endpoint definitions stay explicit."""
import json
import time
from pathlib import Path
import pandas as pd
from analysis_common import ROOT, atomic_json, digest, now

FIELDS = ['closed_elapsed_seconds','emitted_elapsed_seconds','day_closing_started_last',
          'day_closing_confirmed_last','day_all_present_voted_confirmed_last','reviewed_last_completed_second']

def main():
    out=ROOT/'analysis/derived/time-benchmark-comparison-v2'/str(time.time_ns())
    out.mkdir(parents=True,exist_ok=False)
    sources=[]; rows=[]; boundaries=[]
    bdir=ROOT/'analysis/source-audit/official-benchmarks'
    official={600:pd.read_csv(bdir/'late-close-1710.csv').set_index('uf'),
              7200:pd.read_csv(bdir/'late-close-1900.csv').set_index('uf')}
    for delta,t in official.items():
        sources.append({'path':str((bdir/('late-close-1710.csv' if delta==600 else 'late-close-1900.csv')).relative_to(ROOT)),
                        'sha256':digest(bdir/('late-close-1710.csv' if delta==600 else 'late-close-1900.csv'))})
    manifests=sorted((ROOT/'analysis/derived/temporal-reviewed-v1/2026').glob('2t-*/complete.json'))
    if len(manifests)!=28:raise ValueError('All28second-turn archives required')
    for mp in manifests:
        m=json.loads(mp.read_text());uf=m['uf']
        if uf=='ZZ':continue
        p=mp.parent/'sections.parquet'
        expected=next(x['sha256'] for x in m['outputs'] if x['path'].endswith('sections.parquet'))
        if digest(p)!=expected:raise ValueError('Reviewed input changed')
        sources.append({'path':str(mp.relative_to(ROOT)),'sha256':digest(mp)})
        g=pd.read_parquet(p)
        for inclusive in [False,True]:
            c=[g['reviewed_after_ordinary_'+s].fillna(0) for s in ['p0','p3600','p7200']]
            if inclusive:
                c=[x+g['reviewed_at_ordinary_'+s].fillna(0) for x,s in zip(c,['deadline','plus_3600','plus_7200'])]
            boundaries.append({'uf':uf,'inclusive_lower_endpoint':inclusive,'sections':len(g),
                'recorded_17_18':int((c[0]-c[1]).sum()),'recorded_18_19':int((c[1]-c[2]).sum()),
                'recorded_after_19':int(c[2].sum()),'recorded_after_17':int(c[0].sum()),
                'exact17':int(g.reviewed_at_ordinary_deadline.sum()),'exact18':int(g.reviewed_at_ordinary_plus_3600.sum()),
                'exact19':int(g.reviewed_at_ordinary_plus_7200.sum()),'unobserved_count_gap':int(g.reviewed_gap_if_no_spurious.sum())})
        for delta in [0,600,7200]:
            for field in FIELDS:
                for cohort_inclusive in [False, True]:
                    cutoff=g.ordinary_deadline_local_seconds+delta
                    selected=g[field].ge(cutoff) if cohort_inclusive else g[field].gt(cutoff)
                    for population,good in [('all_recorded',g.log_present),('strict_time',g.reviewed_strict_time_eligible)]:
                        if field.startswith('day_') and population=='strict_time':
                            good=good & ~g.operational_context_contaminated
                        x=g.loc[selected & good]
                        for inclusive in [False,True]:
                            c=[x['reviewed_after_ordinary_'+s].sum() for s in ['p0','p3600','p7200']]
                            if inclusive:
                                c=[v+x['reviewed_at_ordinary_'+s].sum() for v,s in zip(c,['deadline','plus_3600','plus_7200'])]
                            row={'uf':uf,'cohort_delta_seconds':delta,'cohort_timestamp':field,'cohort_cutoff_inclusive':cohort_inclusive,
                                'population':population,'vote_cutoff_inclusive':inclusive,'available_timestamp_sections':int(g[field].notna().sum()),
                                'cohort_sections':int(selected.sum()),'cohort_sections_with_usable_logs':len(x),
                                'cohort_missing_logs':int((selected & ~g.log_present).sum()),
                                'recorded_17_18':int(c[0]-c[1]),'recorded_18_19':int(c[1]-c[2]),
                                'recorded_after_19':int(c[2]),'recorded_after_17':int(c[0]),
                                'unobserved_count_gap':int(g.loc[selected,'reviewed_gap_if_no_spurious'].sum())}
                            if delta in official and uf in official[delta].index:
                                row.update({'official_'+k:int(v) for k,v in official[delta].loc[uf].items()})
                            rows.append(row)
    a=pd.DataFrame(rows);b=pd.DataFrame(boundaries)
    keys=['cohort_delta_seconds','cohort_timestamp','cohort_cutoff_inclusive','population','vote_cutoff_inclusive']
    counts=['cohort_sections','cohort_sections_with_usable_logs','cohort_missing_logs','recorded_17_18','recorded_18_19','recorded_after_19','recorded_after_17','unobserved_count_gap']
    national=a.groupby(keys,dropna=False)[counts].sum().reset_index()
    # National official totals use all listed source rows, not invented zeros for absent UFs.
    for delta,t in official.items():
        mask=national.cohort_delta_seconds.eq(delta)
        for k in t.columns:national.loc[mask,'official_'+k]=int(t[k].sum())
    national.loc[national.cohort_delta_seconds.eq(0),'official_sections']=497333
    a.to_csv(out/'uf-operational-cohorts.csv',index=False)
    national.to_csv(out/'national-operational-cohorts.csv',index=False)
    b.to_csv(out/'uf-endpoint-windows.csv',index=False)
    bn=b.groupby('inclusive_lower_endpoint').sum(numeric_only=True).reset_index()
    bn.to_csv(out/'national-endpoint-windows.csv',index=False)
    for field in ['closed_elapsed_seconds','emitted_elapsed_seconds']:
        # A compact, deliberately non-optimized comparison of two documented clocks.
        chosen=national[(national.cohort_timestamp==field)&~national.cohort_cutoff_inclusive&
                        (national.population=='all_recorded')&national.vote_cutoff_inclusive]
        print(chosen.to_json(orient='records'))
    result={'at':now(),'status':'full_2026_recorded_time_comparison_residual_differences_explicit',
        'output_folder':str(out.relative_to(ROOT)),'domestic_archives':27,'input_manifests':sources,
        'all_domestic_endpoint_totals':json.loads(bn.to_json(orient='records')),
        'official_all_domestic':{'after17':34393,'17_18':32399,'18_19':1981,'after19':13,'sections_closed_after17':497333},
        'notes':['Timestamp families remain separate. Closest numerical match does not establish the unpublished TSE section-level definition.',
          'All-recorded totals include incomplete-count sections as observed, not zero-vote imputations; unobserved count gap is explicit.',
          'Strict-time operational log cohorts exclude known foreign-section context contamination. BWeb timestamps are independent fields.',
          'Endpoint windows are (17,18],(18,19],(19,infinity) for strict and [17,18),[18,19),[19,infinity) for inclusive.',
          'Missing rows in the public19h UF table are not imputed as zero; national source totals sum only listed rows.',
          'These comparisons neither reveal the time of notification nor identify additional participation caused by the order.'],
        'code_sha256':digest(ROOT/'scripts/compare_reviewed_time_benchmarks.py'),
        'outputs':[{'path':str(p.relative_to(ROOT)),'sha256':digest(p)} for p in out.glob('*.csv')]}
    atomic_json(out/'comparison.json',result);atomic_json(ROOT/'reports/time-benchmark-comparison-reviewed.json',result)
    print(bn.to_json(orient='records'))
if __name__=='__main__':main()
