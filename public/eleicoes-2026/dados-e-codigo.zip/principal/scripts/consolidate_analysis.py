"""Resume-ready local consolidation after explicit input coverage gates.

This supervisor does not mark the scientific study complete and does not publish
or alter source data. It preserves each prior report before a versioned analysis.
"""
import json,re,subprocess,sys,time
from pathlib import Path
from analysis_common import ROOT,atomic_json,code_fingerprint,digest,inputs,now

JOB=ROOT/'metadata/analysis-jobs/consolidation-v1'
CODE=['consolidate_analysis.py','context_sampling_bounds.py','analyze_margin_scenarios.py',
      'analyze_temporal_population.py','analyze_intercompletion.py']

def expected():
    rows=[]
    for r in inputs():
        m=re.fullmatch(r'raw/(2022|2024|2026)/arquivos_urna/bu_imgbu_logjez_rdv_vscmr_\1_([12])t_([A-Z]{2})\.zip',r['path'])
        if m:rows.append((int(m[1]),int(m[2]),m[3]))
    if len(rows)!=164:raise ValueError('Expected164approved native archives')
    return sorted(rows)

def coverage(rows):
    missing=[];structural=0
    for year,turn,uf in rows:
        fp=ROOT/f'analysis/derived/temporal-features-v1/{year}/{turn}t-{uf}/complete.json'
        if not fp.exists():missing.append([year,turn,uf,'features']);continue
        f=json.loads(fp.read_text())
        if f['status']=='structural_absence_no_sections':structural+=1;continue
        rp=ROOT/f'analysis/derived/temporal-reviewed-v1/{year}/{turn}t-{uf}/complete.json'
        if not rp.exists():missing.append([year,turn,uf,'review']);continue
        r=json.loads(rp.read_text())
        if r['input_manifest_sha256']!=digest(fp):raise ValueError('Reviewed coverage source changed')
    return {'expected_archives':len(rows),'structural_absences':structural,'missing':missing}

def run_step(state,key,args,report):
    step=state['steps'].setdefault(key,{})
    if step.get('status') in ['complete','failed']:return
    dest=ROOT/report
    if dest.exists():
        p=ROOT/'reports/analysis-checkpoints'/f'consolidation-{time.time_ns()}'/dest.name
        p.parent.mkdir(parents=True);p.write_bytes(dest.read_bytes());step['previous_report']=str(p.relative_to(ROOT))
    log=JOB/f'{key}-{time.time_ns()}.log'
    step.update(status='running',started_at=now(),args=args,log=str(log.relative_to(ROOT)))
    with log.open('w') as stream:
        child=subprocess.Popen([sys.executable,*args],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
        step['pid']=child.pid;atomic_json(JOB/'checkpoint.json',state)
        child.wait();step.update(status='complete' if child.returncode==0 else 'failed',returncode=child.returncode,finished_at=now())
    if child.returncode==0 and dest.exists():step['result']={'path':report,'sha256':digest(dest)}
    atomic_json(JOB/'checkpoint.json',state)
    print(json.dumps({'at':now(),'step':key,**step}),flush=True)

def main():
    JOB.mkdir(parents=True,exist_ok=True);cp=JOB/'checkpoint.json';code=code_fingerprint(CODE)
    state=json.loads(cp.read_text()) if cp.exists() else {'started_at':now(),'code':code,'steps':{}}
    if state['code']!=code:raise ValueError('Consolidation code changed; explicit migration required')
    for step in state['steps'].values():
        if step.get('status')=='running':raise ValueError('Prior child running/exit state requires inspection before resuming')
    rows=expected()
    while True:
        gates=coverage(rows)
        plan_path=ROOT/'analysis/source-audit/context-validation-v2/plan.json'
        plan=json.loads(plan_path.read_text())
        context_missing=[s for s in plan['strata'] if not (plan_path.parent/f"2026-{s['round']}t-{s['uf']}"/'complete.json').exists()]
        state.update(updated_at=now(),coverage_gate=gates,context_strata_remaining=len(context_missing))
        if not context_missing:run_step(state,'context_uncertainty',['scripts/context_sampling_bounds.py'],'reports/context-sampling-bounds-state.json')
        if not gates['missing']:
            run_step(state,'temporal_population',['scripts/analyze_temporal_population.py','--years','2026,2022,2024'],'reports/temporal-population-state.json')
        if state['steps'].get('temporal_population',{}).get('status')=='complete':
            run_step(state,'intercompletion',['scripts/analyze_intercompletion.py','--years','2026,2022,2024'],'reports/intercompletion-state.json')
        state['status']='pending_inputs_or_consolidating'
        finished=all(state['steps'].get(k,{}).get('status') in ['complete','failed'] for k in ['context_uncertainty','temporal_population','intercompletion'])
        if finished:state['status']='consolidation_finished_pending_scientific_review'
        if any(s.get('status')=='failed' for s in state['steps'].values()):state['status']='step_failure_requires_diagnosis'
        atomic_json(cp,state);atomic_json(ROOT/'reports/analysis-consolidation-state.json',state)
        print(json.dumps({'at':now(),'status':state['status'],'missing_archives':len(gates['missing']),'context_strata_remaining':len(context_missing)}),flush=True)
        if finished or state['status']=='step_failure_requires_diagnosis':break
        time.sleep(180)
if __name__=='__main__':main()
