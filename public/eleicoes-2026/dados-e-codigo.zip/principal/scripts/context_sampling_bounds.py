"""Finite-population audit uncertainty, separate from census vote-count uncertainty."""
import json,time
import numpy as np
import pandas as pd
from scipy.stats import hypergeom
from analysis_common import ROOT,atomic_json,digest,now
from analyze_margin_scenarios import cap_for_scenario


def hypergeom_upper(population,sample,errors,alpha=.05):
    N,n,e=int(population),int(sample),int(errors)
    if not 0<=e<=n<=N or not 0<alpha<1:raise ValueError('Invalid sampling parameters')
    if n==0:return N
    if n==N:return e
    low,high=e,N-n+e
    # Invert P(X<=observed|K); largest non-rejected number of failures.
    while low<high:
        mid=(low+high+1)//2
        if hypergeom.logcdf(e,N,mid,n)>=np.log(alpha):low=mid
        else:high=mid-1
    return low


def main():
    root=ROOT/'analysis/source-audit/context-validation-v2';plan=json.loads((root/'plan.json').read_text())
    missing=[s for s in plan['strata'] if not (root/f"2026-{s['round']}t-{s['uf']}"/'complete.json').exists()]
    if missing:raise SystemExit(f'Wait for all56strata;{len(missing)} incomplete')
    out=ROOT/'analysis/derived/context-sampling-bounds-v1'/str(time.time_ns());out.mkdir(parents=True,exist_ok=False)
    sampled2=[s for s in plan['strata'] if s['round']==2 and s['uf']!='ZZ' and not s['is_census']]
    S=len(sampled2);records=[];selected={};sources=[];failures=0
    for s in plan['strata']:
        folder=root/f"2026-{s['round']}t-{s['uf']}";mp=folder/'complete.json';m=json.loads(mp.read_text());sources.append({'path':str(mp.relative_to(ROOT)),'sha256':digest(mp)})
        tables=[]
        for b in m['batches']:
            p=ROOT/b['path']
            if digest(p)!=b['sha256']:raise ValueError('Audit batch changed')
            tables.append(pd.read_parquet(p))
        d=pd.concat(tables,ignore_index=True) if tables else pd.DataFrame()
        if len(d)!=s['sample_size']:raise ValueError('Incomplete stratum')
        e=int((~d.passed_internal_identity).sum()) if len(d) else 0;failures+=e
        alpha=.05/S if s['round']==2 and s['uf']!='ZZ' and not s['is_census'] else .05
        K=hypergeom_upper(s['population'],s['sample_size'],e,alpha)
        records.append({'year':2026,'round':s['round'],'uf':s['uf'],'population':s['population'],'sample_size':s['sample_size'],
            'observed_identity_failures':e,'is_census':s['is_census'],'alpha':alpha,'upper_possible_identity_failures':K,
            'simultaneous_domestic_second_turn_family':s['round']==2 and s['uf']!='ZZ','family_probability_strata':S,
            'phase_not_explicit':int(d.phase_not_explicit.sum()) if len(d) else 0,'turn_not_explicit':int(d.turn_not_explicit.sum()) if len(d) else 0})
        if s['round']==2:selected[s['uf']]={tuple(x) for x in d[['municipality','zone','section']].itertuples(index=False,name=None)}
    pd.DataFrame(records).to_csv(out/'finite-population-audit-bounds.csv',index=False)
    result={'at':now(),'status':'audit_complete_pending_failure_review' if failures else 'audit_passed_sampling_uncertainty_quantified',
            'output_folder':str(out.relative_to(ROOT)),'strata':len(records),'checked_packages':sum(x['sample_size'] for x in records),
            'observed_identity_failures':failures,'simultaneous_family_alpha':.05,'probability_strata_in_family':S,
            'plan_sha256':digest(root/'plan.json'),'input_manifests':sources,'code_sha256':digest(ROOT/'scripts/context_sampling_bounds.py')}
    if failures:
        result['next_action']='Inspect and version any measurement correction before applying final scientific margin sensitivity.'
    else:
        margin=json.loads((ROOT/'reports/margin-scenario-state.json').read_text())
        c=pd.read_parquet(ROOT/margin['output_folder']/'section-bound-components.parquet');c=c[c.scenario=='strict_other_sections_all'].copy()
        keys=['uf','municipality','zone','section'];temporal=[]
        for mp in sorted((ROOT/'analysis/derived/temporal-reviewed-v1/2026').glob('2t-*/complete.json')):
            f=pd.read_parquet(mp.parent/'sections.parquet')
            cols=keys+['attendance','log_present','context_audited','reviewed_after_ordinary_p0','reviewed_after_ordinary_m60','reviewed_after_ordinary_m300','reviewed_after_ordinary_m900',
                       'reviewed_at_ordinary_deadline','reviewed_gap_if_no_spurious','context_known','reviewed_observed_completions','reviewed_strict_time_eligible','reviewed_startup_allowed_time_eligible']
            temporal.append(f[cols].rename(columns={'attendance':'primary_attendance'}))
        c=c.merge(pd.concat(temporal,ignore_index=True),on=keys,validate='many_to_one')
        p=c[c.race=='BR-PRESIDENTE'].copy();ufbounds={r['uf']:r for r in records if r['round']==2 and r['uf']!='ZZ'}
        summaries=[];allocations=[]
        for shift in [0,60,300,900]:
            p['base_cap']=cap_for_scenario(p,'strict_other_sections_all',shift)
            p['base_adverse']=np.minimum(p.winner_votes,p.base_cap)
            p['remaining_adverse']=p.winner_votes-p.base_adverse
            extra=0
            for uf,g in p[p.uf!='ZZ'].groupby('uf'):
                s=ufbounds[uf];K=s['upper_possible_identity_failures'];sample_keys=selected[uf]
                # Earlier scoped audit and the new probability sample are inspected, so uncertainty is confined to unsampled complement.
                pool=g[g.log_present & ~g.context_audited & ~pd.Series([tuple(x) in sample_keys for x in g[['municipality','zone','section']].itertuples(index=False,name=None)],index=g.index)]
                if len(pool)!=s['population']-s['sample_size']:raise ValueError('Unaudited complement does not match sampling frame')
                worst=int(pool.remaining_adverse.nlargest(K).sum());extra+=worst
                allocations.append({'uf':uf,'cutoff_shift_earlier_seconds':shift,'unsampled_sections':len(pool),'upper_identity_errors':K,'extra_adverse_votes':worst})
            observed=int((p.winner_votes-p.runner_up_votes).sum());base=int(p.base_adverse.sum())
            summaries.append({'race':'BR-PRESIDENTE','cutoff_shift_earlier_seconds':shift,'observed_margin':observed,
                'base_conditional_adverse_bound':base,'additional_adverse_bound_from_context_sampling':extra,
                'minimum_counterfactual_margin_with_audit_uncertainty':observed-base-extra,
                'audit_joint_coverage_level':.95,'not_an_effect_confidence_interval':True})
        pd.DataFrame(summaries).to_csv(out/'presidential-bounds-with-audit-uncertainty.csv',index=False)
        pd.DataFrame(allocations).to_csv(out/'worst-case-context-allocations.csv',index=False)
        result['presidential_sensitivity']=summaries
        result['governor_note']='All previously unaudited internal contexts in the six second-turn governor UFs were censused; no sampling interval applies to their context audit.'
    result['interpretation']=['Sampling uncertainty concerns whether internal context differs from the external section identity, conditional on the audit detection rule and true simple random sampling frame.',
       'The95percent simultaneous bound covers the number of such errors in sampled domestic second-turn strata, not the true causal effect or clock accuracy.',
       'Census vote counts have no sampling confidence interval. Model/causal, coverage and clock assumptions remain separate.',
       'Presidential sensitivity allocates the largest possible additional adverse final-candidate margin contribution to any allowed number of unidentified-context-error sections. It never assigns actual late votes to candidates.']
    result['outputs']=[{'path':str(p.relative_to(ROOT)),'sha256':digest(p)} for p in out.iterdir()]
    atomic_json(out/'analysis.json',result);atomic_json(ROOT/'reports/context-sampling-bounds-state.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ['input_manifests','outputs']}))
if __name__=='__main__':main()
