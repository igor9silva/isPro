"""Explicit ISO/Brazilian date parsing, with immutable versioned corrections.

Only derived BWeb time deltas are changed. Event times, votes, denominators,
identity reviews, and eligibility subsets are asserted unchanged.
"""
import json
import shutil
import time
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

from analysis_common import ROOT, atomic_json, digest, now, require_disk
from extract_native_logs import DATES
from parse_urna_logs import EVENT_FIELDS

TIME_FIELDS = ['opened_elapsed_seconds', 'closed_elapsed_seconds', 'emitted_elapsed_seconds',
               'close_seconds_after_ordinary_deadline', 'open_seconds_after_ordinary_start', 'usable_timing']
KEYS = ['round', 'uf', 'municipality', 'zone', 'section', 'office']


def parse_dates(values):
    s = values.astype('string')
    valid = s.notna() & ~s.str.strip().isin(['', '#NULO#'])
    iso = s.str.match(r'^\d{4}-\d{2}-\d{2}(?:[ T]|$)', na=False)
    br = s.str.match(r'^\d{2}/\d{2}/\d{4}(?: |$)', na=False)
    if (valid & ~(iso | br)).any():
        raise ValueError('Unrecognized nonempty date format; do not guess')
    result = pd.Series(pd.NaT, index=s.index, dtype='datetime64[us]')
    # Parse distinct strings once. The format branch is decided before parsing.
    for mask, fmt in [(valid & iso, 'ISO8601'), (valid & br, 'mixed')]:
        unique = pd.Series(s[mask].unique(), dtype='string')
        dates = pd.to_datetime(unique, format=fmt, dayfirst=fmt == 'mixed', errors='raise')
        lookup = dict(zip(unique, dates))
        result.loc[mask] = s[mask].map(lookup)
    return result


def fix_frame(frame):
    out = frame.copy()
    day = parse_dates(out.election_date).dt.normalize()
    for field in ['opened', 'closed', 'emitted']:
        out[field + '_elapsed_seconds'] = (parse_dates(out[field]) - day).dt.total_seconds()
    out['close_seconds_after_ordinary_deadline'] = out.closed_elapsed_seconds - out.ordinary_deadline_local_seconds
    out['open_seconds_after_ordinary_start'] = out.opened_elapsed_seconds - (out.ordinary_deadline_local_seconds - 9 * 3600)
    out['usable_timing'] = out.usable_turnout & out.uf.ne('ZZ') & out.closed_elapsed_seconds.between(0, 172800)
    assert out.drop(columns=TIME_FIELDS).equals(frame.drop(columns=TIME_FIELDS))
    return out


def changed(a, b):
    return ~((a == b) | (a.isna() & b.isna()))


def main():
    require_disk()
    stamp = str(time.time_ns())
    root = ROOT / 'analysis/derived/date-correction-v1' / stamp
    root.mkdir(parents=True, exist_ok=False)
    sections_root = ROOT / 'analysis/derived/sections-v3'
    reviewed_root = ROOT / 'analysis/derived/temporal-reviewed-v2'
    if sections_root.exists() or reviewed_root.exists():
        raise ValueError('Version already exists; inspect before creating another version')
    canonical, details, reviewed = [], [], []
    for year in [2014, 2018, 2022, 2024, 2026]:
        source = ROOT / f'analysis/derived/sections-v2/{year}/section-office.parquet'
        original = pd.read_parquet(source)
        corrected = fix_frame(original)
        masks = {c: changed(original[c], corrected[c]) for c in TIME_FIELDS}
        any_change = pd.concat(masks, axis=1).any(axis=1)
        for idx in original.index[any_change]:
            r = {c: original.at[idx, c] for c in ['year'] + KEYS}
            for c in TIME_FIELDS:
                r[c + '_before'] = original.at[idx, c]
                r[c + '_after'] = corrected.at[idx, c]
            details.append(r)
        out = sections_root / str(year)
        out.mkdir(parents=True)
        target = out / 'section-office.parquet'
        corrected.to_parquet(target, index=False, compression='zstd')
        record = {'at': now(), 'year': year, 'status': 'explicit_date_format_correction_verified',
            'input': str(source.relative_to(ROOT)), 'input_sha256': digest(source),
            'rows': len(original), 'changed_rows': int(any_change.sum()),
            'changed_by_field': {c: int(m.sum()) for c, m in masks.items()},
            'non_timing_fields_identical': True, 'output': str(target.relative_to(ROOT)),
            'output_sha256': digest(target), 'code_sha256': digest(__file__)}
        atomic_json(out / 'quality.json', record)
        canonical.append(record)
        print(json.dumps({'year': year, 'changed_rows': record['changed_rows']}), flush=True)
        if year not in [2022, 2024, 2026]:
            continue
        reference = corrected[corrected.office.eq(11 if year == 2024 else 1)].set_index(KEYS)
        for mp in sorted((ROOT / f'analysis/derived/temporal-reviewed-v1/{year}').glob('*/complete.json')):
            meta = json.loads(mp.read_text()); turn, uf = meta['round'], meta['uf']
            path = mp.parent / 'sections.parquet'
            if digest(path) != next(r['sha256'] for r in meta['outputs'] if r['path'].endswith('sections.parquet')):
                raise ValueError('Reviewed table changed')
            old = pd.read_parquet(path); new = old.copy()
            lookup = reference.reindex(pd.MultiIndex.from_frame(new[KEYS]))
            if lookup.attendance.isna().any() or not np.array_equal(lookup.attendance.to_numpy(), new.attendance.to_numpy()):
                raise ValueError('Canonical identities or attendance differ')
            for field in TIME_FIELDS:
                new[field] = lookup[field].to_numpy()
            close_changed = changed(old.closed_elapsed_seconds, new.closed_elapsed_seconds)
            dependent = ['last_vote_minus_bweb_close', 'first_vote_minus_bweb_open', 'reviewed_last_vote_minus_bweb_close']
            new['last_vote_minus_bweb_close'] = new.day_last_completed_second - new.closed_elapsed_seconds
            new['first_vote_minus_bweb_open'] = new.day_first_completed_second - new.opened_elapsed_seconds
            new['reviewed_last_vote_minus_bweb_close'] = new.reviewed_last_completed_second - new.closed_elapsed_seconds
            if close_changed.any():
                primary = json.loads((ROOT / meta['input_manifest']).read_text())
                native = json.loads((ROOT / primary['input_manifest']).read_text())
                wanted = {tuple(new.loc[i, ['municipality', 'zone', 'section']]): i for i in new.index[close_changed & new.log_present]}
                found = set()
                date = DATES[year][turn]
                tomorrow = (datetime.strptime(date, '%d/%m/%Y') + timedelta(days=1)).strftime('%d/%m/%Y')
                for batch in native['batches']:
                    if not wanted:
                        break
                    bp = ROOT / batch['path']
                    if digest(bp) != batch['sha256']:
                        raise ValueError('Native batch identity differs')
                    cols = ['municipality', 'zone', 'section', 'event_date'] + [c + '_seconds' for c in EVENT_FIELDS]
                    for chunk in pq.ParquetFile(bp).iter_batches(batch_size=1000, columns=cols):
                        for r in chunk.to_pylist():
                            key = tuple(r[k] for k in ['municipality', 'zone', 'section'])
                            if key not in wanted or r['event_date'] not in [date, tomorrow]:
                                continue
                            which, shift = ('day', 0) if r['event_date'] == date else ('following', 86400)
                            idx = wanted[key]; close = new.at[idx, 'closed_elapsed_seconds']
                            for field in EVENT_FIELDS:
                                name = which + '_' + field + '_matches_bweb_close'
                                new.at[idx, name] = bool(pd.notna(close) and any(v + shift == close for v in r[field + '_seconds']))
                            found.add((key, which))
                assert found == {(k, d) for k in wanted for d in ['day', 'following']}
            dependent += [d + '_' + c + '_matches_bweb_close' for d in ['day', 'following'] for c in EVENT_FIELDS]
            mutable = TIME_FIELDS + dependent
            assert old.drop(columns=mutable).equals(new.drop(columns=mutable))
            changed_fields = {c: int(changed(old[c], new[c]).sum()) for c in mutable}
            out = reviewed_root / str(year) / f'{turn}t-{uf}'
            out.mkdir(parents=True)
            tp = out / 'sections.parquet'; new.to_parquet(tp, index=False, compression='zstd')
            shutil.copyfile(mp.parent / 'review-evidence.json', out / 'review-evidence.json')
            new_meta = {**meta, 'at': now(), 'status': 'context_reviewed_and_explicit_dates_corrected',
                'previous_review_manifest': str(mp.relative_to(ROOT)), 'previous_review_manifest_sha256': digest(mp),
                'canonical_date_manifest': str((sections_root / str(year) / 'quality.json').relative_to(ROOT)),
                'canonical_date_manifest_sha256': digest(sections_root / str(year) / 'quality.json'),
                'date_correction_code_sha256': digest(__file__), 'changed_timing_fields': changed_fields,
                'all_other_fields_identical': True,
                'outputs': [{'path': str(p.relative_to(ROOT)), 'sha256': digest(p), 'bytes': p.stat().st_size}
                            for p in [tp, out / 'review-evidence.json']]}
            atomic_json(out / 'complete.json', new_meta)
            reviewed.append({'year': year, 'round': turn, 'uf': uf, 'changed': changed_fields,
                'all_counts_identity_quality_and_event_times_identical': True,
                'manifest': str((out / 'complete.json').relative_to(ROOT)), 'sha256': digest(out / 'complete.json')})
    pd.DataFrame(details).to_csv(root / 'changed-canonical-rows.csv', index=False)
    result = {'at': now(), 'status': 'versioned_date_correction_verified_pending_aggregate_recomputation',
        'output_folder': str(root.relative_to(ROOT)), 'canonical': canonical, 'reviewed': reviewed,
        'reviewed_archives': len(reviewed), 'vote_event_counts_and_quality_subsets_identical': True,
        'code_sha256': digest(__file__), 'change_table_sha256': digest(root / 'changed-canonical-rows.csv'),
        'limitations': ['Corrects software date interpretation only, not original clock accuracy.',
                       'Raw timestamps, event sequences, counts, attendance and previous derived versions are preserved.']}
    assert len(reviewed) == 158
    atomic_json(root / 'correction.json', result)
    atomic_json(ROOT / 'reports/date-correction-state.json', result)
    print(json.dumps({'status': result['status'], 'archives': len(reviewed)}), flush=True)


if __name__ == '__main__':
    main()
