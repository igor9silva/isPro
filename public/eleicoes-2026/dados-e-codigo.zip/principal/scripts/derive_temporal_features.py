"""Bounded per-section temporal features from completed, hash-verified extracts.

No vote is assigned to a candidate or to the judicial intervention. Clock
thresholds are measurements only. Original extracts and timestamps stay intact.
"""
import argparse
from collections import Counter
from datetime import datetime, timedelta
import json
from pathlib import Path
import re
import time

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

from analysis_common import ROOT, atomic_json, code_fingerprint, digest, now, require_disk
from extract_native_logs import DATES
from parse_urna_logs import EVENT_FIELDS
from watch_analysis_validation import active_jobs

ROOTS = ['analysis/derived/native-logs-v1/2026', 'analysis/derived/native-logs-history-v2']
DELTAS = [-3600,-1800,-900,-600,-300,-60,-5,-1,0,1,5,60,300,600,900,1800,1979,3600,3921,5400,7200]
OUTPUT = ROOT / 'analysis/derived/temporal-features-v1'


def suffix(delta):
    return ('m'+str(-delta)) if delta < 0 else 'p'+str(delta)


def threshold_counts(seconds, deadline):
    seconds = np.asarray(seconds, dtype=np.int64)
    result = {'observed_completions':len(seconds)}
    for delta in DELTAS:
        result['after_ordinary_'+suffix(delta)] = int((seconds > deadline+delta).sum()) if deadline is not None else None
    result['at_ordinary_deadline'] = int((seconds == deadline).sum()) if deadline is not None else None
    result['at_ordinary_plus_3600'] = int((seconds == deadline+3600).sum()) if deadline is not None else None
    result['at_ordinary_plus_7200'] = int((seconds == deadline+7200).sum()) if deadline is not None else None
    result['first_completed_second'] = int(seconds.min()) if len(seconds) else None
    result['last_completed_second'] = int(seconds.max()) if len(seconds) else None
    return result


def native_metrics(record, shift, deadline, bweb_close=None):
    seconds = np.asarray(record['computed_seconds'], dtype=np.int64) + shift
    result = threshold_counts(seconds, deadline)
    result.update({k:int(record[k]) for k in [
        'raw_computed_count','duplicate_computed_count','clock_backwards_count','largest_backward_seconds',
        'line_count','duplicate_line_count','alert_error_lines','clock_message_count','contingency_message_count',
        'suspension_message_count','manual_authorization_count','biometric_authorization_count',
        'text_file_count','nested_archive_count','unparsed_target_date_lines','invalid_clock_lines']})
    for field in EVENT_FIELDS:
        values = np.asarray(record[field+'_seconds'], dtype=np.int64)+shift
        result[field+'_count'] = len(values)
        result[field+'_first'] = int(values.min()) if len(values) else None
        result[field+'_last'] = int(values.max()) if len(values) else None
        result[field+'_matches_bweb_close'] = bool(bweb_close is not None and np.any(values == bweb_close))
    return result, seconds


def process(manifest):
    m = re.search(r'_(\d{4})_([12])t_([A-Z]{2})$', manifest.parent.name)
    if not m:
        raise ValueError('Unknown native manifest name')
    year, turn, uf = int(m[1]),int(m[2]),m[3]
    out = OUTPUT / str(year) / f'{turn}t-{uf}'
    meta = json.loads(manifest.read_text())
    manifest_sha = digest(manifest)
    code = code_fingerprint(['derive_temporal_features.py'])
    if (out/'complete.json').exists():
        old=json.loads((out/'complete.json').read_text())
        if old['input_manifest_sha256'] != manifest_sha or old['code'] != code:
            raise ValueError('Existing feature version differs; preserve it and choose new version')
        for f in old.get('outputs',[]):
            if digest(ROOT/f['path']) != f['sha256']:
                raise ValueError('Temporal output changed')
        return old
    require_disk()
    out.mkdir(parents=True,exist_ok=True)
    if meta['status']=='complete_no_sections':
        result={'at':now(),'year':year,'round':turn,'uf':uf,'status':'structural_absence_no_sections',
                'input_manifest':str(manifest.relative_to(ROOT)),'input_manifest_sha256':manifest_sha,
                'evidence':meta['structural_absence_evidence'],'code':code,'outputs':[]}
        atomic_json(out/'complete.json',result)
        return result
    section_meta_path=ROOT/'analysis/derived/sections-v2'/str(year)/'quality.json'
    section_meta=json.loads(section_meta_path.read_text())
    section_path=ROOT/section_meta['output']
    if digest(section_path)!=section_meta['output_sha256']:
        raise ValueError('Canonical section table changed')
    office=11 if year==2024 else 1
    b=pd.read_parquet(section_path,filters=[('round','=',turn),('uf','=',uf),('office','=',office)])
    keys=['municipality','zone','section']
    if b.duplicated(keys).any():
        raise ValueError('Nonunique primary-office BWeb section')
    lookup=b.set_index(keys)[['attendance','eligible','machine','ordinary_deadline_local_seconds','closed_elapsed_seconds','offset_to_brasilia_seconds']].to_dict('index')
    date=DATES[year][turn]
    tomorrow=(datetime.strptime(date,'%d/%m/%Y')+timedelta(days=1)).strftime('%d/%m/%Y')
    records, hist = {}, Counter()
    source_rows=0
    for batch in meta['batches']:
        p=ROOT/batch['path']
        if digest(p)!=batch['sha256']:
            raise ValueError('Native batch hash changed')
        for group in pq.ParquetFile(p).iter_batches(batch_size=400):
            for r in group.to_pylist():
                if r['event_date'] not in [date,tomorrow]:
                    continue
                source_rows+=1
                key=tuple(r[k] for k in keys)
                target=records.setdefault(key,{'municipality':key[0],'zone':key[1],'section':key[2],
                            'source_member':r['source_member'],'source_package_sha256':r['package_sha256']})
                which='day' if r['event_date']==date else 'following'
                if which in target:
                    raise ValueError('Multiple log packages/dates for a section require explicit reconciliation')
                shift=0 if which=='day' else 86400
                base=lookup.get(key)
                deadline=base['ordinary_deadline_local_seconds'] if base and pd.notna(base['ordinary_deadline_local_seconds']) else None
                close=base['closed_elapsed_seconds'] if base and pd.notna(base['closed_elapsed_seconds']) else None
                metrics, seconds=native_metrics(r,shift,deadline,close)
                metrics['header_matches_bweb']=bool(base and int(base['machine']) in r['machine_ids'])
                metrics['header_ids_json']=json.dumps(r['machine_ids'])
                target[which]=metrics
                # Histogram clock is relative to the ordinary legal deadline;
                # each date is kept separate; unmatched/unlocated records excluded.
                if deadline is not None:
                    relative_minutes=(seconds-int(deadline))//60
                    matched_count=bool(which=='day' and base['attendance']==len(seconds))
                    clock_clean=bool(r['clock_backwards_count']==0 and r['unparsed_target_date_lines']==0 and r['invalid_clock_lines']==0)
                    bins, counts=np.unique(relative_minutes,return_counts=True)
                    for minute,count in zip(bins,counts):
                        hist[(which,int(minute),matched_count,clock_clean)]+=int(count)
    flat=[]
    for key,r in records.items():
        row={k:v for k,v in r.items() if k not in ['day','following']}
        row.update(year=year,round=turn,uf=uf)
        for which in ['day','following']:
            if which not in r:
                raise ValueError('Missing explicit target-date record')
            row.update({which+'_'+k:v for k,v in r[which].items()})
        flat.append(row)
    n=pd.DataFrame(flat)
    joined=b.merge(n,on=keys+['year','round','uf'],how='outer',indicator='coverage',validate='one_to_one')
    joined['log_present']=joined['coverage'].ne('left_only')
    joined['bweb_present']=joined['coverage'].ne('right_only')
    joined['count_matches_day']=joined['coverage'].eq('both') & joined['day_observed_completions'].eq(joined['attendance'])
    joined['count_matches_two_days']=joined['coverage'].eq('both') & (joined['day_observed_completions']+joined['following_observed_completions']).eq(joined['attendance'])
    joined['count_difference_day']=joined['day_observed_completions']-joined['attendance']
    joined['unobserved_completions_if_no_spurious']=(-joined['count_difference_day']).clip(lower=0)
    joined.loc[~joined['log_present'],'unobserved_completions_if_no_spurious']=joined.loc[~joined['log_present'],'attendance']
    joined['strict_same_day_time_eligible']=(joined['count_matches_day'] & joined['uf'].ne('ZZ')
        & joined['following_observed_completions'].eq(0) & joined['day_clock_backwards_count'].eq(0)
        & joined['day_unparsed_target_date_lines'].eq(0) & joined['day_invalid_clock_lines'].eq(0))
    joined['last_vote_minus_bweb_close']=joined['day_last_completed_second']-joined['closed_elapsed_seconds']
    joined['first_vote_minus_bweb_open']=joined['day_first_completed_second']-joined['opened_elapsed_seconds']
    joined['coverage']=joined['coverage'].astype(str)
    target=out/'sections.parquet'
    if target.exists():
        raise ValueError('Refusing to overwrite an incomplete output')
    joined.to_parquet(target,index=False,compression='zstd')
    hp=out/'minute-histogram.csv'
    pd.DataFrame([{'date_group':k[0],'minutes_after_ordinary_deadline':k[1],'same_day_count_matches':k[2],
                   'clock_parse_clean':k[3],'completions':v} for k,v in sorted(hist.items())]).to_csv(hp,index=False)
    result={'at':now(),'year':year,'round':turn,'uf':uf,'status':'features_built_pending_exception_review',
            'input_manifest':str(manifest.relative_to(ROOT)),'input_manifest_sha256':manifest_sha,
            'section_table_manifest':str(section_meta_path.relative_to(ROOT)),'section_table_manifest_sha256':digest(section_meta_path),
            'source_date_rows':source_rows,'section_rows':len(joined),'bweb_only':int(joined['coverage'].eq('left_only').sum()),
            'native_only':int(joined['coverage'].eq('right_only').sum()),'exact_day_count_matches':int(joined['count_matches_day'].sum()),
            'matched_count_discrepancies':int((joined['coverage'].eq('both') & ~joined['count_matches_day']).sum()),
            'following_day_completions':int(joined['following_observed_completions'].sum()),
            'observed_post_deadline_same_day':int(joined.get('day_after_ordinary_p0',pd.Series(dtype=float)).sum()),
            'observed_post_deadline_strict_count_clock_subset':int(joined.loc[joined['strict_same_day_time_eligible'],'day_after_ordinary_p0'].sum()) if 'day_after_ordinary_p0' in joined else 0,
            'potential_unobserved_votes_if_no_spurious':int(joined['unobserved_completions_if_no_spurious'].sum()),
            'outputs':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':digest(p)} for p in [target,hp]],
            'code':code,'limitations':['Observed clock counts are not caused-by-extension counts.','Missing logs and unequal counts are retained; the gap bound assumes no spurious logged completions.','Strict subset excludes all recorded clock reversals, even startup-only; detailed clock diagnostics and sensitivity must follow.','Seconds1979 and3921 after17h refer to embedded court timestamps17:32:59/18:05:21, not known implementation times.','Minute bins are relative to each section ordinary deadline; overseas unknown offset remains excluded from deadline counts.']}
    atomic_json(out/'complete.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ['outputs','limitations','code']}),flush=True)
    return result


def main():
    p=argparse.ArgumentParser();p.add_argument('--watch',action='store_true');p.add_argument('--year',type=int);p.add_argument('--uf');p.add_argument('--round',type=int)
    args=p.parse_args();errors={}
    while True:
        results=[]
        for root in ROOTS:
            for manifest in sorted((ROOT/root).rglob('complete.json')):
                m=re.search(r'_(\d{4})_([12])t_([A-Z]{2})$',manifest.parent.name)
                if not m:continue
                if args.year and int(m[1])!=args.year:continue
                if args.round and int(m[2])!=args.round:continue
                if args.uf and m[3]!=args.uf:continue
                try:
                    results.append(process(manifest));errors.pop(str(manifest.relative_to(ROOT)),None)
                except Exception as e:
                    errors[str(manifest.relative_to(ROOT))]={'at':now(),'error':repr(e)}
                    print(json.dumps(errors[str(manifest.relative_to(ROOT))]),flush=True)
        active=active_jobs() if args.watch else []
        atomic_json(ROOT/'reports/temporal-feature-state.json',{'at':now(),'status':'running' if active else 'features_finished_pending_scientific_review',
                    'archives':len(results),'errors':errors,'active_extraction_jobs':active,
                    'outputs':[{'year':r['year'],'round':r['round'],'uf':r['uf'],'status':r['status']} for r in results]})
        if not args.watch or not active:break
        time.sleep(300)


if __name__=='__main__':main()
