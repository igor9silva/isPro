"""Baseline differences of late-closure cohorts, never a treatment estimator."""
import json
import time

import numpy as np
import pandas as pd

from analysis_common import ROOT, atomic_json, digest, now


def moments(values, weights):
    keep = np.isfinite(values) & np.isfinite(weights) & (weights > 0)
    if not keep.any():
        return None, None, 0
    x, w = values[keep], weights[keep]
    mean = np.average(x, weights=w)
    return float(mean), float(np.average((x-mean)**2, weights=w)), int(len(x))


def main():
    source = json.loads((ROOT / 'reports/election-comparison-state.json').read_text())
    source_folder = ROOT / source['folder']
    folder = ROOT / 'analysis/derived/closure-selection-v2' / str(time.time_ns())
    folder.mkdir(parents=True, exist_ok=False)
    out, territories, identities = [], [], []
    for year in [2018, 2022, 2024, 2026]:
        path = source_folder / f'{year}-within-year-pairs.parquet'
        q = pd.read_parquet(path)
        q = q[q.exact_key_pair & q.uf.ne('ZZ')].copy()
        q['first_turnout_percent'] = q.turnout_rate_1 * 100
        for cutoff in [600, 7200]:
            valid = q.usable_timing_2.fillna(False)
            late = q.close_seconds_after_ordinary_deadline_2.gt(cutoff)
            for weighting in ['section', 'first_turn_electorate']:
                w = np.ones(len(q)) if weighting == 'section' else q.eligible_1.to_numpy(float)
                for var in ['eligible_1', 'attendance_1', 'first_turnout_percent',
                            'close_seconds_after_ordinary_deadline_1', 'open_seconds_after_ordinary_start_1']:
                    x = q[var].to_numpy(float)
                    l = (valid & late).to_numpy(bool)
                    e = (valid & ~late).to_numpy(bool)
                    ml, vl, nl = moments(x[l], w[l]); me, ve, ne = moments(x[e], w[e])
                    sd = np.sqrt((vl+ve)/2) if vl is not None and ve is not None else 0
                    out.append({'year': year, 'late_closure_cutoff_seconds': cutoff, 'weighting': weighting,
                        'first_round_variable': var, 'late_group_n': nl, 'earlier_group_n': ne,
                        'late_mean': ml, 'earlier_mean': me,
                        'difference': ml-me if ml is not None and me is not None else None,
                        'standardized_mean_difference': (ml-me)/sd if sd > 0 else None,
                        'interpretation': 'association_of_baseline_with_future_closure_not_treatment_balance'})
            for uf, g in q[valid].assign(late=late[valid]).groupby('uf'):
                territories.append({'year': year, 'cutoff_seconds': cutoff, 'uf': uf, 'paired_sections': len(g),
                    'late_sections': int(g.late.sum()), 'late_fraction': float(g.late.mean()),
                    'eligible_round1': int(g.eligible_1.sum()),
                    'eligible_round1_in_late_cohort': int(g.loc[g.late, 'eligible_1'].sum())})
        identities.append({'year': year, 'path': str(path.relative_to(ROOT)), 'sha256': digest(path), 'paired_domestic_sections': len(q)})
    pd.DataFrame(out).to_csv(folder / 'baseline-cohort-differences.csv', index=False)
    pd.DataFrame(territories).to_csv(folder / 'cohort-territorial-composition.csv', index=False)
    result = {'at': now(), 'status': 'baseline_selection_diagnostics_complete', 'folder': str(folder.relative_to(ROOT)), 'inputs': identities,
        'measurement': 'The cohort is final BWeb closure later than the year-specific ordinary deadline plus10min or2h. It is not legal exposure.',
        'limitations': ['These are full-census descriptive contrasts in matched sections; no sampling confidence interval or p-value is added.',
            'Conditioning on final closure can select on demand, operational difficulties or the intervention itself. Baseline balance does not establish exchangeability.',
            '2018/2022 and2024 comparisons show the selection mechanism can exist without the2026judicial intervention; they are not interchangeable causal control groups.',
            'Population variances are used to describe standardized differences. Variables with no variation or absent timing remain undefined.',
            'First-turn turnout and closure are prior to the second-turn intervention, but other time-varying determinants remain unmeasured.'],
        'outputs': [{'path': str(p.relative_to(ROOT)), 'sha256': digest(p)} for p in folder.glob('*.csv')]}
    atomic_json(folder / 'diagnostic.json', result)
    atomic_json(ROOT / 'reports/closure-selection-state.json', result)
    print(json.dumps({'status': result['status'], 'folder': result['folder']}))


if __name__ == '__main__':
    main()
