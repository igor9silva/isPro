#!/usr/bin/env python3
"""Download catalogued resources without altering originals; resumable and auditable."""
import argparse
import concurrent.futures as cf
import hashlib
import json
from pathlib import Path
import re
import shutil
import threading
import zipfile
from collect import ROOT, curl, now, save_json

EXCLUDED = {'fotos','proposta_governo','certidao_criminal','bem_candidato','nota_fiscal_candidato'}
LOCK = threading.Lock()
RESERVED = 0

def hashes(path):
    sha256, sha512 = hashlib.sha256(), hashlib.sha512()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(8*1024*1024), b''):
            sha256.update(block)
            sha512.update(block)
    return sha256.hexdigest(), sha512.hexdigest()

def download(r, reserve_gib):
    global RESERVED
    path = ROOT / r['path']
    receipt = ROOT / 'metadata/downloads' / (hashlib.sha256(r['url'].encode()).hexdigest() + '.json')
    if path.exists() and receipt.exists():
        old = json.loads(receipt.read_text())
        if old.get('status') == 'downloaded' and path.stat().st_size == old.get('bytes'):
            return {**old, 'cached': True}
    expected = r.get('bytes_remote') or 1024**3
    with LOCK:
        free = shutil.disk_usage(ROOT).free
        if free - RESERVED - expected < reserve_gib*1024**3:
            return {**r, 'status':'deferred_disk_space', 'free_bytes':free, 'checked_at':now()}
        RESERVED += expected
    result = dict(r, started_at=now())
    try:
        partial = path.with_name(path.name + '.part')
        curl(r['url'], partial, resume=True)
        size = partial.stat().st_size
        if r.get('bytes_remote') and size != r['bytes_remote']:
            raise ValueError(f'Length mismatch: downloaded {size}, HEAD {r["bytes_remote"]}')
        if path.suffix.lower() == '.zip':
            if not zipfile.is_zipfile(partial):
                raise ValueError('Response is not a ZIP archive')
            with zipfile.ZipFile(partial) as archive:
                result['zip_members'] = len(archive.infolist())
                result['uncompressed_bytes'] = sum(i.file_size for i in archive.infolist())
                result['member_extensions'] = sorted({Path(i.filename).suffix.lower() for i in archive.infolist()})
        result['sha256'], result['sha512'] = hashes(partial)
        partial.replace(path)
        headers = Path(str(partial) + '.headers')
        if headers.exists():
            headers.replace(Path(str(path) + '.headers'))
        result.update(status='downloaded', bytes=size, completed_at=now())
        save_json(receipt, result)
    except Exception as e:
        result.update(status='failed', error=str(e), completed_at=now())
        save_json(receipt.with_suffix('.failed.json'), result)
    finally:
        with LOCK:
            RESERVED -= expected
    return result

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--years',type=int,nargs='+')
    p.add_argument('--categories',nargs='+')
    p.add_argument('--turn',choices=['1','2'])
    p.add_argument('--include-large',action='store_true')
    p.add_argument('--workers',type=int,default=4)
    p.add_argument('--reserve-gib',type=int,default=22)
    p.add_argument('--label',default='download')
    p.add_argument('--manifest',default='metadata/resources.json')
    args=p.parse_args()
    rows=json.loads((ROOT/args.manifest).read_text())
    selected=[]
    for r in rows:
        if args.years and r['year'] not in args.years: continue
        if args.categories and r['category'] not in args.categories: continue
        if not args.categories and r['category'] in EXCLUDED: continue
        if r['category']=='arquivos_urna' and not args.include_large: continue
        if args.turn and not re.search(r'(?:_|/)' + args.turn + r't(?:_|/)', r['url'], re.I): continue
        selected.append(r)
    selected.sort(key=lambda r:(-r['year'], not r['url'].endswith('.sha512'), r.get('bytes_remote') or 0,r['url']))
    save_json(ROOT/'reports'/f'{args.label}-selection.json',selected)
    out=[]
    print(f'SELECTED {len(selected)} resources',flush=True)
    with cf.ThreadPoolExecutor(max_workers=args.workers) as pool:
        jobs={pool.submit(download,r,args.reserve_gib):r for r in selected}
        for job in cf.as_completed(jobs):
            r=job.result()
            out.append(r)
            print(f'{len(out)}/{len(selected)} {r["status"]} {r["path"]} {r.get("bytes",0)}',flush=True)
            save_json(ROOT/'reports'/f'{args.label}-progress.json',out)
    total=sum(r.get('bytes',0) for r in out if r['status']=='downloaded')
    print(f'COMPLETE {len(out)} files, {total/1024**3:.3f} GiB, failures={sum(r["status"]=="failed" for r in out)}, deferred={sum(r["status"]=="deferred_disk_space" for r in out)}',flush=True)

if __name__=='__main__':
    main()
