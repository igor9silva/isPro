#!/usr/bin/env python3
"""Archive official contextual pages and the technical/judicial documents they link."""
import html.parser
import json
from pathlib import Path
import re
import urllib.parse
from collect import ROOT, now, save_json
from download import download

PAGES = {
 'tse-prorrogacao': 'https://www.tse.jus.br/comunicacao/noticias/2026/Outubro/esclarecimento-sobre-prorrogacao-da-votacao',
 'tse-votos-apos-17h': 'https://www.tse.jus.br/comunicacao/noticias/2026/Outubro/eleicoes-2026-mais-de-34-mil-votos-foram-registrados-apos-as-17h-no-2o-turno',
 'tse-evolucao-totalizacao': 'https://www.tse.jus.br/comunicacao/noticias/2026/Outubro/como-a-totalizacao-dos-votos-evoluiu-ferramenta-do-tse-permite-acompanhar-o-processo',
 'tse-documentacao-divulgacao': 'https://www.tse.jus.br/eleicoes/informacoes-tecnicas-sobre-a-divulgacao-de-resultados',
 'tse-eleicoes-2026': 'https://www.tse.jus.br/eleicoes/eleicoes-2026/eleicoes-2026',
 'tse-resolucao-23751': 'https://www.tse.jus.br/legislacao/compilada/res/2026/resolucao-no-23-751-de-26-de-fevereiro-de-2026',
 'stf-prorrogacao': 'https://noticias.stf.jus.br/postsnoticias/stf-prorroga-votacao-ate-as-19h-em-locais-onde-urnas-permaneceram-abertas-apos-as-17h/',
 'tse-painel-evolucao': 'https://evolucao-totalizacao.tse.jus.br/',
}

class Anchors(html.parser.HTMLParser):
    def __init__(self):
        super().__init__(); self.links=[]; self.href=None; self.label=''
    def handle_starttag(self,tag,attrs):
        if tag=='a': self.href=dict(attrs).get('href'); self.label=''
    def handle_data(self,data):
        if self.href: self.label+=data
    def handle_endtag(self,tag):
        if tag=='a' and self.href:
            self.links.append((self.href,self.label.strip())); self.href=None

def main():
    results=[]; links=[]
    for label,url in PAGES.items():
        r={'url':url,'path':f'documentation/{label}.html','year':2026,'category':'official_context','name':label,'discovered_at':now()}
        got=download(r,22); results.append(got)
        print(got['status'],label,flush=True)
        if got['status']=='downloaded':
            parser=Anchors(); parser.feed((ROOT/r['path']).read_text(errors='replace'))
            links.extend({'url':urllib.parse.urljoin(url,u),'label':l,'source':url} for u,l in parser.links)
    save_json(ROOT/'metadata/official-page-links.json',links)
    selected={}
    for link in links:
        u,l=link['url'],link['label']
        host=urllib.parse.urlparse(u).hostname or ''
        if not (host.endswith(('.tse.jus.br','.stf.jus.br')) or host=='noticias-stf-wp-prd.s3.sa-east-1.amazonaws.com'): continue
        match=(('/arquivos/divulgacao-de-resultados/' in u) or
               ('/comunicacao/noticias/arquivos/' in u and ('votos' in u)) or
               ('Formato dos arquivos' in l) or
               (link['source']==PAGES['stf-prorrogacao'] and ('decisão' in l.lower() or 'liminar' in l.lower())))
        if match: selected[u]=link
    for i,(url,link) in enumerate(selected.items()):
        basename=Path(urllib.parse.urlparse(url).path).name or f'documento-{i}'
        basename=re.sub(r'[^\w.-]+','-',basename)
        if 'documento' in basename.lower() and urllib.parse.urlparse(url).query:
            basename+= '-'+re.sub(r'[^\w.-]+','-',urllib.parse.urlparse(url).query)
        # TSE file endpoints often omit the file extension; inspect original bytes later.
        r={'url':url,'path':'documentation/files/'+basename,'year':2026,'category':'official_document','name':link['label'],'source_page':link['source'],'discovered_at':now()}
        got=download(r,22); results.append(got); print(got['status'],basename,flush=True)
    save_json(ROOT/'reports/official-evidence.json',results)

if __name__=='__main__': main()
