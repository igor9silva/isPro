"""Preserve executive-office BWeb rows in compact Parquet, without aggregating votes.

Read each CSV completely (therefore checking its ZIP CRC); filter only office rows.
Source row numbers and all original columns are retained. Section deduplication,
time-zone normalization and aggregation are separate, auditable analysis steps.
"""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import json
from pathlib import Path
import re
import time
import traceback

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

from analysis_common import ROOT, archive, atomic_json, code_fingerprint, digest, inputs, now, require_disk

CODE = ["analysis_common.py", "s3_archive.py", "extract_bweb.py"]


def extract(row, output_root):
    out = Path(output_root) / str(row["year"]) / Path(row["path"]).stem
    out.mkdir(parents=True, exist_ok=True)
    code = code_fingerprint(CODE)
    done = out / "complete.json"
    if done.exists():
        previous = json.loads(done.read_text())
        if previous["source_sha256"] != row["hashes"]["sha256"] or previous["code"] != code:
            raise RuntimeError("Existing completed extract uses different input or code; choose a new output version")
        for f in previous["outputs"]:
            if digest(ROOT / f["path"]) != f["sha256"]:
                raise RuntimeError("Existing extracted table changed")
        return previous
    attempt = time.strftime("%Y%m%dT%H%M%S", time.gmtime())
    started = now()
    outputs, row_count, retained, offices = [], 0, 0, {}
    with archive(row, prefer_local=True) as (z, stats):
        csvs = [i for i in z.infolist() if i.filename.lower().endswith(".csv")]
        if not csvs:
            raise ValueError("BWeb archive contains no CSV")
        for ci, info in enumerate(csvs):
            member_rows = 0
            target = out / f"rows-{ci:02d}-{attempt}.parquet"
            partial = target.with_suffix(".parquet.partial")
            writer = None
            try:
                with z.open(info) as raw:
                    for chunk in pd.read_csv(raw, sep=";", encoding="latin1", dtype=str,
                                             keep_default_na=False, na_filter=False,
                                             chunksize=150000, low_memory=False):
                        required = {"CD_CARGO_PERGUNTA", "QT_VOTOS", "QT_COMPARECIMENTO", "CD_MUNICIPIO", "NR_ZONA", "NR_SECAO"}
                        if not required.issubset(chunk.columns):
                            raise ValueError(f"Unsupported BWeb schema; missing {required - set(chunk.columns)}")
                        chunk.insert(0, "source_row", np.arange(member_rows + 2, member_rows + len(chunk) + 2, dtype=np.int64))
                        member_rows += len(chunk)
                        row_count += len(chunk)
                        for office, count in chunk["CD_CARGO_PERGUNTA"].value_counts().items():
                            offices[office] = offices.get(office, 0) + int(count)
                        chosen = chunk[chunk["CD_CARGO_PERGUNTA"].isin(["1", "3", "11"])].copy()
                        retained += len(chosen)
                        chosen.insert(0, "source_member", info.filename)
                        chosen.insert(0, "source_path", row["path"])
                        table = pa.Table.from_pandas(chosen, preserve_index=False)
                        if writer is None:
                            writer = pq.ParquetWriter(partial, table.schema, compression="zstd")
                        writer.write_table(table)
                        atomic_json(out / "progress.json", {"status": "running", "at": now(), "source": row["path"],
                                    "input_rows_read": row_count, "retained_rows": retained})
                        require_disk()
            finally:
                if writer:
                    writer.close()
            partial.replace(target)
            outputs.append({"path": str(target.relative_to(ROOT)), "bytes": target.stat().st_size, "sha256": digest(target),
                            "member": info.filename, "member_crc32": f"{info.CRC:08x}", "member_uncompressed_bytes": info.file_size})
    result = {"status": "complete", "started_at": started, "finished_at": now(), "source_path": row["path"],
              "source_sha256": row["hashes"]["sha256"], "source_etag": row["etag"], "code": code,
              "input_rows_read": row_count, "retained_rows": retained, "input_rows_by_office": offices,
              "retained_offices": ["1", "3", "11"], "outputs": outputs, "read": stats,
              "note": "Original candidate/category rows, no section aggregation. All timestamps remain as published."}
    atomic_json(done, result)
    atomic_json(out / "progress.json", result)
    return result


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--years", default="2026")
    p.add_argument("--uf")
    p.add_argument("--round", type=int)
    p.add_argument("--workers", type=int, default=2)
    p.add_argument("--output", default="analysis/derived/bweb-v1")
    args = p.parse_args()
    years = {int(y) for y in args.years.split(",")}
    rows = [r for r in inputs() if r["year"] in years and r["category"] == "boletins_urna" and r["path"].endswith(".zip")]
    if args.uf:
        rows = [r for r in rows if re.search(r"_[12]t_" + re.escape(args.uf) + r"_", r["path"])]
    if args.round:
        rows = [r for r in rows if f"_{args.round}t_" in r["path"]]
    if not rows:
        raise ValueError("No audited BWeb inputs selected")
    root = ROOT / args.output
    root.mkdir(parents=True, exist_ok=True)
    run = root / ("run-" + time.strftime("%Y%m%dT%H%M%S", time.gmtime()))
    state = {"started_at": now(), "status": "running", "selected": len(rows), "completed": [], "failed": [], "code": code_fingerprint(CODE)}
    atomic_json(run.with_suffix(".json"), state)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        fs = {pool.submit(extract, row, root): row for row in sorted(rows, key=lambda r: r["bytes"])}
        for future in as_completed(fs):
            row = fs[future]
            try:
                result = future.result()
                state["completed"].append({"source_path": row["path"], "retained_rows": result["retained_rows"]})
                print(json.dumps({"at": now(), "completed": row["path"], "retained_rows": result["retained_rows"]}), flush=True)
            except Exception as e:
                state["failed"].append({"source_path": row["path"], "error": str(e), "traceback": traceback.format_exc()})
                print(json.dumps({"at": now(), "failed": row["path"], "error": str(e)}), flush=True)
            state["updated_at"] = now()
            atomic_json(run.with_suffix(".json"), state)
    state.update(status="complete" if not state["failed"] else "failed", finished_at=now())
    atomic_json(run.with_suffix(".json"), state)
    if state["failed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
