"""Decode headerless 2014 BWeb using its archived official 31-field dictionary."""
import csv
import io
import json
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

from analysis_common import ROOT, archive, atomic_json, code_fingerprint, digest, inputs, now, require_disk

# Positional mapping in LEIAME_BUWEB_1T.pdf, archived from the audited AC package.
# "NOME DO PARTIDO" is retained under a legacy-specific name (values include acronyms).
COLUMNS = ["DT_GERACAO", "HH_GERACAO", "CD_PLEITO", "CD_ELEICAO", "SG_UF", "CD_CARGO_PERGUNTA",
           "DS_CARGO_PERGUNTA", "NR_ZONA", "NR_SECAO", "NR_LOCAL_VOTACAO", "NR_PARTIDO", "LEGACY_NOME_PARTIDO",
           "CD_MUNICIPIO", "NM_MUNICIPIO", "DT_BU_RECEBIDO", "QT_APTOS", "QT_ABSTENCOES", "QT_COMPARECIMENTO",
           "CD_TIPO_ELEICAO", "CD_TIPO_URNA", "DS_TIPO_URNA", "NR_VOTAVEL", "NM_VOTAVEL", "QT_VOTOS",
           "CD_TIPO_VOTAVEL", "NR_URNA_EFETIVADA", "CD_CARGA_1_URNA_EFETIVADA", "CD_CARGA_2_URNA_EFETIVADA",
           "DT_CARGA_URNA_EFETIVADA", "CD_FLASHCARD_URNA_EFETIVADA", "DS_CARGO_PERGUNTA_SECAO"]
CODE = ["extract_bweb_2014.py", "analysis_common.py", "s3_archive.py"]


def extract(row):
    out = ROOT / "analysis/derived/bweb-2014-v1" / "2014" / Path(row["path"]).stem
    out.mkdir(parents=True, exist_ok=True)
    code = code_fingerprint(CODE)
    done = out / "complete.json"
    if done.exists():
        saved = json.loads(done.read_text())
        if saved["code"] != code or saved["source_sha256"] != row["hashes"]["sha256"]:
            raise ValueError("Existing extraction differs; preserve and use a new version")
        for f in saved["outputs"]:
            if digest(ROOT / f["path"]) != f["sha256"]:
                raise ValueError("Existing extracted data changed")
        return saved
    count, retained, offices, outputs = 0, 0, {}, []
    stamp = str(time.time_ns())
    with archive(row, prefer_local=True) as (z, stats):
        txts = [i for i in z.infolist() if i.filename.lower().endswith(".txt")]
        if not txts:
            raise ValueError("No headerless TXT in 2014 archive")
        for index, info in enumerate(txts):
            with z.open(info) as stream:
                first = stream.readline().decode("latin1")
            if len(next(csv.reader([first], delimiter=";"))) != len(COLUMNS):
                raise ValueError("Legacy field count differs from official dictionary")
            target = out / f"rows-{index:02d}-{stamp}.parquet"
            partial = target.with_suffix(".parquet.partial")
            writer, member_rows = None, 0
            try:
                with z.open(info) as raw:
                    for chunk in pd.read_csv(raw, sep=";", encoding="latin1", header=None, names=COLUMNS,
                                             dtype=str, keep_default_na=False, na_filter=False, chunksize=150000,
                                             on_bad_lines="error"):
                        chunk.insert(0, "source_row", np.arange(member_rows + 1, member_rows + len(chunk) + 1, dtype=np.int64))
                        member_rows += len(chunk)
                        count += len(chunk)
                        for office, n in chunk["CD_CARGO_PERGUNTA"].value_counts().items():
                            offices[office] = offices.get(office, 0) + int(n)
                        chosen = chunk[chunk["CD_CARGO_PERGUNTA"].isin(["1", "3"])].copy()
                        retained += len(chosen)
                        chosen.insert(0, "ANO_ELEICAO", "2014")
                        chosen.insert(0, "NR_TURNO", "2" if "_2t_" in row["path"] else "1")
                        chosen.insert(0, "source_member", info.filename)
                        chosen.insert(0, "source_path", row["path"])
                        table = pa.Table.from_pandas(chosen, preserve_index=False)
                        if writer is None:
                            writer = pq.ParquetWriter(partial, table.schema, compression="zstd")
                        writer.write_table(table)
                        require_disk()
            finally:
                if writer:
                    writer.close()
            partial.replace(target)
            outputs.append({"path": str(target.relative_to(ROOT)), "bytes": target.stat().st_size,
                            "sha256": digest(target), "member": info.filename, "member_crc32": f"{info.CRC:08x}"})
    result = {"status": "complete", "finished_at": now(), "source_path": row["path"], "source_sha256": row["hashes"]["sha256"],
              "source_etag": row["etag"], "code": code, "input_rows_read": count, "retained_rows": retained,
              "input_rows_by_office": offices, "outputs": outputs, "read": stats,
              "positional_columns": COLUMNS, "dictionary": "analysis/source-audit/dictionaries/bweb-2014-leiame.pdf",
              "inferred_fields": {"ANO_ELEICAO": "2014 from audited archive path", "NR_TURNO": "from archive filename"},
              "unavailable_fields": ["opening timestamp", "closing timestamp", "BU emission timestamp"],
              "note": "2014 cannot supply section closing-time comparisons from these BWeb files; turnout and votes remain usable."}
    atomic_json(done, result)
    return result


def main():
    root = ROOT / "analysis/derived/bweb-2014-v1"
    root.mkdir(parents=True, exist_ok=True)
    run = root / f"run-{time.time_ns()}.json"
    rows = [r for r in inputs() if r["year"] == 2014 and r["category"] == "boletins_urna" and r["path"].endswith(".zip")]
    state = {"started_at": now(), "status": "running", "selected": len(rows), "completed": [], "failed": []}
    with ProcessPoolExecutor(max_workers=2) as pool:
        fs = {pool.submit(extract, r): r for r in rows}
        for f in as_completed(fs):
            r = fs[f]
            try:
                result = f.result()
                state["completed"].append({"source_path": r["path"], "retained_rows": result["retained_rows"]})
            except Exception as e:
                state["failed"].append({"source_path": r["path"], "error": str(e)})
            atomic_json(run, state)
            print(json.dumps({"at": now(), "completed": len(state["completed"]), "failed": len(state["failed"])}), flush=True)
    state.update(status="complete" if not state["failed"] else "failed", finished_at=now())
    atomic_json(run, state)


if __name__ == "__main__":
    main()
