"""Checkpointed bounded extraction of native logs from audited S3 ZIP archives."""
import argparse
from datetime import datetime, timedelta
from concurrent.futures import ProcessPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path
import time
import traceback

import pyarrow as pa
import pyarrow.parquet as pq

from analysis_common import ROOT, archive, atomic_json, code_fingerprint, digest, inputs, now, require_disk
from parse_urna_logs import parse_package, EVENT_FIELDS

CODE = ["analysis_common.py", "s3_archive.py", "parse_urna_logs.py", "extract_native_logs.py"]
DATES = {2026: {1: "04/10/2026", 2: "25/10/2026"},
         2024: {1: "06/10/2024", 2: "27/10/2024"},
         2022: {1: "02/10/2022", 2: "30/10/2022"}}


def make_schema():
    ints = ["pleito", "municipality", "zone", "section", "raw_computed_count", "duplicate_computed_count",
            "clock_backwards_count", "largest_backward_seconds", "line_count", "duplicate_line_count",
            "alert_error_lines", "clock_message_count", "contingency_message_count", "suspension_message_count",
            "manual_authorization_count", "biometric_authorization_count", "first_record_second", "last_record_second",
            "computed_count", "text_file_count", "nested_archive_count", "unparsed_target_date_lines", "invalid_clock_lines"]
    strings = ["uf", "event_date", "apps_with_computed", "versions", "contexts", "package_sha256", "source_member", "source_path"]
    return pa.schema([(s, pa.string()) for s in strings] + [(s, pa.int64()) for s in ints] +
                     [("machine_ids", pa.list_(pa.int64())), ("computed_seconds", pa.list_(pa.int32()))] +
                     [(k + "_seconds", pa.list_(pa.int32())) for k in EVENT_FIELDS])


def extract(row, output_root, include_prior_round=True, batch_size=200):
    out = Path(output_root) / str(row["year"]) / Path(row["path"]).stem
    out.mkdir(parents=True, exist_ok=True)
    code = code_fingerprint(CODE)
    round_no = 2 if "_2t_" in row["path"] else 1
    target_dates = [DATES[row["year"]][round_no]]
    if round_no == 2 and include_prior_round:
        target_dates.insert(0, DATES[row["year"]][1])
    # Preserve the following day explicitly for midnight crossings and recovery.
    target_dates += [(datetime.strptime(d, "%d/%m/%Y") + timedelta(days=1)).strftime("%d/%m/%Y")
                     for d in list(target_dates)]
    cp_path = out / "checkpoint.json"
    cp = {"started_at": now(), "source_path": row["path"], "source_sha256": row["hashes"]["sha256"],
          "source_etag": row["etag"], "code": code, "target_dates": target_dates, "next_member_index": 0,
          "batches": [], "failed_members": [], "stats": {}, "status": "running"}
    if cp_path.exists():
        saved = json.loads(cp_path.read_text())
        for key in ["source_sha256", "source_etag", "code", "target_dates"]:
            if saved[key] != cp[key]:
                raise ValueError("Checkpoint input/code changed; choose a new output version")
        cp = saved
        for batch in cp["batches"]:
            if digest(ROOT / batch["path"]) != batch["sha256"]:
                raise ValueError("Extracted checkpoint batch changed")
        if cp["status"] == "complete":
            return cp
    attempt = time.strftime("%Y%m%dT%H%M%S", time.gmtime())
    with archive(row) as (z, stats):
        members = [x for x in z.infolist() if x.filename.lower().endswith("-log.jez")]
        if not members:
            raise ValueError("No native section logs in audited package")
        index_hash = hashlib.sha256(json.dumps([(i.filename, i.CRC, i.file_size) for i in members]).encode()).hexdigest()
        if cp.get("member_index_sha256", index_hash) != index_hash:
            raise ValueError("Native archive member index changed")
        cp.update(member_count=len(members), member_index_sha256=index_hash,
                  compressed_log_member_bytes=sum(i.compress_size for i in members), status="running")
        atomic_json(cp_path, cp)
        buffer, batch_start = [], cp["next_member_index"]
        for index in range(cp["next_member_index"], len(members)):
            info = members[index]
            try:
                if info.file_size > 256 * 1024**2:
                    raise ValueError("Oversized section package")
                payload = z.read(info)
                parsed, counters = parse_package(payload, info.filename, target_dates)
                for record in parsed:
                    record["source_path"] = row["path"]
                buffer.extend(parsed)
                for k, n in counters.items():
                    cp["stats"][k] = cp["stats"].get(k, 0) + n
            except Exception as e:
                cp["failed_members"].append({"index": index, "member": info.filename, "error": str(e)})
            if (index + 1 - batch_start) >= batch_size or index + 1 == len(members):
                require_disk()
                target = out / f"sections-{batch_start:07d}-{index + 1:07d}-{attempt}.parquet"
                if target.exists():
                    raise ValueError("Refusing to overwrite an extracted batch")
                table = pa.Table.from_pylist(buffer, schema=make_schema())
                pq.write_table(table, target, compression="zstd", row_group_size=500)
                cp["batches"].append({"path": str(target.relative_to(ROOT)), "sha256": digest(target),
                                      "bytes": target.stat().st_size, "rows": len(buffer),
                                      "start_member_index": batch_start, "end_member_index": index + 1})
                cp.update(next_member_index=index + 1, updated_at=now())
                atomic_json(cp_path, cp)
                print(json.dumps({"at": now(), "source": row["path"], "processed": index + 1, "total": len(members),
                                  "failed_members": len(cp["failed_members"])}), flush=True)
                buffer, batch_start = [], index + 1
    cp.update(status="complete" if not cp["failed_members"] else "complete_with_member_errors", finished_at=now(), read=stats)
    atomic_json(cp_path, cp)
    if not cp["failed_members"]:
        atomic_json(out / "complete.json", cp)
    return cp


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--years", default="2026")
    p.add_argument("--round", type=int)
    p.add_argument("--uf")
    p.add_argument("--workers", type=int, default=2)
    p.add_argument("--output", default="analysis/derived/native-logs-v1")
    args = p.parse_args()
    years = {int(y) for y in args.years.split(",")}
    rows = [r for r in inputs() if r["year"] in years and r["category"] == "arquivos_urna" and r["path"].endswith(".zip")]
    if args.round:
        rows = [r for r in rows if f"_{args.round}t_" in r["path"]]
    if args.uf:
        rows = [r for r in rows if r["path"].endswith("_" + args.uf + ".zip")]
    if not rows:
        raise ValueError("No audited native inputs selected")
    root = ROOT / args.output
    root.mkdir(parents=True, exist_ok=True)
    run = root / ("run-" + time.strftime("%Y%m%dT%H%M%S", time.gmtime()) + ".json")
    state = {"started_at": now(), "status": "running", "selected": len(rows), "completed": [], "failed": [], "code": code_fingerprint(CODE)}
    atomic_json(run, state)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        # Largest first reduces the final-file tail. Pilot runs use an explicit UF.
        fs = {pool.submit(extract, row, root): row for row in sorted(rows, key=lambda r: r["bytes"], reverse=True)}
        for f in as_completed(fs):
            row = fs[f]
            try:
                result = f.result()
                if result["failed_members"]:
                    state["failed"].append({"source_path": row["path"], "member_errors": len(result["failed_members"])})
                else:
                    state["completed"].append({"source_path": row["path"], "member_count": result["member_count"]})
            except Exception as e:
                state["failed"].append({"source_path": row["path"], "error": str(e), "traceback": traceback.format_exc()})
                print(json.dumps({"at": now(), "source": row["path"], "error": str(e)}), flush=True)
            state["updated_at"] = now()
            atomic_json(run, state)
    state.update(status="complete" if not state["failed"] else "failed", finished_at=now())
    atomic_json(run, state)
    if state["failed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
