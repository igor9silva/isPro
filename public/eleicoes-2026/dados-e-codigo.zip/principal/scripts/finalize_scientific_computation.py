"""Record the completed internal scientific review; document release is separate.

The narrative judgments below are the review decisions, not a claim that a
successful process alone constitutes scientific approval or external peer review.
"""
import json
import re
import shutil
import time
import pandas as pd
from analysis_common import ROOT, atomic_json, digest, now


def main():
    numeric = json.loads((ROOT / 'reports/analysis-numerical-verification-state.json').read_text())
    dates = json.loads((ROOT / 'reports/date-correction-verification.json').read_text())
    context = json.loads((ROOT / 'reports/context-sampling-bounds-state.json').read_text())
    assert numeric['status'] == 'passed_numerical_crosschecks_not_causal_identification'
    assert dates['status'] == 'passed_date_correction_and_downstream_recomputation'
    assert context['status'] == 'audit_passed_sampling_uncertainty_quantified'
    test_log = (ROOT / 'reports/analysis-test-suite-final.log').read_text()
    assert re.search(r'Ran 58 tests', test_log) and test_log.rstrip().endswith('OK')
    old = json.loads((ROOT / 'reports/evidence-matrix-state.json').read_text())
    rows = json.loads((ROOT / old['output_folder'] / 'matrix.json').read_text())['rows']
    updates = {
        'A01': ('Cronologia auditada: autuação, assinatura e comunicação são distintas. Circular relatada às 17h49; a aplicação por seção não foi observada. Discordância de Coari preservada.',
                ['reports/regional-communication-review.json', 'reports/documentary-time-window-state.json']),
        'A02': ('3.388 objetos e 521.157.604.697 bytes auditados; 276 BWeb convertidos. Cobertura de 164 arquivos nativos: 158 com seções e seis ausências estruturais. Lacunas por seção/turno enumeradas, sem tratá-las como falha dos ZIPs.',
                ['reports/analysis-consolidation-state.json', 'reports/temporal-population-state.json', 'reports/measurement-exception-review-state.json']),
        'A03': ('Datas, CRC, contexto, contagens e relógios revisados. Cinco falhas de leitura recuperadas; 63.362 inspeções adicionais sem falha de identidade detectada. Correção explícita de um horário BWeb de 2024 em 6.853.065 linhas, com provas de invariância dos eventos e conjuntos de qualidade.',
                ['reports/date-correction-verification.json', 'reports/context-sampling-bounds-state.json', 'reports/measurement-exception-review-state.json']),
        'A04': ('2026 doméstico segundo turno: 34.050 conclusões estritamente após 17h; 34.330 inclusivas; lacuna 322. As 108 células oficiais de votos foram reproduzidas sob a convenção alternativa, sem inferir seu algoritmo. História de 2022/2024 e sensibilidade de passagem de data concluídas.',
                ['reports/temporal-population-state.json', 'reports/following-day-review-state.json', 'reports/documentary-time-window-state.json']),
        'A05': ('Tabelas nacionais, por UF e município, denominadores, concentração e indicadores operacionais concluídos para os três anos com logs. Intervalos completos por configuração: em 2026, medianas 101/70/73 segundos, sem confundi-los com espera ou serviço puro.',
                ['reports/intercompletion-state.json', 'reports/temporal-population-state.json']),
        'A06': ('BWeb de cinco eleições e logs nacionais de 2022/2024/2026 comparados com perdas de vínculo explícitas. Primeiro turno 2022–2026 inverte o sinal no subconjunto de eleitorado estável; resultado contrário preservado. Municipal 2024 e prazo local 2018 diferenciados.',
                ['reports/election-comparison-state.json', 'reports/temporal-population-state.json', 'reports/supplemental-sensitivity-state.json']),
        'A07': ('Não identificação pontual demonstrada por dois mundos com os mesmos observáveis: fila ordinária e admissões adicionais. Não significa efeito zero. Ausência de chegada, comunicação/aplicação por seção e contrafactual impede DiD/RDD causal defensável.',
                ['analysis/findings/causal-identification-v2.json']),
        'A08': ('Coorte de fechamento tardio já difere no primeiro turno: +31,29 aptos e +694,09 segundos. Histórias anteriores, múltiplas inicializações, abertura, suspensão e intervalos examinados; suspensão mostra taxas praticamente iguais. Não se inventa exposição de transporte, fila ou hardware.',
                ['reports/closure-selection-state.json', 'reports/temporal-population-state.json', 'reports/intercompletion-state.json']),
        'A09': ('Cortes, relógios, identidades, cobertura, pesos e perdas de ligação examinados. Retenções históricas: 59 sequências alternativas; passagem de data: 215 eventos próprios. Auditoria finita: limites hipergeométricos com Bonferroni nos 21 estratos domésticos amostrais; censos sem IC.',
                ['reports/context-sampling-bounds-state.json', 'reports/supplemental-sensitivity-state.json', 'reports/following-day-review-state.json', 'reports/date-correction-verification.json']),
        'A10': ('84 limites básicos positivos sob participação adicional; mínimo presidencial básico de 15 min 3.472.537, RN 21.665. Com incerteza de identidade alocada adversamente, mínimo presidencial 2.262.970. Um participante adicional altera a margem em no máximo um voto.',
                ['reports/margin-scenario-state.json', 'reports/context-sampling-bounds-state.json', 'reports/analysis-numerical-verification-state.json']),
        'A11': ('Tabelas canônicas/revisadas, CSV/Parquet agregados, código, dependências, sementes e hashes preservados. Dicionários centrais e dos estimadores completos. Documentos finais e preservação privada sujeitos ao gate separado de entrega.',
                ['reports/data-dictionary-state.json', 'reports/aggregate-data-dictionary-state.json', 'reports/analysis-numerical-verification-state.json']),
        'A12': ('Revisão interna confrontou cifras, denominadores, não identificação, seleção, inferência ecológica, limites, relógios e fontes. Sete famílias de conferência numérica e 58 testes passaram; bug de datas corrigido antes da entrega. Não houve revisão externa por pares.',
                ['reports/analysis-numerical-verification-state.json', 'reports/date-correction-verification.json', 'reports/analysis-test-suite-final.log'])
    }
    limitations = {
        'A02': 'Um SHA1 HTTP404 com ZIP preservado; dez auxiliares sem binário arquivado. Lacunas de membros e contagens históricas/2026 são explicitadas.',
        'A03': 'Auditoria de identidade depende da regra de detecção. Relógios não certificados; equivalência de contagem não autentica sozinha um contexto.',
        'A04': 'Registro tardio não é participação causada pela decisão. Definição oficial das coortes de fechamento permanece sem reprodução integral.',
        'A06': 'Chaves estáveis não garantem mesmos eleitores. 2014 sem horários; 2018 prazo local; 2024 municipal. A estabilidade de 5% é exploratória.',
        'A09': 'A cobertura amostral trata apenas identidade sob o plano; cortes não certificam erros reais dos relógios nem identificam efeito causal.',
        'A10': 'Não cobre supressão, mudança de escolha dos demais, antecipação anterior ao corte ou efeitos institucionais irrestritos.',
        'A11': 'Reprodução integral exige acesso privado ao acervo; fontes atualizadas na origem não substituem o snapshot preservado.',
        'A12': 'Revisão interna não equivale a certificação externa do processo eleitoral. Limitações de identificação permanecem mesmo após concluir o estudo.'
    }
    out = ROOT / 'analysis/findings/evidence-matrix-v2' / str(time.time_ns())
    out.mkdir(parents=True, exist_ok=False)
    for r in rows:
        result, artifacts = updates[r['module']]
        r.update(result=result, status='scientifically_reviewed_with_documented_limitations')
        r['artifacts'] = list(dict.fromkeys(r['artifacts'] + artifacts))
        r['limitation'] = limitations.get(r['module'], r['limitation'])
        if r['module'] in ['A03', 'A09']:
            r['uncertainty'] = 'Mensuração, cobertura e amostragem da auditoria separadas; contagens censitárias sem intervalo amostral.'
        if r['module'] == 'A10':
            r['uncertainty'] = 'Mecanismo e mensuração; sensibilidade amostral de identidade aplicada e separada do efeito causal.'
        r['artifact_hashes'] = [{'path': p, 'sha256': digest(ROOT / p)} for p in r['artifacts']]
    atomic_json(out / 'matrix.json', {'at': now(), 'status': 'scientific_review_complete_document_release_pending', 'rows': rows})
    flat = [{**{k:v for k,v in r.items() if k not in ['artifacts','artifact_hashes']}, 'artifacts': ' | '.join(r['artifacts'])} for r in rows]
    pd.DataFrame(flat).to_csv(out / 'matrix.csv', index=False)
    checklist = {'at': now(), 'all_modules_scientifically_reviewed': True, 'all_modules_final_approved': False,
        'items': [{'module': r['module'], 'question': r['question'], 'scientifically_reviewed': True,
                   'reviewed_scope': r['result'], 'open_limitations': r['limitation'], 'evidence': r['artifacts'],
                   'final_approved': False} for r in rows], 'release_remaining': ['PDF visual review', 'Private preservation and delivery']}
    atomic_json(out / 'checklist.json', checklist)
    atomic_json(ROOT / 'reports/evidence-matrix-state.json', {'at': now(), 'status': 'scientific_review_complete_document_release_pending',
        'output_folder': str(out.relative_to(ROOT)), 'modules': 12, 'scientifically_reviewed': 12, 'final_approved': 0})
    result = {'at': now(), 'status': 'scientific_computation_reviewed_pending_document_release',
        'review_type': 'internal_scientific_and_numerical_review_not_external_peer_review',
        'scope': 'All twelve planned fronts executed; causal point nonidentification is demonstrated, not replaced by a null-effect assertion.',
        'decisions': [
            'Retain municipal clock conversion and exact boundary sensitivity; 108-cell reproduction does not prove the official algorithm.',
            'Retain conflicting preliminary Coari account and final logs, without inventing administrative cause.',
            'Retain historical excesses, missing records, post-completion clock reversals and the sign reversal under the 5 percent linkage sensitivity.',
            'Preserve same-day primary estimates; next-day and retained-turn sequences are separate, disjoint, audited sensitivities.',
            'Correct one ISO-derived BWeb timing row with explicit versioning and verify every unaffected event/identity/quality field.',
            'Do not infer preference by timestamp, causal exposure from closure, or pure queue capacity from intercompletion intervals.',
            'Keep 95 percent audit coverage separate from census, absolute clock, model and causal-identification uncertainty.',
            'Restrict positive-margin conclusion to additional participation with no suppression, earlier anticipation or changes in other choices.'
        ], 'checks': numeric['checks'], 'test_count': 58, 'date_review': 'reports/date-correction-verification.json',
        'matrix': str((out / 'matrix.json').relative_to(ROOT)), 'code_sha256': digest(__file__),
        'inputs': [{'path': p, 'sha256': digest(ROOT / p)} for p in [
            'reports/analysis-numerical-verification-state.json', 'reports/date-correction-verification.json',
            'reports/context-sampling-bounds-state.json', 'reports/analysis-test-suite-final.log',
            'analysis/report-source/manuscript-v2.json', 'analysis/report-source/technical-appendix-v2.json']]}
    atomic_json(ROOT / 'reports/scientific-computation-review.json', result)
    p = ROOT / 'reports/analysis-state.json'; state = json.loads(p.read_text())
    backup = ROOT / 'reports/analysis-checkpoints' / ('pre-final-review-' + str(time.time_ns()))
    backup.mkdir(parents=True); shutil.copy2(p, backup / p.name)
    state.update(updated_at=now(), status='scientific_computation_reviewed_document_release_pending', active_jobs=[],
        next_action='Render and visually inspect final PDFs, preserve all final artifacts privately, then deliver and close the automation.',
        pending_concrete=['Final PDF visual review', 'Private evidence and final artifact publication', 'Final delivery and automation deletion'],
        latest_review='reports/scientific-computation-review.json', evidence_matrix='reports/evidence-matrix-state.json')
    for r in rows:
        m = state['required_modules'][r['module']]
        m.update(status=r['status'], progress=r['result'], uncertainty=r['uncertainty'], limitation=r['limitation'], outputs=r['artifacts'])
    atomic_json(p, state)
    print(json.dumps({'status': result['status'], 'modules_reviewed': 12, 'matrix': str(out.relative_to(ROOT))}))


if __name__ == '__main__':
    main()
