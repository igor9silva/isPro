"""Read selected original packages to diagnose count gaps and clock reversals.

Only aggregate operational diagnostics leave memory. No voter identifiers or
candidate-event links are retained. Every saved case refers to immutable inputs.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import time

import pandas as pd

from analysis_common import ROOT, archive, atomic_json, code_fingerprint, inputs, now
from extract_native_logs import DATES
from parse_urna_logs import HEADER, COMPLETED, EVENTS, texts_in_package
from parse_urna_logs_legacy import to_parser_container
from watch_analysis_validation import active_jobs

OUT=ROOT/'analysis/source-audit/log-exceptions-v1'


def category(message):
    if message==COMPLETED:return 'completed_vote'
    if message in EVENTS:return EVENTS[message]
    lower=message.lower()
    for token,label in [('recuper','recovery'),('suspens','suspension'),('suspenso','suspension'),
                        ('relógio','clock'),('relogio','clock'),('ajuste','adjustment'),
                        ('encerramento','closing'),('reinici','restart'),('deslig','shutdown')]:
        if token in lower:return label
    return 'other'


def inspect(payload,member,date):
    counters={}; converted=to_parser_container(payload,counters=counters)
    stats=Counter();seen=set();dates=defaultdict(Counter);texts=[];backwards=[]
    for label,data in texts_in_package(converted,member,stats):
        prior={}; completed_before=Counter(); perdate=defaultdict(Counter)
        for lineno,line in enumerate(data.splitlines(),1):
            match=HEADER.fullmatch(line)
            if not match:continue
            date_b,h,m,s,severity,machine_b,app_b,message_b,mac=match.groups()
            day=date_b.decode();second=int(h)*3600+int(m)*60+int(s);machine=int(machine_b)
            message=message_b.decode('latin1').strip();kind=category(message)
            perdate[day]['lines']+=1
            if kind=='completed_vote':perdate[day]['completed_raw']+=1
            identity=hashlib.blake2b(line,digest_size=16).digest()
            if identity in seen:
                if kind=='completed_vote':dates[day]['completed_duplicate']+=1
                continue
            seen.add(identity)
            dates[day]['unique_'+kind]+=1
            old=prior.get((day,machine))
            if old and second<old['second'] and day==date:
                backwards.append({'text_member':label,'line':lineno,'header_id':machine,
                    'previous_second':old['second'],'new_second':second,'backward_seconds':old['second']-second,
                    'previous_category':old['category'],'new_category':kind,
                    'completed_before_in_this_text':completed_before[day]})
            prior[(day,machine)]={'second':second,'category':kind}
            if kind=='completed_vote':
                completed_before[day]+=1
                perdate[day]['completed_unique']+=1
                key='first_completed_second'
                if key not in perdate[day]:perdate[day][key]=second
                perdate[day]['last_completed_second']=second
        texts.append({'member':label,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
                      'dates':{d:dict(c) for d,c in perdate.items()}})
    return {'original_package_sha256':hashlib.sha256(payload).hexdigest(), 'original_package_bytes':len(payload),
            'container_stats':{**dict(stats),**counters},'dates':{d:dict(c) for d,c in dates.items()},
            'texts':texts,'backwards':backwards,
            'reversals_before_any_completed_vote_in_text':sum(x['completed_before_in_this_text']==0 for x in backwards),
            'reversals_after_completed_vote_in_text':sum(x['completed_before_in_this_text']>0 for x in backwards),
            'largest_backward_seconds':max((x['backward_seconds'] for x in backwards),default=0)}


def pass_once():
    indexed={r['path']:r for r in inputs()};output=[];errors=[]
    for validation in sorted((ROOT/'reports/log-validation').glob('*.json')):
        v=json.loads(validation.read_text())
        if 'exceptions' not in v:continue
        cases=pd.read_csv(ROOT/v['exceptions'])
        cases=cases[(cases['difference']!=0)|(cases['clock_backwards_count']>0)]
        if cases.empty:continue
        year,turn,uf=v['year'],v['round'],v['uf'];date=DATES[year][turn]
        source=f'raw/{year}/arquivos_urna/bu_imgbu_logjez_rdv_vscmr_{year}_{turn}t_{uf}.zip'
        folder=OUT/f'{year}-{turn}t-{uf}';folder.mkdir(parents=True,exist_ok=True)
        pending=[]
        for r in cases.to_dict('records'):
            dest=folder/f"{int(r['municipality'])}-{int(r['zone'])}-{int(r['section'])}.json"
            if dest.exists():output.append(str(dest.relative_to(ROOT)))
            else:pending.append((r,dest))
        if not pending:continue
        try:
            with archive(indexed[source]) as (z,read):
                for case,dest in pending:
                    result=inspect(z.read(case['source_member']),case['source_member'],date)
                    result.update(at=now(),year=year,round=turn,uf=uf,municipality=int(case['municipality']),zone=int(case['zone']),section=int(case['section']),
                        source_archive=source,source_archive_sha256=indexed[source]['hashes']['sha256'],source_member=case['source_member'],
                        bweb_attendance=int(case['comparecimento']),extracted_count=int(case['computed_count']),
                        difference=int(case['difference']),code=code_fingerprint(['inspect_log_exceptions.py']),
                        note='Diagnostics only; no timestamps repaired and no missing vote times imputed. Date counts include operational records from other rounds and must not be added indiscriminately.')
                    atomic_json(dest,result);output.append(str(dest.relative_to(ROOT)))
            print(json.dumps({'at':now(),'archive':source,'new_cases':len(pending),'range_bytes':read.get('bytes_fetched')}),flush=True)
        except Exception as e:
            errors.append({'source':source,'error':repr(e)})
            print(json.dumps(errors[-1]),flush=True)
    return output,errors


def main():
    p=argparse.ArgumentParser();p.add_argument('--watch',action='store_true');args=p.parse_args()
    while True:
        output,errors=pass_once();active=active_jobs() if args.watch else []
        atomic_json(ROOT/'reports/log-exception-inspection-state.json',{'at':now(),'status':'running' if active else 'finished_pending_case_review',
                    'cases':len(output),'case_files':output,'execution_errors':errors,'active_extractions':active})
        if not active:break
        time.sleep(300)


if __name__=='__main__':main()
