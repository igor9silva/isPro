"""Preserve five reviewed figures and add completed-history/audit sensitivities."""
import json
import shutil
import time

import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

from analysis_common import ROOT, atomic_json, digest, now
from make_scientific_figures import BLUE, ORANGE, GREY, pt


def main():
    previous = ROOT / 'reports/scientific-figures-state.json'
    old = json.loads(previous.read_text())
    pop = json.loads((ROOT / 'reports/temporal-population-state.json').read_text())
    if len(pop['coverage']) != 6 or not all(r['population_complete'] for r in pop['coverage']):
        raise ValueError('Final historical population coverage is required')
    out = ROOT / 'analysis/figures/scientific-final-v1' / str(time.time_ns())
    out.mkdir(parents=True, exist_ok=False)
    captions = []
    inputs = [{'path': str(previous.relative_to(ROOT)), 'sha256': digest(previous)}]
    for item in old['captions']:
        if not item['name'].startswith(('01-', '02-', '03-', '05-')):
            continue
        captions.append(item)
        for ext in ['png', 'svg', 'pdf']:
            p = ROOT / old['output_folder'] / (item['name'] + '.' + ext)
            inputs.append({'path': str(p.relative_to(ROOT)), 'sha256': digest(p)})
            shutil.copy2(p, out / p.name)

    def read(report, filename):
        rp = ROOT / ('reports/' + report + '.json'); r = json.loads(rp.read_text())
        p = ROOT / r['output_folder'] / filename
        inputs.extend([{'path': str(rp.relative_to(ROOT)), 'sha256': digest(rp)},
                       {'path': str(p.relative_to(ROOT)), 'sha256': digest(p)}])
        return pd.read_csv(p)

    def save(fig, name, caption):
        for ext in ['png', 'svg', 'pdf']:
            fig.savefig(out / (name + '.' + ext), dpi=180, bbox_inches='tight')
        plt.close(fig); captions.append({'name': name, 'caption': caption})

    b = read('margin-scenario-state', 'conditional-margin-bounds.csv')
    a = read('context-sampling-bounds-state', 'presidential-bounds-with-audit-uncertainty.csv')
    q = b[(b.scenario == 'strict_other_sections_all') & (b.cutoff_shift_earlier_seconds == 900)].copy()
    extra = a[a.cutoff_shift_earlier_seconds == 900].iloc[0]
    q['sampling_extra'] = 0
    q.loc[q.race == 'BR-PRESIDENTE', 'sampling_extra'] = extra.additional_adverse_bound_from_context_sampling
    q['base_ratio'] = 100 * q.maximum_adverse_margin_change / q.observed_margin
    q['extra_ratio'] = 100 * q.sampling_extra / q.observed_margin
    q['minimum_with_audit'] = q.minimum_counterfactual_margin - q.sampling_extra
    q = q.sort_values('base_ratio')
    labels = q.race.str.replace('BR-PRESIDENTE', 'Presidência', regex=False).str.replace('-GOVERNADOR', ' · governo', regex=False)
    fig, ax = plt.subplots(figsize=(10, 4.9))
    ax.barh(labels, q.base_ratio, color=BLUE, height=.58, label='Limite básico do cenário')
    ax.barh(labels, q.extra_ratio, left=q.base_ratio, color=ORANGE, height=.58, label='Pior caso da auditoria amostral')
    for i, (_, r) in enumerate(q.iterrows()):
        ax.text(r.base_ratio + r.extra_ratio + 1, i, 'margem mínima ' + pt(r.minimum_with_audit), va='center', fontsize=9, color=GREY)
    ax.set(xlim=(0, 105), xlabel='Redução admissível / margem observada (%)', title='Limites condicionais, incluindo incerteza da auditoria de contexto')
    ax.axvline(100, color=GREY, linestyle='--', linewidth=1)
    ax.xaxis.set_major_formatter(FuncFormatter(lambda x, p: f'{x:.0f}%'))
    ax.legend(loc='lower right', fontsize=8); fig.tight_layout()
    save(fig, '04-limites-margens', 'Corte 15 minutos anterior; casos fora do conjunto estrito e todo o exterior admitidos integralmente no teto. O acréscimo presidencial usa limites simultâneos de 95% para falhas de identidade nos 21 estratos amostrais. Nas seis UFs com disputa de governador, os contextos restantes foram censitados. As barras não são efeitos estimados nem intervalos do efeito causal. Mantêm-se as hipóteses de participação adicional, sem supressão, mudança de escolha dos demais ou antecipação anterior ao corte.')

    n = read('temporal-population-state', 'national.csv')
    n = n[n.scope.eq('domestic')]
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.6), gridspec_kw={'width_ratios': [1.8, 1]})
    for ax, years, title in [(axes[0], [2022, 2026], 'Eleições gerais'), (axes[1], [2024], 'Eleição municipal')]:
        x = 0
        labels = []
        for year in years:
            for turn in [1, 2]:
                r = n[(n.year == year) & (n['round'] == turn)].iloc[0]
                rate = 100 * r.recorded_strict_post_deadline / r.attendance
                ax.scatter(x, rate, s=70, color=BLUE if turn == 1 else ORANGE, zorder=3)
                ax.text(x, rate * 1.15, pt(r.recorded_strict_post_deadline), ha='center', fontsize=9)
                labels.append(f'{year}\n{turn}º turno'); x += 1
        ax.set_xticks(range(len(labels)), labels)
        ax.set_xlim(-.5, len(labels)-.5)
        ax.set(yscale='log', ylim=(.008, 12), title=title, ylabel='Conclusões após o prazo / comparecimento (%)')
    fig.tight_layout()
    save(fig, '06-comparacoes-historicas', 'Enumeração dos registros disponíveis, após revisão de contexto e normalização municipal do prazo. Escala vertical logarítmica; rótulos mostram contagens absolutas. O segundo turno de 2024 inclui apenas os municípios em que ocorreu. As diferenças não isolam efeito da decisão de 2026. Lacunas de contagem e vínculos são apresentadas nas tabelas de cobertura e sensibilidade; não há intervalo amostral sobre estas contagens.')
    result = {'at': now(), 'status': 'final_figure_set_pending_visual_review', 'output_folder': str(out.relative_to(ROOT)),
              'captions': sorted(captions, key=lambda x: x['name']), 'inputs': inputs,
              'code_sha256': digest(ROOT / 'scripts/make_final_scientific_figures.py'),
              'outputs': [{'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size, 'sha256': digest(p)} for p in out.iterdir()]}
    atomic_json(out / 'manifest.json', result)
    atomic_json(ROOT / 'reports/scientific-final-figures-state.json', result)
    print(json.dumps({'folder': result['output_folder'], 'figures': len(captions)}))


if __name__ == '__main__':
    main()
