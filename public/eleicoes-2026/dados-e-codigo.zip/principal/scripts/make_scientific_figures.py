"""Conventional scientific figures from frozen derived tables; no fitted causal effects."""
import json,time
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from analysis_common import ROOT,digest,atomic_json,now

BLUE='#164B6A';ORANGE='#B75B29';GREY='#5F6871';LIGHT='#EDF2F5'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':13,'axes.labelsize':10,
 'axes.spines.top':False,'axes.spines.right':False,'axes.titlelocation':'left','axes.titlepad':14,
 'figure.facecolor':'white','axes.grid':True,'grid.alpha':.16,'grid.linewidth':.6,'legend.frameon':False,
 'savefig.facecolor':'white','svg.fonttype':'none'})

def pt(x,pos=None):return f'{x:,.0f}'.replace(',','.')
def main():
 tag=str(time.time_ns());out=ROOT/'analysis/figures/scientific-v1'/tag;out.mkdir(parents=True,exist_ok=False)
 pop=json.loads((ROOT/'reports/temporal-population-state.json').read_text());base=ROOT/pop['output_folder']
 margin=json.loads((ROOT/'reports/margin-scenario-state.json').read_text());mbase=ROOT/margin['output_folder']
 inputs=[];captions=[]
 def read(path):inputs.append({'path':str(path.relative_to(ROOT)),'sha256':digest(path)});return pd.read_csv(path)
 def save(fig,name,caption):
  for ext in ['png','svg','pdf']:fig.savefig(out/(name+'.'+ext),dpi=180,bbox_inches='tight')
  plt.close(fig);captions.append({'name':name,'caption':caption})
 h=read(base/'minute-histograms.csv');n=read(base/'national.csv')
 fig,axs=plt.subplots(1,2,figsize=(11.4,4.3),gridspec_kw={'width_ratios':[1.25,1]})
 for turn,color in [(1,BLUE),(2,ORANGE)]:
  g=h[(h.year==2026)&(h['round']==turn)].copy();g['bin5']=g.minutes_after_ordinary_deadline//5*5
  s=g.groupby('bin5').completions.sum();attendance=float(n[(n.year==2026)&(n['round']==turn)&(n.scope=='domestic')].attendance.iloc[0])
  axs[0].plot(17+s.index/60,s/attendance*100,color=color,lw=1.8,label=f'{turn}º turno')
  z=g.groupby('minutes_after_ordinary_deadline').completions.sum().sort_index()
  tail=z.iloc[::-1].cumsum().iloc[::-1];mask=(tail.index>=0)&(tail.index<=150)
  axs[1].step(tail.index[mask],tail[mask],where='post',color=color,lw=1.8,label=f'{turn}º turno')
 axs[0].set(xlim=(8,21),xlabel='Horário de Brasília (intervalos de 5 minutos)',ylabel='% do comparecimento nacional',title='Distribuição das conclusões de votação')
 axs[1].set(xlim=(0,150),yscale='log',xlabel='Minutos após 17h (início do intervalo)',ylabel='Conclusões a partir do minuto indicado',title='Cauda após o prazo ordinário')
 axs[0].axvline(17,color=GREY,ls='--',lw=1);axs[1].axvline(120,color=GREY,ls='--',lw=1)
 axs[0].legend();axs[1].legend();fig.tight_layout()
 save(fig,'01-perfil-temporal-2026','Brasil doméstico,2026. Horários municipais convertidos para Brasília. Contagens de eventos de conclusão; não votos por candidato. Na cauda, o início do minuto é inclusivo. A escala vertical da direita é logarítmica. Diferença entre turnos não identifica efeito causal; lacunas constam na tabela de cobertura.')
 u=read(base/'uf.csv');u=u[(u.year==2026)&(u['round']==2)&u.uf.ne('ZZ')].copy();u['rate']=u.recorded_strict_post_deadline/u.attendance*100000;u=u.sort_values('rate')
 fig,ax=plt.subplots(figsize=(8,7.4));ax.hlines(u.uf,0,u.rate,color=LIGHT,lw=3);ax.scatter(u.rate,u.uf,color=BLUE,s=28,zorder=3)
 for i,(_,r) in enumerate(u.iterrows()):ax.text(r.rate+1,i,pt(r.recorded_strict_post_deadline),va='center',fontsize=8,color=GREY)
 ax.set(xlabel='Conclusões após 17h por 100 mil comparecimentos',ylabel='UF',title='Frequência relativa e contagens absolutas • 2º turno 2026',xlim=(0,u.rate.max()*1.22));ax.xaxis.set_major_formatter(FuncFormatter(pt));fig.tight_layout()
 save(fig,'02-heterogeneidade-uf','Taxa por100mil comparecimentos presidenciais; números ao lado dos pontos são contagens absolutas. Corte estrito após17hBrasília. Não é uma taxa de votos causados pela extensão. Denominadores e falhas de cobertura são publicados porUF.')
 c=read(base/'cutoff-sensitivity.csv');c=c[(c.year==2026)&(c['round']==2)&(c.population=='all_recorded')&c.cutoff_seconds_after_ordinary.between(-900,900)]
 fig,ax=plt.subplots(figsize=(8.5,4.4));ax.plot(c.cutoff_seconds_after_ordinary/60,c.recorded_late,marker='o',ms=4,color=BLUE,lw=1.5)
 ax.set(yscale='log',xlabel='Deslocamento do corte em minutos em relação a 17h',ylabel='Conclusões posteriores ao corte',title='Sensibilidade ao horário de corte • 2º turno 2026');ax.axvline(0,color=GREY,ls='--',lw=1)
 for shift in [-900,0,600]:
  r=c[c.cutoff_seconds_after_ordinary==shift].iloc[0];ax.annotate(pt(r.recorded_late),(shift/60,r.recorded_late),xytext=(6,8),textcoords='offset points',fontsize=9)
 fig.tight_layout();save(fig,'03-sensibilidade-corte','Contagens observadas na escala dos relógios registrados. A variação do corte é análise de sensibilidade, não uma estimativa ou certificação do erro dos relógios. Escala vertical logarítmica; não são intervalos de confiança.')
 b=read(mbase/'conditional-margin-bounds.csv');q=b[(b.scenario=='strict_other_sections_all')&(b.cutoff_shift_earlier_seconds==900)].copy();q['ratio']=100*q.maximum_adverse_margin_change/q.observed_margin;q=q.sort_values('ratio')
 labels=q.race.str.replace('BR-PRESIDENTE','Presidência',regex=False).str.replace('-GOVERNADOR',' • governo',regex=False)
 fig,ax=plt.subplots(figsize=(9.5,4.6));ax.barh(labels,q.ratio,color=BLUE,height=.58)
 for i,(_,r) in enumerate(q.iterrows()):ax.text(r.ratio+.6,i,f"{r.ratio:.1f}% | margem mínima {pt(r.minimum_counterfactual_margin)}".replace('.',',',1),va='center',fontsize=9,color=GREY)
 ax.set(xlim=(0,max(q.ratio)*1.75),xlabel='Máxima redução permitida da margem / margem observada (%)',title='Limite sob um cenário conservador de participação adicional')
 ax.xaxis.set_major_formatter(FuncFormatter(lambda x,p:f'{x:.0f}%'));fig.tight_layout()
 save(fig,'04-limites-margens','Cenário condicional: corte antecipado em15min; todas as cédulas de seções fora do conjunto estrito e todo o exterior podem ser removidos; contagens finais restringem extremos por seção. Exclui antecipação antes do corte, supressão e mudanças de escolha de outros eleitores. Barras são limites matemáticos, não efeitos estimados nem intervalos de confiança.')
 bench=json.loads((ROOT/'reports/time-benchmark-comparison-reviewed.json').read_text());bb=read(ROOT/bench['output_folder']/'national-operational-cohorts.csv')
 bb=bb[(bb.population=='all_recorded')&~bb.cohort_cutoff_inclusive&bb.vote_cutoff_inclusive]
 fields=['reviewed_last_completed_second','closed_elapsed_seconds','day_closing_started_last','emitted_elapsed_seconds'];names=['Última conclusão\nde votação','Encerramento\nno BWeb','Início do encerramento\nno log','Emissão\ndo BU']
 fig,axs=plt.subplots(1,2,figsize=(11.2,4.4))
 for ax,delta,title in zip(axs,[600,7200],['Depois de 17h10','Depois de 19h']):
  x=bb[(bb.cohort_delta_seconds==delta)&bb.cohort_timestamp.isin(fields)].set_index('cohort_timestamp').loc[fields]
  ax.bar(range(4),x.cohort_sections,color=[ORANGE,BLUE,BLUE,BLUE]);ax.set_xticks(range(4),names,fontsize=8);ax.set_title(title);ax.set_ylabel('Número de seções');ax.yaxis.set_major_formatter(FuncFormatter(pt))
  for j,v in enumerate(x.cohort_sections):ax.text(j,v+max(x.cohort_sections)*.015,pt(v),ha='center',fontsize=9)
  ax.set_ylim(0,max(x.cohort_sections)*1.15)
 fig.tight_layout();save(fig,'05-eventos-distintos','Brasil doméstico,2º turno 2026. Os quatro horários têm significados distintos. Horários municipais normalizados. As pequenas lacunas de logs e a contaminação de contexto de uma seção constam no arquivo detalhado; não usar nenhum desses indicadores como medida automática de tratamento.')
 result={'at':now(),'status':'figures_from_reviewed_2026_results_history_figures_pending','output_folder':str(out.relative_to(ROOT)),
         'captions':captions,'inputs':inputs,'code_sha256':digest(ROOT/'scripts/make_scientific_figures.py'),
         'outputs':[{'path':str(p.relative_to(ROOT)),'sha256':digest(p),'bytes':p.stat().st_size} for p in out.iterdir()]}
 atomic_json(out/'manifest.json',result);atomic_json(ROOT/'reports/scientific-figures-state.json',result)
 print(json.dumps({'folder':result['output_folder'],'figures':len(captions)}))
if __name__=='__main__':main()
