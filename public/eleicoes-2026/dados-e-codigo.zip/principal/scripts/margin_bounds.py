"""Sharp finite-table bounds for removal of an unknown subset of observed votes.

These are conditional arithmetic bounds, not estimates of treatment effects.
Let a,b,o be final votes for the two compared candidates and all other outcomes.
For up to t causally additional voters, choose nonnegative integer x_a,x_b,x_o
with sum <= t and category caps (a,b,o). Counterfactual margin minus observed
margin is x_b-x_a. Its extrema are -min(t,a) and min(t,b). They are attainable
by choosing only one candidate's votes, including a smaller subset than t.

If exactly t observed votes are removed, unavoidable other-category constraints
give the formulas below. Summing independent section extrema is sharp given
only these section caps. Extra cross-section constraints could tighten bounds.
Neither function assumes proportional allocation or identifies anyone's vote.
"""


def removal_margin_bounds(a,b,other,cap,exact=False):
    values=[a,b,other,cap]
    if any(int(x)!=x or x<0 for x in values):
        raise ValueError('Nonnegative integer counts required')
    a,b,other,cap=map(int,values)
    if cap>a+b+other:raise ValueError('Removal cap exceeds observed attendance')
    if exact:
        low=-min(a,cap)+max(0,cap-a-other)
        high=min(b,cap)-max(0,cap-b-other)
    else:
        low=-min(a,cap);high=min(b,cap)
    return {'observed_margin':a-b,'minimum_margin_change':low,'maximum_margin_change':high,
            'minimum_counterfactual_margin':a-b+low,'maximum_counterfactual_margin':a-b+high}
