"""Create and verify the compact portable scientific delivery, without raw ZIPs."""
import hashlib
import json
import zipfile
from analysis_common import ROOT, atomic_json, digest, now


def main():
    selection = json.loads((ROOT / 'reports/final-delivery-selection.json').read_text())
    out = ROOT / selection['output_folder']; target = out / 'estudo-tse-2026-resultados-e-codigo-v2.zip'
    if target.exists():
        raise ValueError('Package already exists; preserve this version')
    expected = {r['path']: r for r in selection['files']}
    readme = ('ESTUDO TSE — ENTREGA CIENTÍFICA PRIVADA\n\nAbra ' + selection['output_folder'] + '/index.html após extrair em uma pasta vazia.\n'
        'O pacote preserva os caminhos relativos das tabelas, código e documentação. Não contém credenciais nem ZIPs brutos.\n'
        'Os derivados por seção e os registros completos de auditoria estão nos bundles privados do estudo, conforme o guia de reprodução.\n').encode()
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=1) as archive:
        archive.writestr('LEIA-ME.txt', readme)
        for name, r in expected.items():
            p = ROOT / name
            if digest(p) != r['sha256'] or p.stat().st_size != r['bytes']:
                raise ValueError('Delivery input changed: ' + name)
            archive.write(p, arcname=name)
    with zipfile.ZipFile(target) as archive:
        assert set(archive.namelist()) == set(expected) | {'LEIA-ME.txt'}
        assert archive.read('LEIA-ME.txt') == readme
        for name, r in expected.items():
            h = hashlib.sha256(); size = 0
            with archive.open(name) as stream:
                while block := stream.read(8 * 1024**2):
                    h.update(block); size += len(block)
            assert h.hexdigest() == r['sha256'] and size == r['bytes']
    result = {'at': now(), 'status': 'portable_delivery_all_members_sha256_verified',
        'path': str(target.relative_to(ROOT)), 'bytes': target.stat().st_size, 'sha256': digest(target),
        'members': len(expected) + 1, 'selection': 'reports/final-delivery-selection.json',
        'selection_sha256': digest(ROOT / 'reports/final-delivery-selection.json'), 'code_sha256': digest(__file__)}
    atomic_json(ROOT / 'reports/final-portable-package.json', result)
    print(json.dumps(result))


if __name__ == '__main__':
    main()
