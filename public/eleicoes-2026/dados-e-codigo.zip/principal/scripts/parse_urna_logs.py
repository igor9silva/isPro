"""Parse public operational logs; never retain voter IDs or candidate/time links.

The observed time is the machine's unnormalized OS clock. We extract the exact
completed-voter event, not individual office confirmations. A second-turn JEZ
can contain first-turn records. Dates are explicit; duplicate full log lines
across nested archives are counted separately and deduplicated for measures.
Cryptographic MAC fields are used only as part of event identity, not verified.
"""
from collections import Counter, defaultdict
import hashlib
import io
import json
from pathlib import PurePosixPath
import re
import zipfile

FILENAME = re.compile(r"o(?P<pleito>\d{5})(?P<uf>[a-z]{2})(?P<municipality>\d{5})(?P<zone>\d{4})(?P<section>\d{4})-log\.jez$", re.I)
HEADER = re.compile(rb"^(\d{2}/\d{2}/\d{4}) (\d{2}):(\d{2}):(\d{2})\t([^\t]+)\t(\d+)\t([^\t]+)\t(.*)\t([a-fA-F0-9]{16})\s*$")
COMPLETED = "O voto do eleitor foi computado"
EVENTS = {
    "Todas as pessoas presentes já votaram? SIM": "all_present_voted_confirmed",
    "Procedimento de encerramento confirmado": "closing_confirmed",
    "Inicio do Encerramento": "closing_started",
    "Início do Encerramento": "closing_started",
    "Eleitor foi suspenso e não confirmou nenhum voto": "suspended_without_vote",
    "Início das operações do logd": "log_boot",
}
EVENT_FIELDS = ["all_present_voted_confirmed", "closing_confirmed", "closing_started", "suspended_without_vote", "log_boot"]


def texts_in_package(payload, label, stats, depth=0):
    if depth > 8 or len(payload) > 256 * 1024**2:
        raise ValueError("Nested log exceeds bounded extraction limits")
    if not zipfile.is_zipfile(io.BytesIO(payload)):
        raise ValueError(f"JEZ is not a ZIP: {label}")
    with zipfile.ZipFile(io.BytesIO(payload)) as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            if info.file_size > 256 * 1024**2:
                raise ValueError("Oversized nested log member")
            name = info.filename.lower()
            if name.endswith((".jez", ".zip")):
                stats["nested_archives"] += 1
                yield from texts_in_package(z.read(info), label + "/" + info.filename, stats, depth + 1)
            elif name.endswith(".dat") or name.endswith(".log"):
                data = z.read(info)  # complete member read verifies ZIP CRC
                stats["text_files"] += 1
                stats["uncompressed_text_bytes"] += len(data)
                if stats["uncompressed_text_bytes"] > 512 * 1024**2:
                    raise ValueError("Section log total exceeds bounded extraction limit")
                yield label + "/" + info.filename, data
            else:
                stats["other_members"] += 1


def parse_package(payload, member_name, target_dates):
    """Return per-date section summaries and a privacy-preserving package audit."""
    m = FILENAME.fullmatch(PurePosixPath(member_name).name)
    if not m:
        raise ValueError("Unrecognized official section filename")
    identity = m.groupdict()
    identity["uf"] = identity["uf"].upper()
    identity.update({k: int(identity[k]) for k in ["pleito", "municipality", "zone", "section"]})
    stats = Counter()
    rows, seen = {}, set()
    versions, contexts = set(), set()

    def get_row(date):
        if date not in rows:
            rows[date] = {**identity, "event_date": date, "computed_seconds": [], "raw_computed_count": 0,
                          "duplicate_computed_count": 0, "clock_backwards_count": 0,
                          "largest_backward_seconds": 0, "machine_ids": set(), "apps_with_computed": Counter(),
                          "line_count": 0, "duplicate_line_count": 0, "alert_error_lines": 0,
                          "clock_message_count": 0, "contingency_message_count": 0, "suspension_message_count": 0,
                          "manual_authorization_count": 0, "biometric_authorization_count": 0,
                          "first_record_second": None, "last_record_second": None,
                          **{k + "_seconds": [] for k in EVENT_FIELDS}}
        return rows[date]

    for label, data in texts_in_package(payload, member_name, stats):
        prior = {}
        for line_number, line in enumerate(data.splitlines(), 1):
            stats["total_lines"] += 1
            match = HEADER.fullmatch(line)
            if not match:
                stats["unparsed_lines"] += 1
                # Do not persist arbitrary messages containing personal identifiers.
                if line[:10].decode("ascii", errors="replace") in target_dates:
                    stats["unparsed_target_date_lines"] += 1
                continue
            date_b, hb, mb, sb, severity, machine_b, app_b, message_b, mac = match.groups()
            date = date_b.decode("ascii")
            h, minute, second = int(hb), int(mb), int(sb)
            if h > 23 or minute > 59 or second > 59:
                stats["invalid_clock_lines"] += 1
                continue
            message = message_b.decode("latin1").strip()
            if message == COMPLETED:
                stats["raw_computed_date:" + date] += 1
            if message.startswith("Versão da aplicação:"):
                versions.add(message.split(":", 1)[1].strip())
            if message.startswith(("Fase da UE:", "Turno da UE:", "Modo de carga da UE")):
                contexts.add(message)
            if date not in target_dates:
                continue
            row = get_row(date)
            sec = h * 3600 + minute * 60 + second
            machine, app = int(machine_b), app_b.decode("latin1")
            row["line_count"] += 1
            row["machine_ids"].add(machine)
            row["first_record_second"] = sec if row["first_record_second"] is None else min(sec, row["first_record_second"])
            row["last_record_second"] = sec if row["last_record_second"] is None else max(sec, row["last_record_second"])
            if message == COMPLETED:
                row["raw_computed_count"] += 1
            # Full raw record (including MAC) identity prevents equal-second collisions.
            event_key = hashlib.blake2b(line, digest_size=16).digest()
            if event_key in seen:
                row["duplicate_line_count"] += 1
                if message == COMPLETED:
                    row["duplicate_computed_count"] += 1
                continue
            seen.add(event_key)
            if (date, machine) in prior and sec < prior[date, machine]:
                row["clock_backwards_count"] += 1
                row["largest_backward_seconds"] = max(row["largest_backward_seconds"], prior[date, machine] - sec)
            prior[date, machine] = sec
            if message == COMPLETED:
                row["computed_seconds"].append(sec)
                row["apps_with_computed"][app] += 1
            if message in EVENTS:
                row[EVENTS[message] + "_seconds"].append(sec)
            lower = message.lower()
            row["clock_message_count"] += int(any(x in lower for x in ["relógio", "relogio", "ajuste de hor", "ajuste da data", "fuso hor"]))
            row["contingency_message_count"] += int(any(x in lower for x in ["contingência", "contingencia", "recuperação de dados"]))
            row["suspension_message_count"] += int("suspens" in lower or "suspenso" in lower)
            row["manual_authorization_count"] += int(message == "Solicitação de dado pessoal do eleitor para habilitação manual")
            row["biometric_authorization_count"] += int(message == "Tipo de habilitação do eleitor [biométrica]")
            row["alert_error_lines"] += int(severity.upper() in [b"ERRO", b"ALERTA", b"ERROR", b"WARN"])
    for date in target_dates:
        # Keep an explicit zero-record row for absence on the requested day.
        get_row(date)
    result = []
    for date, row in sorted(rows.items()):
        row.update(computed_count=len(row["computed_seconds"]), machine_ids=sorted(row["machine_ids"]),
                   apps_with_computed=json.dumps(dict(row["apps_with_computed"]), sort_keys=True),
                   versions=json.dumps(sorted(versions), ensure_ascii=False),
                   contexts=json.dumps(sorted(contexts), ensure_ascii=False),
                   package_sha256=hashlib.sha256(payload).hexdigest(), source_member=member_name,
                   text_file_count=stats["text_files"], nested_archive_count=stats["nested_archives"],
                   unparsed_target_date_lines=stats["unparsed_target_date_lines"],
                   invalid_clock_lines=stats["invalid_clock_lines"])
        result.append(row)
    return result, dict(stats)
