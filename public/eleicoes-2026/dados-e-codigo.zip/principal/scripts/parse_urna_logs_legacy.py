"""Filename adapter for 2022 .logjez; data fields use the separately tested parser."""
from pathlib import PurePosixPath
import hashlib
import io
import re
import zipfile
import py7zr
from py7zr.io import BytesIOFactory
from parse_urna_logs import parse_package as modern_parse_package

LEGACY = re.compile(r"o(?P<pleito>\d{5})-(?P<municipality>\d{5})(?P<zone>\d{4})(?P<section>\d{4})\.logjez$", re.I)


def to_parser_container(payload, depth=0, counters=None):
    """Decode official 2022 7z containers in RAM, checking lengths and CRCs.

    The ephemeral ZIP_STORED representation is only an adapter to the common
    record parser. It is never treated as an original file or stored on disk.
    Original package hashes and original outer filenames remain in the output.
    """
    counters = counters if counters is not None else {}
    if depth > 8:
        raise ValueError("Legacy nested archive depth exceeded")
    if payload.startswith(b"7z\xbc\xaf\x27\x1c"):
        counters["seven_zip_containers_decoded"] = counters.get("seven_zip_containers_decoded", 0) + 1
        with py7zr.SevenZipFile(io.BytesIO(payload)) as z:
            members = [m for m in z.list() if not m.is_directory]
            if any(m.uncompressed > 256 * 1024**2 for m in members) or sum(m.uncompressed for m in members) > 512 * 1024**2:
                raise ValueError("Legacy package exceeds bounded extraction limit")
            factory = BytesIOFactory(limit=256 * 1024**2)
            z.extractall(factory=factory)
            output = io.BytesIO()
            with zipfile.ZipFile(output, "w", zipfile.ZIP_STORED) as converted:
                for member in members:
                    obj = factory.get(member.filename)
                    if obj.size() != member.uncompressed:
                        raise ValueError("Legacy decoded member size differs from archive header")
                    obj.seek(0)
                    data = obj.read()
                    name = member.filename
                    if data.startswith(b"7z\xbc\xaf\x27\x1c"):
                        data = to_parser_container(data, depth + 1, counters)
                        if not name.lower().endswith((".jez", ".zip")):
                            name += ".zip"
                    converted.writestr(name, data)
            return output.getvalue()
    if zipfile.is_zipfile(io.BytesIO(payload)):
        return payload
    raise ValueError("Legacy log is neither a 7z nor a ZIP container")


def parse_package(payload, member_name, target_dates, archive_uf):
    match = LEGACY.fullmatch(PurePosixPath(member_name).name)
    if match:
        d = match.groupdict()
        alias = f"o{d['pleito']}{archive_uf.lower()}{d['municipality']}{d['zone']}{d['section']}-log.jez"
        counters = {}
        converted = to_parser_container(payload, counters=counters)
        rows, stats = modern_parse_package(converted, alias, target_dates)
        for row in rows:
            row["source_member"] = member_name
            row["package_sha256"] = hashlib.sha256(payload).hexdigest()
        stats["legacy_filename_adapted"] = 1
        stats.update(counters)
        return rows, stats
    return modern_parse_package(payload, member_name, target_dates)
