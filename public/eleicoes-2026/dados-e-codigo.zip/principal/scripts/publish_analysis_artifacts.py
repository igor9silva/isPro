"""Preserve an explicit, hashed analysis manifest in the private research bucket.

All paths must be reviewed public-research artifacts under analysis, reports or
scripts. No directory sync, deletion, original-key overwrite or credential reads.
Small local derivatives are streamed; remote verification uses bounded buffers.
"""
import argparse
import base64
import hashlib
import json
from pathlib import Path

from botocore.exceptions import ClientError
from analysis_common import ROOT, BUCKET, PREFIX, atomic_json, now, s3_client

LIMIT = 1_000_000_000_000


def hashes(stream):
    sha, md5, size = hashlib.sha256(), hashlib.md5(), 0
    while block := stream.read(8 * 1024**2):
        sha.update(block)
        md5.update(block)
        size += len(block)
    return sha.hexdigest(), base64.b64encode(md5.digest()).decode(), size


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('manifest')
    args = parser.parse_args()
    manifest = json.loads(Path(args.manifest).read_text())
    paths = []
    for record in manifest['records']:
        path = (ROOT / record['local']).resolve()
        relative = path.relative_to(ROOT)
        if relative.parts[0] not in {'analysis', 'reports', 'scripts'} or 'private' in relative.parts:
            raise ValueError('Path is outside the explicit research artifact roots')
        if path.stat().st_size > 512 * 1024**2:
            raise ValueError('Single analysis artifact exceeds the reviewed 512MiB cap')
        with path.open('rb') as stream:
            sha, md5, size = hashes(stream)
        if sha != record['sha256'] or size != record['bytes']:
            raise ValueError(f'Artifact changed after manifest: {relative}')
        paths.append((path, record, md5))
    s3 = s3_client()
    bucket_bytes = sum(obj['Size'] for page in s3.get_paginator('list_objects_v2').paginate(Bucket=BUCKET)
                       for obj in page.get('Contents', []))
    additional = sum(r['bytes'] for _, r, _ in paths)
    if bucket_bytes + additional > LIMIT:
        raise ValueError('Private research storage limit would be exceeded')
    report_path = ROOT / manifest['publication_report']
    if report_path.exists():
        raise ValueError('Use a new publication report path; prior reports are preserved')
    report = {'started_at': now(), 'bucket': BUCKET, 'prefix': PREFIX, 'bucket_bytes_before': bucket_bytes,
              'additional_bytes_upper_bound': additional, 'storage_limit_bytes': LIMIT,
              'manifest': str(Path(args.manifest).resolve().relative_to(ROOT)), 'records': [], 'status': 'publishing'}
    for path, record, md5 in paths:
        key = f"{PREFIX}/analysis/artifacts/{record['sha256'][:24]}/{path.name}"
        created = True
        try:
            with path.open('rb') as stream:
                s3.put_object(Bucket=BUCKET, Key=key, Body=stream, ContentLength=record['bytes'],
                              IfNoneMatch='*', ContentMD5=md5, Metadata={'sha256': record['sha256']})
        except ClientError as exc:
            if exc.response['Error']['Code'] not in {'PreconditionFailed', '412'}:
                raise
            created = False
        response = s3.get_object(Bucket=BUCKET, Key=key)
        try:
            sha, _, size = hashes(response['Body'])
        finally:
            response['Body'].close()
        if sha != record['sha256'] or size != record['bytes']:
            raise ValueError(f'Private readback mismatch: {record["local"]}')
        report['records'].append({**record, 'key': key, 'new_object': created,
                                  'verification': 'full_s3_readback_sha256', 'official_hash_comparison': False})
        report['updated_at'] = now()
        atomic_json(report_path, report)
    report.update(status='complete_verified', finished_at=now(), published_records=len(report['records']))
    atomic_json(report_path, report)
    print(json.dumps({k: report[k] for k in ['status', 'published_records', 'additional_bytes_upper_bound', 'bucket_bytes_before']}))


if __name__ == '__main__':
    main()
