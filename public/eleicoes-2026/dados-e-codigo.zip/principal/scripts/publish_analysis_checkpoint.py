"""Publish reviewed analysis code and small audit records to the private bucket.

Only explicit public-research paths are allowed; credentials and arbitrary
metadata directories are never synced. Content-addressed keys preserve versions.
"""
import base64
import hashlib
import json
from pathlib import Path

from botocore.exceptions import ClientError
from analysis_common import ROOT, BUCKET, PREFIX, atomic_json, now, s3_client

SCRIPTS = ["analysis_common.py", "s3_archive.py", "extract_bweb.py", "extract_bweb_2014.py", "extract_native_logs.py",
           "extract_native_logs_history.py", "parse_urna_logs.py", "parse_urna_logs_legacy.py", "validate_log_pilot.py",
           "watch_analysis_validation.py", "build_section_tables.py", "test_analysis_extraction.py",
           "test_analysis_extraction_legacy.py", "archive_analysis_sources.py", "publish_analysis_checkpoint.py",
           "requirements-analysis.txt"]
RECORDS = ["analysis/analysis-plan.json", "analysis/plan-amendments.jsonl", "analysis/source-audit/source-ledger.json",
           "reports/log-pilot-validation-2026-2t-AC.json", "reports/log-pilot-timing-validation-2026-2t-AC.json",
           "reports/log-pilot-validation-2024-1t-AC.json", "reports/log-pilot-validation-2022-2t-AC.json",
           "reports/log-pilot-review-2022-AC.json", "reports/analysis-source-retrieval-latest.json"]


def main():
    s3 = s3_client()
    paths = [ROOT / "scripts" / name for name in SCRIPTS] + [ROOT / r for r in RECORDS]
    paths += list((ROOT / "analysis/source-audit/dictionaries").glob("*"))
    paths += [p for p in (ROOT / "analysis/source-audit/http-snapshots/20261030T231658").glob("stf-peca-*.pdf") if p.stat().st_size]
    paths += [ROOT / "analysis/source-audit/http-snapshots/20261030T231658/judicial-pdf-timestamp-inspection.json"]
    total = 0
    for page in s3.get_paginator("list_objects_v2").paginate(Bucket=BUCKET, Prefix=PREFIX + "/"):
        total += sum(o["Size"] for o in page.get("Contents", []))
    additional = sum(p.stat().st_size for p in paths)
    if total + additional > 1_000_000_000_000:
        raise ValueError("Private research storage ceiling would be exceeded")
    results = []
    for path in paths:
        if path.stat().st_size > 20 * 1024**2:
            raise ValueError("Checkpoint publisher accepts only small reviewed records")
        body = path.read_bytes()
        sha = hashlib.sha256(body).hexdigest()
        key = PREFIX + "/analysis/checkpoints/" + sha[:20] + "/" + path.name
        try:
            s3.put_object(Bucket=BUCKET, Key=key, Body=body, IfNoneMatch="*",
                          ContentMD5=base64.b64encode(hashlib.md5(body).digest()).decode(), Metadata={"sha256": sha})
        except ClientError as e:
            if e.response["Error"]["Code"] not in ["PreconditionFailed", "412"]:
                raise
        response = s3.get_object(Bucket=BUCKET, Key=key)
        try:
            actual = hashlib.sha256(response["Body"].read()).hexdigest()
        finally:
            response["Body"].close()
        if actual != sha:
            raise ValueError("Published checkpoint readback differs")
        results.append({"local": str(path.relative_to(ROOT)), "key": key, "bytes": len(body), "sha256": sha,
                        "verification": "full_s3_readback", "official_hash_comparison": False})
    report = {"at": now(), "bucket": BUCKET, "prefix": PREFIX, "prefix_bytes_before": total,
              "new_bytes_upper_bound": additional, "storage_limit_bytes": 1_000_000_000_000, "records": results}
    atomic_json(ROOT / "reports/analysis-checkpoint-publication.json", report)
    print(json.dumps({"published_records": len(results), "published_bytes": additional, "prefix_bytes_before": total}))


if __name__ == "__main__":
    main()
