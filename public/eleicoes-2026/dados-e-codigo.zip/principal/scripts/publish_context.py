#!/usr/bin/env python3
"""Publish only public election context and acquisition code; never sync metadata/."""
import base64
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

ROOT = Path(__file__).resolve().parents[1]
PREFIX = "tse/2026-10-29/"
BUCKET = "tse-research"


def main():
    s3 = boto3.Session(profile_name="tse-research", region_name="auto").client(
        "s3", endpoint_url="https://t3.storage.dev", config=Config(
            connect_timeout=20, read_timeout=90, retries={"max_attempts": 5},
            request_checksum_calculation="when_required", response_checksum_validation="when_required"))
    records = []

    def publish(path, body, source=None):
        key = PREFIX + path
        digest = hashlib.sha256(body).hexdigest()
        try:
            s3.put_object(Bucket=BUCKET, Key=key, Body=body, IfNoneMatch="*",
                ContentMD5=base64.b64encode(hashlib.md5(body).digest()).decode(),
                Metadata={"sha256": digest})
        except ClientError as error:
            if error.response["Error"]["Code"] not in ("PreconditionFailed", "412"):
                raise
        response = s3.get_object(Bucket=BUCKET, Key=key)
        try:
            check = hashlib.sha256(response["Body"].read()).hexdigest()
        finally:
            response["Body"].close()
        if check != digest:
            raise ValueError("Existing remote document differs; refusing to overwrite " + path)
        record = {"path": path, "bytes": len(body), "sha256": digest,
                  "sha512": hashlib.sha512(body).hexdigest(), "verification": "full_s3_readback"}
        if source:
            record["source"] = source
        records.append(record)

    evidence = json.loads((ROOT / "reports/official-evidence.json").read_text())
    unavailable = []
    for item in evidence:
        if item.get("status") != "downloaded":
            unavailable.append({"url": item["url"], "name": item.get("name"), "status": "not_downloaded"})
            continue
        path = Path(item["path"])
        if path.is_absolute() or ".." in path.parts or path.parts[0] != "documentation":
            raise ValueError("Unexpected documentation path")
        publish(path.as_posix(), (ROOT / path).read_bytes(), item["url"])

    for filename in ("collect.py", "download.py", "evidence.py", "cloud_transfer.py",
                     "test_cloud_transfer.py", "requirements-cloud.txt", "publish_context.py", "supervise_transfer.py"):
        body = (ROOT / "scripts" / filename).read_bytes()
        digest = hashlib.sha256(body).hexdigest()[:16]
        publish("acquisition-code/" + digest + "/" + filename, body)

    selections = [json.loads(path.read_text()) for path in
                  (ROOT / "metadata/cloud-selection.json", ROOT / "metadata/cloud-selection-2024.json") if path.exists()]
    planned = sum(r.get("bytes_remote") or 0 for selection in selections for r in selection["resources"])
    record = {"created_at": datetime.now(timezone.utc).isoformat(), "artifacts": records,
              "context_not_downloaded": unavailable,
              "storage_limit_bytes": 1_000_000_000_000,
              "planned_bytes_known": planned,
              "integrity_notes": [
                  "Raw files are preserved byte-for-byte with source URLs and retrieval metadata.",
                  "Official checksum matching is stated individually in each provenance receipt.",
                  "Computed hashes without an official comparison are not labelled official checksum matches.",
                  "Tigris rejected a deliberately incorrect Content-MD5 on a disposable multipart part with BadDigest.",
                  "Ten tests passed, including resume, changed source, integrity, storage ceiling, missing official checksum and connection rotation with validator checks.",
                  "The 1 TB ceiling is a maximum, not a storage target."]}
    destination = ROOT / "metadata/cloud-context.json"
    destination.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
    body = destination.read_bytes()
    s3.put_object(Bucket=BUCKET, Key=PREFIX + "catalog/context-and-acquisition.json", Body=body,
                  ContentType="application/json", ContentMD5=base64.b64encode(hashlib.md5(body).digest()).decode())
    print(json.dumps({"published": len(records), "context_not_downloaded": len(unavailable),
                      "bytes": sum(r["bytes"] for r in records)}, indent=2))


if __name__ == "__main__":
    main()
