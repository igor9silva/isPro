"""Reproduce the complete published UF table without changing primary municipal clocks."""
import json,time
from pathlib import Path
import pandas as pd
from analysis_common import ROOT,digest,atomic_json,now

def main():
 out=ROOT/'analysis/source-audit/benchmark-reconciliation-v1'/str(time.time_ns());out.mkdir(parents=True,exist_ok=False)
 a=json.loads((ROOT/'reports/time-benchmark-comparison-reviewed.json').read_text())
 z=json.loads((ROOT/'reports/timezone-benchmark-audit.json').read_text())
 p=ROOT/'analysis/source-audit/official-benchmarks/all-post17.csv';o=pd.read_csv(p).set_index('uf')
 assert int(o.total_completed_after_17.sum())==34393 and int(o.sections.sum())==497333
 assert (o.iloc[:,1:4].sum(axis=1)==o.total_completed_after_17).all()
 g=pd.read_csv(ROOT/a['output_folder']/'uf-endpoint-windows.csv');g=g[g.inclusive_lower_endpoint].set_index('uf')
 t=pd.read_csv(ROOT/z['output_folder']/'uf-timezone-totals.csv').set_index(['uf','mapping'])
 pairs={'total_completed_after_17':'after17','completed_17_18':'17_18','completed_18_19':'18_19','completed_after_19':'after19'}
 rows=[]
 for uf in o.index:
  for official_key,short in pairs.items():
   primary=int(g.loc[uf,'recorded_after_17' if short=='after17' else 'recorded_after_19' if short=='after19' else 'recorded_'+short])
   diagnostic=int(t.loc[(uf,'uniform_uf_diagnostic'),short]) if uf in ['AM','PE'] else primary
   rows.append({'uf':uf,'measure':official_key,'official':int(o.loc[uf,official_key]),'primary_municipal_clock_inclusive':primary,
                'uniform_uf_diagnostic':diagnostic,'diagnostic_minus_official':diagnostic-int(o.loc[uf,official_key]),'diagnostic_minus_primary':diagnostic-primary})
 r=pd.DataFrame(rows);r.to_csv(out/'uf-vote-reconciliation.csv',index=False)
 sources=[{'path':str(p.relative_to(ROOT)),'sha256':digest(p)},*a['input_manifests'],*z['input_manifests']]
 result={'at':now(),'status':'108_of_108_published_uf_vote_cells_reproduced_under_uniform_uf_diagnostic' if r.diagnostic_minus_official.eq(0).all() else 'residual_differences',
  'output_folder':str(out.relative_to(ROOT)),'cells':len(r),'matched_cells':int(r.diagnostic_minus_official.eq(0).sum()),
  'primary_national_inclusive':int(r.loc[r.measure=='total_completed_after_17','primary_municipal_clock_inclusive'].sum()),
  'diagnostic_national_inclusive':int(r.loc[r.measure=='total_completed_after_17','uniform_uf_diagnostic'].sum()),
  'am_change':int(r.loc[(r.uf=='AM')&(r.measure=='total_completed_after_17'),'diagnostic_minus_primary'].iloc[0]),
  'pe_change':int(r.loc[(r.uf=='PE')&(r.measure=='total_completed_after_17'),'diagnostic_minus_primary'].iloc[0]),
  'public_source_url':'https://www.tse.jus.br/comunicacao/noticias/arquivos/total-de-votos-apos-17h',
  'transcription_provenance':'Official PDF text read through web tool2026-10-31; original HTTP body remains403. All27rows transcribed and sums verified.',
  'inference':'Exact reproduction is consistent with uniform-UF handling of AM/PE and inclusive17h boundaries, but it does not prove the TSE software or section-level selection method. Municipal legal schedules and opening times support retaining the primary conversion.',
  'still_unresolved':'Section cohort definition at17h/17h10/19h; no section-level TSE benchmark or implementation receipt. These vote-cell matches are not evidence of individual votes caused by extension.',
  'inputs':sources,'code_sha256':digest(ROOT/'scripts/reconcile_timezone_benchmark.py'),
  'outputs':[{'path':str(q.relative_to(ROOT)),'sha256':digest(q)} for q in out.iterdir()]}
 atomic_json(out/'reconciliation.json',result);atomic_json(ROOT/'reports/timezone-benchmark-reconciliation.json',result)
 print(json.dumps({k:v for k,v in result.items() if k not in ['inputs','outputs']}))
if __name__=='__main__':main()
