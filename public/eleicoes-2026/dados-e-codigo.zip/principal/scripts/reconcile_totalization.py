"""Independent totalization-table checks against the BWeb section census.

Read one BRASIL CSV (not both it and its UF copies) per audited ZIP. Preserve
executive rows including vote validity; report discrepancies without adjustment.
"""
import io
import json
from pathlib import Path
import re

import pandas as pd

from analysis_common import ROOT, archive, atomic_json, code_fingerprint, digest, inputs, now

OUT=ROOT/'analysis/derived/totalization-v1'
GENERAL=['NR_TURNO','CD_TIPO_ELEICAO','CD_ELEICAO','DT_ELEICAO','ANO_ELEICAO','SG_UF','SG_UE','CD_MUNICIPIO','NR_ZONA','CD_CARGO','ST_VOTO_EM_TRANSITO']
CANDIDATE=['NR_CANDIDATO','NM_CANDIDATO','NM_URNA_CANDIDATO','DS_SIT_TOT_TURNO','NM_TIPO_DESTINACAO_VOTOS']
DATES={2014:['05/10/2014','26/10/2014'],2018:['07/10/2018','28/10/2018'],2022:['02/10/2022','30/10/2022'],2024:['06/10/2024','27/10/2024'],2026:['04/10/2026','25/10/2026']}


def extract(row):
    category,year=row['category'],row['year'];folder=OUT/str(year)/category
    folder.mkdir(parents=True,exist_ok=True);complete=folder/'complete.json'
    if complete.exists():
        m=json.loads(complete.read_text())
        if m['source_sha256']!=row['hashes']['sha256']:raise ValueError('Source revision differs')
        if digest(ROOT/m['output'])!=m['output_sha256']:raise ValueError('Output changed')
        return m
    parts=[];source_counts={};selected=[]
    with archive(row,prefer_local=True) as (z,stats):
        infos=[i for i in z.infolist() if i.filename.lower().endswith('.csv')]
        brasil=[i for i in infos if i.filename.upper().endswith('_BRASIL.CSV')]
        if len(brasil)!=1:raise ValueError('Need exactly one national BRASIL member to avoid duplicate coverage')
        for info in brasil:
            selected.append({'name':info.filename,'crc32':info.CRC,'bytes':info.file_size})
            source_counts[info.filename]=0
            with z.open(info) as stream:
                for chunk in pd.read_csv(stream,sep=';',encoding='latin1',dtype=str,keep_default_na=False,chunksize=100000,
                    usecols=lambda x:x in GENERAL+CANDIDATE or x.startswith('QT_')):
                    source_counts[info.filename]+=len(chunk)
                    chunk=chunk[chunk['CD_CARGO'].isin(['1','3','11'])].copy()
                    if len(chunk):parts.append(chunk)
    data=pd.concat(parts,ignore_index=True)
    data['analysis_election_date']=pd.to_datetime(data['DT_ELEICAO'],format='mixed',dayfirst=True,errors='raise').dt.strftime('%d/%m/%Y')
    data['analysis_in_scope']=data['analysis_election_date'].isin(DATES[year]) & data['CD_TIPO_ELEICAO'].eq('2')
    for c in data.columns:
        if c.startswith('QT_') or c in ['NR_TURNO','CD_CARGO','NR_CANDIDATO','CD_ELEICAO','CD_MUNICIPIO','NR_ZONA']:
            data[c]=pd.to_numeric(data[c],errors='raise').astype('int64')
    target=folder/'executive-rows.parquet'
    if target.exists():raise ValueError('Preserve incomplete output before explicit retry')
    data.to_parquet(target,index=False,compression='zstd')
    m={'at':now(),'source':row['path'],'source_sha256':row['hashes']['sha256'],'source_etag':row['etag'],
       'selected_members':selected,'source_rows':source_counts,'executive_rows':len(data),'in_scope_rows':int(data['analysis_in_scope'].sum()),
       'output':str(target.relative_to(ROOT)),'output_sha256':digest(target),'read':stats,
       'code':code_fingerprint(['reconcile_totalization.py'])}
    atomic_json(complete,m);print(json.dumps({k:v for k,v in m.items() if k not in ['code','read','selected_members']}),flush=True)
    return m


def reconcile_detail(year,meta):
    bpath=ROOT/'analysis/derived/sections-v2'/str(year)/'section-office.parquet'
    b=pd.read_parquet(bpath)
    d=pd.read_parquet(ROOT/meta['output']);d=d[d['analysis_in_scope']].copy()
    # TTE N/S records describe disjoint electoral-roll participation populations.
    rename={'NR_TURNO':'round','SG_UF':'uf','CD_CARGO':'office','CD_ELEICAO':'election','CD_MUNICIPIO':'municipality','NR_ZONA':'zone'}
    keys=list(rename.values());d=d.rename(columns=rename)
    original_keys=keys+['ST_VOTO_EM_TRANSITO']
    if d.duplicated(original_keys).any():raise ValueError('Nonunique totalization row: examine extra grouping variables')
    vals={'QT_APTOS':'eligible','QT_COMPARECIMENTO':'attendance','QT_ABSTENCOES':'abstention','QT_VOTOS':'total_votes'}
    dg=d.groupby(keys,dropna=False)[list(vals)].sum().rename(columns=vals)
    bg=b.groupby(keys,dropna=False)[list(vals.values())].sum()
    j=bg.add_prefix('bweb_').join(dg.add_prefix('official_'),how='outer')
    for f in vals.values():j[f+'_difference']=j['bweb_'+f]-j['official_'+f]
    compared=j[['bweb_attendance','official_attendance']].notna().all(axis=1)
    differences=j[[f+'_difference' for f in vals.values()]].ne(0).any(axis=1)
    j.reset_index().to_parquet(OUT/str(year)/'municipality-zone-reconciliation.parquet',index=False,compression='zstd')
    national=j.groupby(['round','office']).sum(numeric_only=True).reset_index()
    national.to_csv(OUT/str(year)/'national-reconciliation.csv',index=False)
    result={'at':now(),'year':year,'groups':len(j),'missing_either_source_groups':int((~compared).sum()),
        'groups_with_numeric_difference':int((compared & differences).sum()),'national':json.loads(national.to_json(orient='records')),
        'status':'all_groups_match' if compared.all() and not differences.any() else 'differences_require_review',
        'bweb_input_sha256':digest(bpath),'official_extract_sha256':meta['output_sha256'],
        'interpretation':'Totalization and BWeb are distinct official products with different revision times; investigate differences, including uninstalled/aggregated sections and transit records, before asserting a result error.'}
    atomic_json(OUT/str(year)/'reconciliation.json',result)
    print(json.dumps({'year':year,'status':result['status'],'different_groups':result['groups_with_numeric_difference'],'missing_groups':result['missing_either_source_groups']}),flush=True)


def reconcile_candidates(meta):
    year=2026;d=pd.read_parquet(ROOT/meta['output']);d=d[d['analysis_in_scope']]
    keys=['round','uf','office','election','votable']
    d=d.rename(columns={'NR_TURNO':'round','SG_UF':'uf','CD_CARGO':'office','CD_ELEICAO':'election','NR_CANDIDATO':'votable'})
    dg=d.groupby(keys,dropna=False)[['QT_VOTOS_NOMINAIS','QT_VOTOS_NOMINAIS_VALIDOS']].sum()
    bp=next((ROOT/'analysis/derived/sections-v1').glob('2026-*/candidate-totals-uf.parquet'))
    b=pd.read_parquet(bp);b=b[b['votable_type']==1]
    j=b.set_index(keys).join(dg,how='outer')
    j['nominal_difference']=j['votes']-j['QT_VOTOS_NOMINAIS']
    j.reset_index().to_parquet(OUT/'2026/candidate-uf-reconciliation.parquet',index=False,compression='zstd')
    result={'at':now(),'rows':len(j),'missing_either_source_rows':int(j[['votes','QT_VOTOS_NOMINAIS']].isna().any(axis=1).sum()),
       'different_nominal_rows':int(j['nominal_difference'].fillna(0).ne(0).sum()),
       'sum_bweb_nominal_votes':int(j['votes'].sum()),'sum_official_nominal_votes':int(j['QT_VOTOS_NOMINAIS'].sum()),
       'bweb_sha256':digest(bp),'official_extract_sha256':meta['output_sha256'],'status':'requires_review'}
    if not result['missing_either_source_rows'] and not result['different_nominal_rows']:result['status']='all_candidate_uf_totals_match'
    atomic_json(OUT/'2026/candidate-reconciliation.json',result);print(json.dumps(result),flush=True)


def main():
    rows=inputs();errors=[]
    for year in DATES:
        match=[r for r in rows if r['year']==year and r['category']=='detalhe_votacao_munzona']
        try:
            if len(match)!=1:raise ValueError('Need one audited detail archive')
            meta=extract(match[0]);reconcile_detail(year,meta)
        except Exception as e:errors.append({'year':year,'category':'detail','error':repr(e)})
    try:
        row=next(r for r in rows if r['year']==2026 and r['category']=='votacao_candidato_munzona')
        reconcile_candidates(extract(row))
    except Exception as e:errors.append({'year':2026,'category':'candidates','error':repr(e)})
    atomic_json(ROOT/'reports/totalization-reconciliation-state.json',{'at':now(),'status':'extraction_or_reconciliation_errors' if errors else 'finished_pending_difference_review','execution_errors':errors})
    print(json.dumps(errors),flush=True)


if __name__=='__main__':main()
