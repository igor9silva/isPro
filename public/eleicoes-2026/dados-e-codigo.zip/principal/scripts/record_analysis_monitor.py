"""Read-only process/checkpoint observation; write compact versioned monitoring.

This records execution progress, not scientific approval of the extracted data.
It does not restart jobs or change the app automation.
"""
from collections import Counter
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import shutil
import time

import psutil

from analysis_common import ROOT, atomic_json, digest

JOBS = ['native-2026-v1', 'native-history-v2', 'log-validation', 'temporal-features-v1',
        'log-exceptions-v1', 'native-member-recovery-v1', 'log-context-v1', 'reviewed-temporal-v1',
        'context-validation-v2', 'consolidation-v1']
ROOTS = ['analysis/derived/native-logs-v1/2026', 'analysis/derived/native-logs-history-v2/2022',
         'analysis/derived/native-logs-history-v2/2024']


def main():
    timestamp = datetime.now(timezone.utc)
    old_path = ROOT / 'reports/monitor-state.json'
    old = json.loads(old_path.read_text())
    history = ROOT / 'reports/monitor-history' / f'analysis-{time.time_ns()}.json'
    atomic_json(history, old)
    observations, years = [], {}
    for directory in ROOTS:
        year = int(Path(directory).name)
        counts = Counter()
        for path in sorted((ROOT / directory).glob('*/checkpoint.json')):
            cp = json.loads(path.read_text())
            complete_path = path.with_name('complete.json')
            complete = json.loads(complete_path.read_text()) if complete_path.exists() else {}
            recovered = complete.get('member_recovery', complete.get('recovery', {})).get('recovered_members', 0)
            failures = cp.get('failed_members', [])
            record = {'source_path': cp['source_path'], 'state': str(path.relative_to(ROOT)),
                      'status': cp['status'], 'processed_members': cp.get('next_member_index', 0),
                      'member_count': cp.get('member_count', 0), 'updated_at': cp.get('updated_at'),
                      'failed_members_original': len(failures), 'recovered_members': recovered,
                      'unresolved_member_failures': max(0, len(failures) - recovered),
                      'completion_manifest_present': bool(complete)}
            counts['processed_members'] += record['processed_members']
            counts['unresolved_member_failures'] += record['unresolved_member_failures']
            counts['recovered_members'] += recovered
            counts['completed_archives'] += bool(complete)
            counts['started_archives'] += 1
            counts[cp['status']] += 1
            observations.append(record)
        years[str(year)] = dict(counts)
    jobs, rates = [], {}
    for name in JOBS:
        launch = ROOT / 'metadata/analysis-jobs' / name / 'launch.json'
        if not launch.exists():
            continue
        item = json.loads(launch.read_text())
        record = {'name': name, 'launch': str(launch.relative_to(ROOT)), 'pid': item['pid'],
                  'log': item['log'], 'alive': False}
        try:
            process = psutil.Process(item['pid'])
            commands = process.cmdline()
            script = Path(item['args'][0]).name
            record['alive'] = process.is_running() and any(Path(part).name == script for part in commands)
            record['process_status'] = process.status()
            record['cpu_seconds'] = sum(process.cpu_times()[:2])
            record['children'] = [{'pid': child.pid, 'status': child.status(), 'rss': child.memory_info().rss}
                                  for child in process.children(recursive=True)]
        except (psutil.NoSuchProcess, psutil.AccessDenied) as exc:
            record['process_check_note'] = type(exc).__name__
        log = ROOT / item['log']
        record['log_last_modified_at'] = datetime.fromtimestamp(log.stat().st_mtime, timezone.utc).isoformat()
        record['code_matches_launch'] = digest(ROOT / 'scripts' / Path(item['args'][0]).name) == item.get('script_sha256')
        jobs.append(record)
        if name in ['native-2026-v1', 'native-history-v2']:
            before, after = {}, {}
            cutoff = timestamp - timedelta(hours=1)
            for line in log.open():
                try:
                    event = json.loads(line)
                    if 'processed' not in event or 'source' not in event:
                        continue
                    moment = datetime.fromisoformat(event['at'])
                    after[event['source']] = max(after.get(event['source'], 0), event['processed'])
                    if moment <= cutoff:
                        before[event['source']] = max(before.get(event['source'], 0), event['processed'])
                except (ValueError, KeyError):
                    continue
            delta = sum(after.values()) - sum(before.values())
            rates[name] = {'window_seconds': 3600, 'new_processed_members': delta,
                           'members_per_hour': delta, 'meaning': 'new package attempts; not votes or unique physical sections'}
    result = {**old, 'checked_at': timestamp.isoformat(), 'status': 'collection_audited_analysis_running',
              'analysis_jobs': jobs, 'native_archive_observations': observations,
              'native_log_members_processed': sum(x['processed_members'] for x in observations),
              'native_member_failures_current_versions': sum(x['unresolved_member_failures'] for x in observations),
              'native_member_recoveries': sum(x['recovered_members'] for x in observations),
              'native_extraction_by_year': years, 'recent_extraction_rates': rates,
              'disk_free_bytes': shutil.disk_usage(ROOT).free,
              'analysis_derived_bytes_local': sum(p.stat().st_size for p in (ROOT / 'analysis/derived').rglob('*') if p.is_file()),
              'memory_available_bytes': psutil.virtual_memory().available,
              'previous_monitor_snapshot': str(history.relative_to(ROOT)),
              'current_analysis_step': 'National native logs, independent result reconciliation, internal section-context audit and temporal validation.',
              'remaining': 'Complete extraction and exception/context review, population temporal comparisons, conditional margin bounds and sensitivity, figures/report/appendix and critical review.'}
    atomic_json(old_path, result)
    snapshot = ROOT / 'reports/monitor-history' / f'observation-{time.time_ns()}.json'
    atomic_json(snapshot, result)
    print(json.dumps({k: result[k] for k in ['checked_at', 'native_log_members_processed', 'native_member_failures_current_versions',
                                          'native_member_recoveries', 'native_extraction_by_year', 'recent_extraction_rates', 'disk_free_bytes']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
