"""Recover only failed native members after their original archive job ends.

Original checkpoint and batches remain unchanged. A new completion manifest
references them plus separately verified recovery batches with the same parser.
"""
import argparse
import copy
import hashlib
import json
import time

import pyarrow as pa
import pyarrow.parquet as pq

from analysis_common import ROOT, archive, atomic_json, code_fingerprint, digest, inputs, now
from extract_native_logs import make_schema
from parse_urna_logs import parse_package as parse_modern
from parse_urna_logs_legacy import parse_package as parse_legacy
from watch_analysis_validation import active_jobs

ROOTS = ['analysis/derived/native-logs-v1/2026', 'analysis/derived/native-logs-history-v2']


def validate_checkpoint(cp, row):
    if cp['status'] != 'complete_with_member_errors' or cp['next_member_index'] != cp['member_count']:
        raise ValueError('Original archive extraction is not finished')
    if not cp['failed_members']:
        raise ValueError('No failed members to recover')
    if cp['source_sha256'] != row['hashes']['sha256'] or cp['source_etag'] != row['etag']:
        raise ValueError('Input identity changed')
    if cp['code'] != code_fingerprint(list(cp['code'])):
        raise ValueError('Parser/acquisition code changed; explicit new version is required')
    names = [m['member'] for m in cp['failed_members']]
    if len(names) != len(set(names)):
        raise ValueError('Duplicate failed member identities')


def validate_rows(records, member, dates):
    if len(records) != len(dates) or {r['event_date'] for r in records} != set(dates):
        raise ValueError('Recovered dates differ from original extraction contract')
    if any(r['source_member'] != member for r in records):
        raise ValueError('Recovered member identity differs')


def recover(cp_path, row):
    complete = cp_path.parent / 'complete.json'
    if complete.exists():
        return json.loads(complete.read_text()).get('recovery')
    original_sha = digest(cp_path)
    cp = json.loads(cp_path.read_text())
    validate_checkpoint(cp, row)
    failed_names = {m['member'] for m in cp['failed_members']}
    for batch in cp['batches']:
        path = ROOT / batch['path']
        if digest(path) != batch['sha256']:
            raise ValueError('Original extracted batch changed')
        if failed_names.intersection(pq.read_table(path, columns=['source_member'])['source_member'].to_pylist()):
            raise ValueError('Failed member already has records; refusing double count')
    stamp = str(time.time_ns())
    recovery_dir = cp_path.parent / ('recovery-' + stamp)
    recovery_dir.mkdir(exist_ok=False)
    recovered, new_stats = [], {}
    for failure in cp['failed_members']:
        error = None
        for attempt in range(3):
            try:
                with archive(row) as (z, read):
                    members = [i for i in z.infolist() if i.filename.lower().endswith(('-log.jez', '.logjez'))]
                    index_sha = hashlib.sha256(json.dumps([(i.filename, i.CRC, i.file_size) for i in members]).encode()).hexdigest()
                    if index_sha != cp['member_index_sha256']:
                        raise ValueError('Archive member inventory changed')
                    info = members[failure['index']]
                    if info.filename != failure['member'] or info.file_size > 256*1024**2:
                        raise ValueError('Member identity/size differs')
                    payload = z.read(info)
                    if row['year'] == 2026:
                        records, counters = parse_modern(payload, info.filename, cp['target_dates'])
                    else:
                        uf = cp_path.parent.name.rsplit('_', 1)[1]
                        records, counters = parse_legacy(payload, info.filename, cp['target_dates'], uf)
                validate_rows(records, failure['member'], cp['target_dates'])
                for record in records:
                    record['source_path'] = row['path']
                path = recovery_dir / f"member-{failure['index']:07d}.parquet"
                pq.write_table(pa.Table.from_pylist(records, schema=make_schema()), path, compression='zstd')
                # Decode persisted output and verify the rows we are about to expose.
                validate_rows(pq.read_table(path).to_pylist(), failure['member'], cp['target_dates'])
                recovered.append({'path': str(path.relative_to(ROOT)), 'sha256': digest(path), 'bytes': path.stat().st_size,
                    'rows': len(records), 'recovered_member_index': failure['index'], 'recovered_member': info.filename,
                    'original_package_sha256': hashlib.sha256(payload).hexdigest(), 'read': read})
                for k, value in counters.items():
                    new_stats[k] = new_stats.get(k, 0) + value
                error = None
                break
            except Exception as exc:
                error = repr(exc)
                atomic_json(recovery_dir / 'attempt-error.json', {'at': now(), 'member': failure['member'], 'attempt': attempt+1, 'error': error})
        if error:
            raise RuntimeError(error)
    if digest(cp_path) != original_sha or complete.exists():
        raise ValueError('Original checkpoint or completion changed during recovery')
    result = copy.deepcopy(cp)
    record = {'at': now(), 'original_checkpoint': str(cp_path.relative_to(ROOT)), 'original_checkpoint_sha256': original_sha,
        'original_failed_members': cp['failed_members'], 'recovered_members': len(recovered), 'batches': recovered,
        'code': code_fingerprint(['recover_native_members.py']), 'parser_code_unchanged': True}
    result['batches'] += recovered
    for k, value in new_stats.items():
        result['stats'][k] = result['stats'].get(k, 0) + value
    result.update(status='complete', failed_members=[], recovery=record, finished_at=now())
    atomic_json(recovery_dir / 'recovery.json', record)
    atomic_json(complete, result)
    print(json.dumps({'at': now(), 'source': row['path'], 'recovered_members': len(recovered), 'complete': str(complete.relative_to(ROOT))}), flush=True)
    return record


def main():
    p = argparse.ArgumentParser(); p.add_argument('--watch', action='store_true'); args = p.parse_args()
    index = {r['path']: r for r in inputs()}
    while True:
        recovered, errors = [], []
        for root in ROOTS:
            for cp_path in sorted((ROOT / root).rglob('checkpoint.json')):
                cp = json.loads(cp_path.read_text())
                if cp['status'] != 'complete_with_member_errors':
                    continue
                try:
                    record = recover(cp_path, index[cp['source_path']])
                    recovered.append({'source': cp['source_path'], 'recovery': record})
                except Exception as exc:
                    errors.append({'source': cp['source_path'], 'error': repr(exc)})
        active = active_jobs() if args.watch else []
        atomic_json(ROOT / 'reports/native-member-recovery-state.json', {'at': now(),
            'status': 'watching' if active else 'finished' if not errors else 'requires_review',
            'recovered_archives': len(recovered), 'recovered_members': sum(r['recovery']['recovered_members'] for r in recovered),
            'records': recovered, 'errors': errors, 'active_extraction_jobs': active,
            'note': 'Original job run summaries may still show failures; preserved completion manifests include separately recovered members. Do not restart entire archives.'})
        if not active:
            break
        time.sleep(120)


if __name__ == '__main__':
    main()
