"""Review zero-vote placeholders without overwriting canonical table version 1."""
import json
from pathlib import Path
import time

import duckdb
import pandas as pd

from analysis_common import ROOT, atomic_json, code_fingerprint, digest, now


def is_zero_vote_placeholder(table):
    return ((table['candidate_rows'] == 1) & (table['distinct_votables'] == 0)
            & (table['total_votes'] == 0) & (table['attendance'] == 0)
            & (table['invalid_vote_rows'] == 1))


def main():
    results = []
    con = duckdb.connect()
    con.execute("SET threads=2")
    con.execute("SET memory_limit='2GB'")
    for year in [2014, 2018, 2022, 2024, 2026]:
        sources = list((ROOT / 'analysis/derived/sections-v1').glob(f'{year}-*/quality.json'))
        if len(sources) != 1:
            raise ValueError('Ambiguous section-table version')
        source = sources[0]
        meta = json.loads(source.read_text())
        for out in meta['outputs']:
            if digest(ROOT / out['path']) != out['sha256']:
                raise ValueError('Input table hash changed')
        table = pd.read_parquet(source.parent / 'section-office.parquet')
        flag = is_zero_vote_placeholder(table)
        rawroot = 'bweb-2014-v1' if year == 2014 else 'bweb-v1'
        files = [str(p) for p in (ROOT / 'analysis/derived' / rawroot / str(year)).glob('*/*.parquet')]
        con.read_parquet(files, union_by_name=True).create_view('raw', replace=True)
        ufcol = 'SG_UF' if 'SG_UF' in con.table('raw').columns else 'SG_ UF'
        keys = ['NR_TURNO', ufcol, 'CD_ELEICAO', 'CD_MUNICIPIO', 'NR_ZONA', 'NR_SECAO', 'CD_CARGO_PERGUNTA', 'NR_VOTAVEL']
        cols = ','.join('"'+k+'"' for k in keys)
        duplicates = con.sql('SELECT '+cols+',count(*) AS n FROM raw GROUP BY '+cols+' HAVING count(*)>1').df()
        bad = con.sql("SELECT * FROM raw WHERE try_cast(NR_VOTAVEL AS BIGINT) IS NULL").df()
        allowed_empty = bad['NR_VOTAVEL'].fillna('').isin(['', '#NULO#'])
        valid_empty = allowed_empty & pd.to_numeric(bad['QT_VOTOS']).eq(0) & pd.to_numeric(bad['QT_COMPARECIMENTO']).eq(0)
        if len(duplicates) or not valid_empty.all() or len(bad) != int(flag.sum()):
            raise ValueError('New candidate-key issue requires explicit review')
        if not table.loc[~flag, 'duplicate_votable_rows'].eq(0).all():
            raise ValueError('Unexpected duplicate flag beyond reviewed placeholders')
        table['legacy_duplicate_votable_rows'] = table['duplicate_votable_rows']
        table['legacy_invalid_vote_rows'] = table['invalid_vote_rows']
        table['zero_vote_placeholder'] = flag
        table.loc[flag, ['duplicate_votable_rows', 'invalid_vote_rows']] = 0
        table['usable_turnout'] = (~table['metadata_conflict'] & table['duplicate_votable_rows'].eq(0)
                                   & table['electorate_identity_ok'] & table['votes_attendance_identity_ok']
                                   & table['invalid_vote_rows'].eq(0))
        table['usable_turnout_rate'] = table['usable_turnout'] & table['eligible'].gt(0)
        table['usable_timing'] = table['usable_turnout'] & table['uf'].ne('ZZ') & table['closed_elapsed_seconds'].between(0,172800)
        target = ROOT / 'analysis/derived/sections-v2' / str(year)
        target.mkdir(parents=True, exist_ok=False)
        output = target / 'section-office.parquet'
        table.to_parquet(output, index=False, compression='zstd')
        table.loc[flag, ['year','round','uf','municipality','zone','section','office','eligible','attendance','total_votes']].to_csv(target / 'zero-vote-placeholders.csv', index=False)
        result = {'at':now(), 'year':year, 'status':'placeholder_review_passed_pending_result_and_timing_reconciliation',
                  'source_quality':str(source.relative_to(ROOT)), 'source_quality_sha256':digest(source),
                  'rows':len(table), 'zero_vote_placeholders':int(flag.sum()), 'actual_duplicate_candidate_keys':len(duplicates),
                  'zero_vote_placeholder_eligible':int(table.loc[flag,'eligible'].sum()),
                  'zero_denominator_rows':int(table['eligible'].eq(0).sum()),
                  'unusable_turnout_rows':int((~table['usable_turnout']).sum()),
                  'output':str(output.relative_to(ROOT)), 'output_sha256':digest(output),
                  'code':code_fingerprint(['review_section_tables.py']),
                  'meaning':'Missing candidate identifiers on zero-vote rows are not duplicated candidates. No source votes or attendance were changed. Null rates for zero denominators remain null; cancellation status is not inferred.'}
        atomic_json(target/'quality.json',result)
        results.append(result)
        print(json.dumps(result),flush=True)
    atomic_json(ROOT/'reports/section-placeholder-review.json',{'at':now(),'years':results})


if __name__ == '__main__':
    main()
