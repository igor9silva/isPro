"""Audit every nonempty first-turn retention found in second-turn packages.

This creates evidence for a later versioned sensitivity, never automatic count
fitting or replacement. Selection does not depend on agreement with BWeb.
"""
import hashlib,json,time
from collections import defaultdict
from analysis_common import ROOT,archive,atomic_json,digest,inputs,now
from audit_log_context import audit
from extract_native_logs import DATES

def main():
    out=ROOT/'analysis/source-audit/supplemental-context-v1'/str(time.time_ns());out.mkdir(parents=True,exist_ok=False)
    groups=defaultdict(list);provenance=[]
    for p in sorted((ROOT/'analysis/source-audit/supplemental-log-review-v1').glob('*secondary-source.json')):
        d=json.loads(p.read_text());provenance.append({'path':str(p.relative_to(ROOT)),'sha256':digest(p)})
        for r in d['secondary_records']:
            if r['metrics']['observed_completions']>0:groups[(d['year'],d['uf'])].append(r)
    inventory={r['path']:r for r in inputs()};results=[]
    for (year,uf),records in groups.items():
        source=f'raw/{year}/arquivos_urna/bu_imgbu_logjez_rdv_vscmr_{year}_2t_{uf}.zip'
        with archive(inventory[source],block_size=512*1024) as (z,stats):
            for r in records:
                payload=z.read(r['secondary_member'])
                if hashlib.sha256(payload).hexdigest()!=r['secondary_package_sha256']:raise ValueError('Secondary package changed')
                target=dict(zip(['municipality','zone','section'],r['section']))
                context=audit(payload,r['secondary_member'],DATES[year][1],target,1)
                cp=out/f'{year}-{uf}-'+str(r['section'][0]) if False else out/f"{year}-{uf}-{'-'.join(map(str,r['section']))}.json"
                atomic_json(cp,context)
                counts={k:len(v) for k,v in context['completion_seconds'].items()}
                result={'year':year,'uf':uf,**target,'primary_count_before_context_review':r['primary_count'],
                        'bweb_attendance':r['bweb_attendance'],'secondary_all_contexts':r['metrics']['observed_completions'],
                        **{k+'_completions':v for k,v in counts.items()},
                        'secondary_clock_reversals':r['metrics']['clock_backwards_count'],
                        'secondary_parse_flags':r['metrics']['unparsed_target_date_lines']+r['metrics']['invalid_clock_lines'],
                        'evidence':str(cp.relative_to(ROOT)),'evidence_sha256':digest(cp),
                        'applied_to_primary':False,'pending':'Compare reviewed primary target events and overlap, then define explicit sensitivity layer; equality to BWeb alone is insufficient.'}
                results.append(result)
                print(json.dumps({'year':year,'uf':uf,'section':r['section'],**counts}),flush=True)
    state={'at':now(),'status':'nonempty_secondary_contexts_audited_not_applied','output_folder':str(out.relative_to(ROOT)),
           'cases':results,'inputs':provenance,'code_sha256':digest(ROOT/'scripts/review_supplemental_context.py')}
    atomic_json(out/'review.json',state);atomic_json(ROOT/'reports/supplemental-context-review-state.json',state)
if __name__=='__main__':main()
