"""Versioned context-qualified temporal measurements; source features immutable."""
import argparse
import json
from pathlib import Path
import time

import numpy as np
import pandas as pd

from analysis_common import ROOT, atomic_json, code_fingerprint, digest, now
from derive_temporal_features import threshold_counts

OUT = ROOT / 'analysis/derived/temporal-reviewed-v1'
KEYS = ['municipality', 'zone', 'section']


def reviewed_context(result, primary_count, package_sha):
    if result['package_sha256'] != package_sha:
        raise ValueError('Context source identity differs')
    classes = result['completion_seconds']
    counts = {k: len(classes[k]) for k in ['target', 'foreign', 'unknown', 'conflicting']}
    if sum(counts.values()) != primary_count or result['unique_completions_all_contexts'] != primary_count:
        raise ValueError('Context and primary complete-event populations differ')
    return classes['target'], counts, counts['unknown'] == 0 and counts['conflicting'] == 0


def process(mp):
    meta = json.loads(mp.read_text())
    year, turn, uf = meta['year'], meta['round'], meta['uf']
    if not meta.get('outputs'):
        return {'year': year, 'round': turn, 'uf': uf, 'status': 'structural_absence_no_sections'}
    cp = ROOT / f'analysis/source-audit/log-context-v1/{year}-{turn}t-{uf}/complete.json'
    if not cp.exists():
        return {'year': year, 'round': turn, 'uf': uf, 'status': 'waiting_context_audit'}
    context_meta = json.loads(cp.read_text())
    if context_meta['feature_manifest_sha256'] != digest(mp):
        raise ValueError('Context audit belongs to a different feature manifest')
    out = OUT / str(year) / f'{turn}t-{uf}'
    code = code_fingerprint(['review_temporal_features.py'])
    if (out / 'complete.json').exists():
        previous = json.loads((out / 'complete.json').read_text())
        if previous['code'] != code or previous['input_manifest_sha256'] != digest(mp) or previous['context_manifest_sha256'] != digest(cp):
            raise ValueError('Reviewed version changed; create another version')
        for row in previous['outputs']:
            if digest(ROOT / row['path']) != row['sha256']:
                raise ValueError('Reviewed output changed')
        return previous
    source = mp.parent / 'sections.parquet'
    if digest(source) != next(x['sha256'] for x in meta['outputs'] if x['path'].endswith('sections.parquet')):
        raise ValueError('Original temporal features changed')
    f = pd.read_parquet(source)
    if f.duplicated(KEYS).any():
        raise ValueError('Nonunique section key')
    f = f.set_index(KEYS, drop=False)
    metrics = threshold_counts([], None)
    for name in metrics:
        f['reviewed_' + name] = f['day_' + name]
    f['context_audited'] = False
    f['context_known'] = f.log_present
    f['context_foreign_completions'] = 0
    f['context_unknown_completions'] = 0
    f['context_conflicting_completions'] = 0
    f['context_qualified_change'] = False
    f['clock_diagnostic_available'] = False
    f['clock_reversals_after_completion_in_text'] = 0
    f['startup_reversal_only'] = False
    inputs, changes = [], []
    for path in sorted(cp.parent.glob('[0-9]*.json')):
        r = json.loads(path.read_text())
        key = tuple(r['target'][k] for k in KEYS)
        if key not in f.index:
            raise ValueError('Context report has no feature row')
        row = f.loc[key]
        seconds, counts, known = reviewed_context(r, int(row.day_observed_completions), row.source_package_sha256)
        if r['date'] != {2026: {1: '04/10/2026', 2: '25/10/2026'}, 2022: {1: '02/10/2022', 2: '30/10/2022'}, 2024: {1: '06/10/2024', 2: '27/10/2024'}}[year][turn]:
            raise ValueError('Context event date differs')
        f.loc[key, 'context_audited'] = True
        f.loc[key, 'context_known'] = known
        for kind in ['foreign', 'unknown', 'conflicting']:
            f.loc[key, 'context_' + kind + '_completions'] = counts[kind]
        if any(counts[k] for k in ['foreign', 'unknown', 'conflicting']):
            deadline = row.ordinary_deadline_local_seconds if pd.notna(row.ordinary_deadline_local_seconds) else None
            values = threshold_counts(seconds, deadline)
            for name, value in values.items():
                f.loc[key, 'reviewed_' + name] = value
            f.loc[key, 'context_qualified_change'] = True
            changes.append({**dict(zip(KEYS, key)), 'original': int(row.day_observed_completions),
                            'reviewed': len(seconds), 'attendance': int(row.attendance), **counts,
                            'evidence': str(path.relative_to(ROOT))})
        inputs.append({'path': str(path.relative_to(ROOT)), 'sha256': digest(path)})
    # A complete context manifest must cover every nested/exception row selected
    # in the primary audit. Absence of a report cannot silently pass validation.
    required = f.log_present & ((f.day_text_file_count > 1) | (f.day_nested_archive_count > 0)
        | ~f.count_matches_day | (f.day_clock_backwards_count > 0)
        | (f.day_unparsed_target_date_lines > 0) | (f.day_invalid_clock_lines > 0))
    if (required & ~f.context_audited).any():
        raise ValueError('Context audit incomplete for required rows')
    for key, row in f[f.day_clock_backwards_count > 0].iterrows():
        path = ROOT / f'analysis/source-audit/log-exceptions-v1/{year}-{turn}t-{uf}/{key[0]}-{key[1]}-{key[2]}.json'
        if not path.exists():
            raise ValueError('Clock exception inspection pending')
        r = json.loads(path.read_text())
        if r['original_package_sha256'] != row.source_package_sha256:
            raise ValueError('Clock diagnostic source differs')
        f.loc[key, 'clock_diagnostic_available'] = True
        f.loc[key, 'clock_reversals_after_completion_in_text'] = r['reversals_after_completed_vote_in_text']
        f.loc[key, 'startup_reversal_only'] = r['reversals_before_any_completed_vote_in_text'] > 0 and r['reversals_after_completed_vote_in_text'] == 0
        inputs.append({'path': str(path.relative_to(ROOT)), 'sha256': digest(path)})
    f['reviewed_count_matches_day'] = f.log_present & f.reviewed_observed_completions.eq(f.attendance) & f.context_known
    f['reviewed_gap_if_no_spurious'] = (f.attendance - f.reviewed_observed_completions).clip(lower=0)
    f.loc[~f.log_present, 'reviewed_gap_if_no_spurious'] = f.loc[~f.log_present, 'attendance']
    no_parse = f.day_unparsed_target_date_lines.eq(0) & f.day_invalid_clock_lines.eq(0)
    basic = f.reviewed_count_matches_day & f.uf.ne('ZZ') & f.following_observed_completions.eq(0) & no_parse
    f['reviewed_strict_time_eligible'] = basic & f.day_clock_backwards_count.eq(0)
    f['reviewed_startup_allowed_time_eligible'] = basic & (f.day_clock_backwards_count.eq(0) | f.startup_reversal_only)
    f['reviewed_last_vote_minus_bweb_close'] = f.reviewed_last_completed_second - f.closed_elapsed_seconds
    f['apuration_status_code'] = f.machine_type
    f['operational_context_contaminated'] = f.context_foreign_completions.gt(0) | f.context_unknown_completions.gt(0) | f.context_conflicting_completions.gt(0)
    out.mkdir(parents=True, exist_ok=True)
    target = out / 'sections.parquet'
    if target.exists():
        raise ValueError('Refusing to overwrite partial reviewed file')
    f.reset_index(drop=True).to_parquet(target, index=False, compression='zstd')
    audit_path = out / 'review-evidence.json'
    atomic_json(audit_path, {'inputs': inputs, 'changes': changes})
    result = {'at': now(), 'year': year, 'round': turn, 'uf': uf,
        'status': 'context_reviewed_recorded_time_features', 'input_manifest': str(mp.relative_to(ROOT)),
        'input_manifest_sha256': digest(mp), 'context_manifest': str(cp.relative_to(ROOT)), 'context_manifest_sha256': digest(cp),
        'section_rows': len(f), 'missing_logs': int((~f.log_present).sum()),
        'context_audited_packages': int(f.context_audited.sum()), 'context_changed_packages': int(f.context_qualified_change.sum()),
        'removed_foreign_completions': int(f.context_foreign_completions.sum()),
        'unresolved_context_packages': int((f.log_present & ~f.context_known).sum()),
        'remaining_count_mismatches': int((f.log_present & ~f.reviewed_count_matches_day).sum()),
        'reviewed_count_matches': int(f.reviewed_count_matches_day.sum()),
        'post_vote_clock_reversal_packages': int(f.clock_reversals_after_completion_in_text.gt(0).sum()),
        'recorded_post_deadline': int(f.reviewed_after_ordinary_p0.sum()),
        'exact_deadline_events': int(f.reviewed_at_ordinary_deadline.sum()),
        'code': code, 'outputs': [{'path': str(p.relative_to(ROOT)), 'sha256': digest(p), 'bytes': p.stat().st_size} for p in [target, audit_path]],
        'limitations': ['Recorded clock counts are not causal effects; no external clock accuracy is established.',
            'All nested/multiple-text and exception packages, and five simple packages per archive, had internal-context audit; other simple packages rely on outer identity and count reconciliation.',
            'Context-foreign events are excluded by explicit IDs, not by fitting counts. Unknown/conflicting contexts remain flagged.',
            'Operational event timestamps from a context-contaminated original package remain flagged; only completion-event counts/times are context-corrected here.',
            'The startup-allowed subset is a separate sensitivity. Before-first-completion in a text is not proof of globally accurate clocks.',
            'CD_TIPO_URNA is apuration status, not hardware model. Overseas has no inferred Brasilia offset in this layer.']}
    atomic_json(out / 'complete.json', result)
    print(json.dumps({k:v for k,v in result.items() if k not in ['outputs','limitations','code']}), flush=True)
    return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--years',default='2026');parser.add_argument('--watch',action='store_true');args=parser.parse_args()
    years=[int(x) for x in args.years.split(',')]
    while True:
        results, errors = [], []
        for year in years:
            for mp in sorted((ROOT/'analysis/derived/temporal-features-v1'/str(year)).glob('*/complete.json')):
                try: results.append(process(mp))
                except Exception as exc: errors.append({'manifest':str(mp.relative_to(ROOT)),'error':repr(exc)})
        status={'at':now(),'years':years,'status':'reviewed_available_archives_pending_full_population_analysis',
                'completed':sum(r['status']=='context_reviewed_recorded_time_features' for r in results),
                'waiting':sum(r['status']=='waiting_context_audit' for r in results),'errors':errors,
                'outputs':[{'year':r['year'],'round':r['round'],'uf':r['uf'],'status':r['status']} for r in results]}
        atomic_json(ROOT/'reports/reviewed-temporal-state.json',status)
        if not args.watch: break
        # Watch until both input construction and context audit finish, including
        # recovery/feature tails. A new heartbeat still checks expected coverage.
        import psutil
        active=False
        for name in ['native-2026-v1','native-history-v2','temporal-features-v1','log-context-v1']:
            lp=ROOT/f'metadata/analysis-jobs/{name}/launch.json'
            if lp.exists():
                launch=json.loads(lp.read_text())
                try: active |= psutil.Process(launch['pid']).is_running() and any(Path(c).name==Path(launch['args'][0]).name for c in psutil.Process(launch['pid']).cmdline())
                except (psutil.NoSuchProcess,psutil.AccessDenied): pass
        if not active: break
        time.sleep(300)


if __name__=='__main__': main()
