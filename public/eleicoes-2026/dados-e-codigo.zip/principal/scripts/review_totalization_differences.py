"""Explain observed official-product differences without changing source data."""
import json
from pathlib import Path

import pandas as pd
from pypdf import PdfReader

from analysis_common import ROOT, archive, atomic_json, digest, inputs, now

OUT = ROOT / 'analysis/derived/totalization-review-v1'
KEYS = ['round', 'uf', 'office', 'election', 'municipality', 'zone']


def extract_reference(row, suffix, usecols, predicate, name):
    folder = OUT / name
    folder.mkdir(parents=True, exist_ok=True)
    complete = folder / 'complete.json'
    if complete.exists():
        m = json.loads(complete.read_text())
        assert m['source_sha256'] == row['hashes']['sha256']
        assert digest(ROOT / m['output']) == m['output_sha256']
        return pd.read_parquet(ROOT / m['output'])
    selected = []
    n = 0
    with archive(row, prefer_local=True) as (z, stats):
        member = next(i for i in z.infolist() if i.filename.upper().endswith(suffix))
        with z.open(member) as f:
            for chunk in pd.read_csv(f, sep=';', encoding='latin1', dtype=str,
                                     keep_default_na=False, chunksize=100000, usecols=usecols):
                n += len(chunk)
                selected.append(chunk.loc[predicate(chunk)].copy())
        pdf = next((i for i in z.infolist() if i.filename.lower() == 'leiame.pdf'), None)
        if pdf:
            target = folder / 'leiame.pdf'
            if not target.exists():
                target.write_bytes(z.read(pdf))
            text = '\n\n'.join(p.extract_text() or '' for p in PdfReader(target).pages)
            (folder / 'leiame.extracted.txt').write_text(text)
    data = pd.concat(selected, ignore_index=True)
    target = folder / 'rows.parquet'
    if target.exists():
        raise ValueError('Preserve unfinished output before retry')
    data.to_parquet(target, index=False, compression='zstd')
    atomic_json(complete, {'at': now(), 'source': row['path'], 'source_sha256': row['hashes']['sha256'],
                          'member': member.filename, 'crc32': member.CRC, 'source_rows': n,
                          'retained_rows': len(data), 'output': str(target.relative_to(ROOT)),
                          'output_sha256': digest(target), 'read': stats})
    return data


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rows = inputs()
    reviews = []
    for year in [2014, 2018, 2022, 2024, 2026]:
        j = pd.read_parquet(ROOT / f'analysis/derived/totalization-v1/{year}/municipality-zone-reconciliation.parquet')
        s = pd.read_parquet(ROOT / f'analysis/derived/sections-v2/{year}/section-office.parquet')
        placeholders = s[s.zero_vote_placeholder].groupby(KEYS).eligible.sum().rename('placeholder_eligible')
        j = j.set_index(KEYS).join(placeholders).reset_index()
        d = pd.read_parquet(ROOT / f'analysis/derived/totalization-v1/{year}/detalhe_votacao_munzona/executive-rows.parquet')
        d = d[d.analysis_in_scope].rename(columns={'NR_TURNO': 'round', 'SG_UF': 'uf', 'CD_CARGO': 'office',
                                                 'CD_ELEICAO': 'election', 'CD_MUNICIPIO': 'municipality', 'NR_ZONA': 'zone'})
        uninstalled = d.groupby(KEYS)[['QT_ELEITORES_SECOES_NAO_INSTALADAS', 'QT_SECOES_NAO_INSTALADAS']].sum()
        j = j.set_index(KEYS).join(uninstalled).reset_index()
        j['abstention_difference_equals_zero_vote_placeholder_eligible'] = (
            j.abstention_difference.ne(0) & j.abstention_difference.eq(j.placeholder_eligible))
        j['eligible_difference_equals_negative_uninstalled_eligible'] = (
            j.eligible_difference.ne(0) & j.eligible_difference.eq(-j.QT_ELEITORES_SECOES_NAO_INSTALADAS))
        j.to_parquet(OUT / f'{year}-municipality-zone-review.parquet', index=False, compression='zstd')
        compared = j.bweb_attendance.notna() & j.official_attendance.notna()
        remaining = compared & (j.attendance_difference.ne(0) | j.total_votes_difference.ne(0) |
            (j.abstention_difference.ne(0) & ~j.abstention_difference_equals_zero_vote_placeholder_eligible) |
            (j.eligible_difference.ne(0) & ~j.eligible_difference_equals_negative_uninstalled_eligible))
        review = {'year': year, 'compared_groups': int(compared.sum()),
                  'zero_vote_placeholder_abstention_differences': int(j.abstention_difference_equals_zero_vote_placeholder_eligible.sum()),
                  'uninstalled_eligible_differences': int(j.eligible_difference_equals_negative_uninstalled_eligible.sum()),
                  'unexplained_matched_group_differences': int(remaining.sum()),
                  'official_only_groups': int(j.bweb_attendance.isna().sum()),
                  'official_only_attendance': int(j.loc[j.bweb_attendance.isna(), 'official_attendance'].sum()),
                  'bweb_only_groups': int(j.official_attendance.isna().sum()),
                  'limitations': ['Accounting identities identify where the published products differ; they do not prove the administrative reason for every historical zero-vote row.']}
        reviews.append(review)

    c = pd.read_parquet(ROOT / 'analysis/derived/totalization-v1/2026/candidate-uf-reconciliation.parquet')
    missing = c[c.QT_VOTOS_NOMINAIS.isna()]
    q = missing.groupby(['round', 'uf', 'office']).votes.sum().rename('missing_bweb_nominal')
    d = pd.read_parquet(ROOT / 'analysis/derived/totalization-v1/2026/detalhe_votacao_munzona/executive-rows.parquet')
    d = d[d.analysis_in_scope]
    t = d.groupby(['NR_TURNO', 'SG_UF', 'CD_CARGO']).QT_VOTOS_NULOS_TECNICOS.sum()
    t.index.names = q.index.names
    q = q.to_frame().join(t)
    q['difference'] = q.missing_bweb_nominal - q.QT_VOTOS_NULOS_TECNICOS
    q.to_csv(OUT / '2026-technical-null-reconciliation.csv')
    assert q.difference.eq(0).all()
    second = c[c['round'] == 2]
    assert second[['votes', 'QT_VOTOS_NOMINAIS', 'QT_VOTOS_NOMINAIS_VALIDOS']].notna().all().all()
    assert second.votes.eq(second.QT_VOTOS_NOMINAIS).all()
    assert second.votes.eq(second.QT_VOTOS_NOMINAIS_VALIDOS).all()
    missing.to_csv(OUT / '2026-first-round-candidates-absent-from-nominal-totalization.csv', index=False)

    row = next(r for r in rows if r['path'].endswith('/consulta_cand_2026.zip'))
    cand = extract_reference(row, '_BRASIL.CSV', lambda k: k in ['NR_TURNO', 'SG_UF', 'SG_UE', 'CD_CARGO',
        'NR_CANDIDATO', 'NM_URNA_CANDIDATO', 'DS_SITUACAO_CANDIDATURA', 'DS_SIT_TOT_TURNO'],
        lambda x: x.CD_CARGO.isin(['1', '3']), '2026-candidate-status')
    absent = missing[['office', 'uf', 'votable', 'votable_name']].drop_duplicates()
    cand['office'] = pd.to_numeric(cand.CD_CARGO)
    cand['votable'] = pd.to_numeric(cand.NR_CANDIDATO)
    cand['uf'] = cand.SG_UF
    governors = absent[absent.office == 3].merge(cand[cand.office == 3], on=['office', 'uf', 'votable'], how='left')
    presidents = absent[absent.office == 1].drop(columns=['uf']).drop_duplicates().merge(
        cand[cand.office == 1], on=['office', 'votable'], how='left')
    pd.concat([governors, presidents], ignore_index=True).to_csv(OUT / '2026-absent-candidate-status.csv', index=False)

    # The sole unexplained historic turnout discrepancy is localized independently.
    row = next(r for r in rows if r['path'].endswith('/votacao_secao_2018_MA.zip'))
    section = extract_reference(row, '_MA.CSV', lambda k: k in ['NR_TURNO', 'SG_UF', 'CD_MUNICIPIO', 'NR_ZONA',
        'NR_SECAO', 'CD_CARGO', 'NR_VOTAVEL', 'NM_VOTAVEL', 'QT_VOTOS', 'CD_ELEICAO'],
        lambda x: x.CD_MUNICIPIO.eq('8591') & x.NR_ZONA.eq('17') & x.NR_TURNO.eq('1') & x.CD_CARGO.isin(['1', '3']),
        '2018-ma-zone17-section-votes')
    for k in ['NR_SECAO', 'CD_CARGO', 'QT_VOTOS']:
        section[k] = pd.to_numeric(section[k], errors='raise')
    votes = section.groupby(['NR_SECAO', 'CD_CARGO']).QT_VOTOS.sum()
    votes.index.names = ['section', 'office']
    s = pd.read_parquet(ROOT / 'analysis/derived/sections-v2/2018/section-office.parquet')
    s = s[(s['round'] == 1) & (s.uf == 'MA') & (s.municipality == 8591) & (s.zone == 17)]
    comparison = s.set_index(['section', 'office'])[['eligible', 'attendance', 'abstention', 'total_votes', 'machine', 'closed', 'emitted']].join(votes.rename('official_section_votes'), how='outer')
    comparison['vote_difference'] = comparison.total_votes - comparison.official_section_votes
    comparison.reset_index().to_csv(OUT / '2018-ma-zone17-section-review.csv', index=False)
    result = {'at': now(), 'status': 'reviewed_with_localized_remaining_differences', 'year_reviews': reviews,
        'second_round_2026_candidate_uf_rows_exact': len(second),
        'second_round_2026_all_executive_nominal_votes_exact': int(second.votes.sum()),
        'first_round_2026_absent_nominal_candidate_uf_rows': len(missing),
        'first_round_2026_absent_nominal_votes': int(missing.votes.sum()),
        'all_absent_first_round_votes_reconcile_to_technical_nulls_by_uf_office': bool(q.difference.eq(0).all()),
        '2018_ma_sections_with_different_votes': json.loads(comparison[comparison.vote_difference.fillna(0).ne(0)].reset_index().to_json(orient='records')),
        'limitations': ['This compares archived official products, not an independent recount of physical ballots.',
            'Technical-null accounting does not establish the individual legal history of every candidacy.',
            '2014/2018 zero-vote placeholder electorate accounts exactly for most abstention differences; no cancellation cause is inferred.',
            'Missing official-only overseas groups have zero attendance, but affect eligible/abstention denominators and must remain visible.']}
    atomic_json(ROOT / 'reports/totalization-difference-review.json', result)
    print(json.dumps(result, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
