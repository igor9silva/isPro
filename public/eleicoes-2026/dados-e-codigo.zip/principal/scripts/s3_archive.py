"""Seekable, bounded-memory reads of immutable S3 objects for ZIP extraction."""
from collections import OrderedDict
import io


class S3RangeReader(io.RawIOBase):
    def __init__(self, client, bucket, key, expected_size=None, expected_etag=None,
                 block_size=1024 * 1024, cache_blocks=16, max_single_read=256 * 1024 * 1024):
        super().__init__()
        self.cache = OrderedDict()
        self.client, self.bucket, self.key = client, bucket, key
        head = client.head_object(Bucket=bucket, Key=key)
        self.size, self.etag = head["ContentLength"], head["ETag"]
        if expected_size is not None and self.size != expected_size:
            raise ValueError("Archived object size changed")
        if expected_etag is not None and self.etag != expected_etag:
            raise ValueError("Archived object identity changed")
        self.position = 0
        self.block_size, self.cache_blocks = block_size, cache_blocks
        self.max_single_read = max_single_read
        self.requests, self.bytes_fetched = 0, 0

    def readable(self):
        return True

    def seekable(self):
        return True

    def tell(self):
        return self.position

    def seek(self, offset, whence=0):
        if whence not in (0, 1, 2):
            raise ValueError("Invalid whence")
        position = offset + (self.position if whence == 1 else self.size if whence == 2 else 0)
        if position < 0:
            raise ValueError("Negative seek")
        self.position = position
        return position

    def _range(self, start, count):
        stop = start + count - 1
        response = self.client.get_object(Bucket=self.bucket, Key=self.key, IfMatch=self.etag,
                                          Range=f"bytes={start}-{stop}")
        try:
            if response.get("ContentRange") != f"bytes {start}-{stop}/{self.size}":
                raise ValueError("Remote server did not honor exact range")
            data = response["Body"].read(count + 1)
            if len(data) != count:
                raise ValueError("Truncated or overlong range response")
            self.requests += 1
            self.bytes_fetched += count
            return data
        finally:
            response["Body"].close()

    def read(self, count=-1):
        if count is None or count < 0:
            count = max(0, self.size - self.position)
        count = min(count, max(0, self.size - self.position))
        if count > self.max_single_read:
            raise ValueError("Unbounded archive read refused")
        if not count:
            return b""
        if count > 4 * self.block_size:
            data = self._range(self.position, count)
            self.position += count
            return data
        data = bytearray()
        while len(data) < count:
            block = self.position // self.block_size
            offset = self.position % self.block_size
            if block not in self.cache:
                start = block * self.block_size
                self.cache[block] = self._range(start, min(self.block_size, self.size - start))
                if len(self.cache) > self.cache_blocks:
                    self.cache.popitem(last=False)
            else:
                self.cache.move_to_end(block)
            take = min(count - len(data), len(self.cache[block]) - offset)
            data.extend(self.cache[block][offset:offset + take])
            self.position += take
        return bytes(data)

    def readinto(self, target):
        data = self.read(len(target))
        target[:len(data)] = data
        return len(data)

    def close(self):
        self.cache.clear()
        super().close()
