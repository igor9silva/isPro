"""Publish all residual section-level gaps/excesses and recorded clock exceptions."""
import json
import time
import pandas as pd
from analysis_common import ROOT, atomic_json, digest, now


def main():
    out = ROOT / 'analysis/derived/measurement-exceptions-v1' / str(time.time_ns())
    out.mkdir(parents=True, exist_ok=False)
    cases, totals, sources = [], [], []
    for year in [2022, 2024, 2026]:
        for mp in sorted((ROOT / f'analysis/derived/temporal-reviewed-v1/{year}').glob('*/complete.json')):
            meta = json.loads(mp.read_text()); p = mp.parent / 'sections.parquet'
            if digest(p) != next(x['sha256'] for x in meta['outputs'] if x['path'].endswith('sections.parquet')):
                raise ValueError('Measurement table changed')
            f = pd.read_parquet(p)
            observed = f.reviewed_observed_completions.fillna(0)
            deficit = (f.attendance - observed).clip(lower=0)
            excess = (observed - f.attendance).clip(lower=0)
            totals.append({'year': year, 'round': meta['round'], 'uf': meta['uf'], 'sections': len(f),
                'attendance': int(f.attendance.sum()), 'conclusions': int(observed.sum()),
                'positive_deficit': int(deficit.sum()), 'positive_excess': int(excess.sum()),
                'net_deficit': int(f.attendance.sum() - observed.sum()),
                'missing_log_sections': int((~f.log_present).sum()),
                'unresolved_context_sections': int((f.log_present & ~f.context_known).sum()),
                'following_day_conclusions': int(f.following_observed_completions.fillna(0).sum()),
                'post_completion_clock_reversal_sections': int(f.clock_reversals_after_completion_in_text.gt(0).sum())})
            flagged = ~f.log_present | ~f.reviewed_count_matches_day | f.day_clock_backwards_count.gt(0) | f.day_unparsed_target_date_lines.gt(0) | f.following_observed_completions.gt(0)
            for r in f[flagged].to_dict('records'):
                record = {k: r[k] for k in ['year', 'round', 'uf', 'municipality', 'zone', 'section', 'attendance', 'log_present',
                    'reviewed_observed_completions', 'reviewed_after_ordinary_p0', 'reviewed_gap_if_no_spurious',
                    'context_audited', 'context_known', 'context_foreign_completions', 'reviewed_strict_time_eligible',
                    'reviewed_startup_allowed_time_eligible', 'day_clock_backwards_count', 'day_unparsed_target_date_lines',
                    'following_observed_completions', 'clock_reversals_after_completion_in_text']}
                paths = {}
                for name in ['log-context-v1', 'log-exceptions-v1']:
                    ep = ROOT / f"analysis/source-audit/{name}/{year}-{meta['round']}t-{meta['uf']}/{r['municipality']}-{r['zone']}-{r['section']}.json"
                    if ep.exists(): paths[name] = {'path': str(ep.relative_to(ROOT)), 'sha256': digest(ep)}
                record['evidence_records'] = json.dumps(paths, ensure_ascii=False)
                cases.append(record)
            sources.append({'path': str(mp.relative_to(ROOT)), 'sha256': digest(mp)})
    pd.DataFrame(cases).to_csv(out / 'all-measurement-exceptions.csv', index=False)
    pd.DataFrame(cases).to_parquet(out / 'all-measurement-exceptions.parquet', index=False, compression='zstd')
    table = pd.DataFrame(totals); table.to_csv(out / 'quality-by-archive.csv', index=False)
    numeric = [k for k in table.columns if k not in ['year', 'round', 'uf']]
    domestic = table[table.uf.ne('ZZ')].groupby(['year', 'round'])[numeric].sum().reset_index()
    domestic.to_csv(out / 'quality-domestic.csv', index=False)
    result = {'at': now(), 'status': 'residual_measurement_exceptions_enumerated', 'output_folder': str(out.relative_to(ROOT)),
        'archives': len(totals), 'exception_rows': len(cases), 'domestic': domestic.to_dict('records'), 'inputs': sources,
        'code_sha256': digest(ROOT / 'scripts/summarize_measurement_exceptions.py'),
        'interpretation': ['Deficit and excess are reported separately; a net difference must not hide either.',
            'Historical counts can exceed office attendance despite target section identity. These sequences are preserved and excluded in quality-restricted sensitivities; no count-fitting correction is made.',
            '2022 MG44830/303/70 has220 own-context conclusions in two distinct texts (168+52), versus122 executive-office attendance. RN18139/65/32 has259 (10+249) versus249. Administrative causes are not observed.',
            'Three domestic first-turn sections have reversals after completion:2022RN16713/64/154 (542s),2022ES56774/30/60 (14s),2024BA38490/13/116 (4688s and61s). They are excluded from both strict and startup-only sensitivities.',
            'The additional probability context audit is2026-only; historical simple packages did not receive an equivalent probability audit. Historical descriptive comparisons are conditional on their documented scope.']}
    atomic_json(out / 'analysis.json', result)
    atomic_json(ROOT / 'reports/measurement-exception-review-state.json', result)
    print(json.dumps({'archives': len(totals), 'exception_rows': len(cases), 'domestic': result['domestic']}))


if __name__ == '__main__':
    main()
