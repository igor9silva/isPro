#!/usr/bin/env python3
"""Finish the active acquisition, then run the queued comparison collection."""
import argparse
from datetime import datetime, timezone
import json
import hashlib
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

import boto3
from botocore.config import Config

STOP = False


def stop(*_):
    global STOP
    STOP = True


def alive(pid):
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False


def read_progress(job):
    path = Path(job["state_dir"]) / "progress.json"
    if not path.exists():
        return {"selected": job["selected"], "pending": job["selected"], "verified": 0, "failed": 0, "unavailable": 0, "verified_bytes": 0}
    return {k: v for k, v in json.loads(path.read_text()).items() if k != "files"}


def recovery_matches(item, row, receipt, head, bucket, prefix):
    """Accept only a receipt for the exact preserved object and approved revision."""
    missing_companion = (item.get("status") == "unavailable"
                         and item.get("path", "").endswith(".zip")
                         and ".zip.sha" in item.get("error", ""))
    revision = row.get("source_revision_refresh", {})
    changed_source = (item.get("status") == "failed"
                      and item.get("error") == "ValueError: Official source length changed since cataloguing"
                      and bool(revision))
    if not (missing_companion or changed_source):
        return False
    if (receipt.get("status") != "verified" or receipt.get("bucket") != bucket
            or receipt.get("path") != item.get("path") or row.get("path") != item.get("path")
            or receipt.get("url") != item.get("url") or row.get("url") != item.get("url")
            or receipt.get("key") != prefix.rstrip("/") + "/" + item["path"]
            or not receipt.get("etag") or receipt["etag"] != head.get("ETag")
            or receipt.get("bytes") != head.get("ContentLength")
            or (row.get("bytes_remote") is not None and receipt.get("bytes") != row["bytes_remote"])):
        return False
    hashes = receipt.get("hashes", {})
    if not all(re.fullmatch(r"[0-9a-f]{%d}" % size, hashes.get(name, ""))
               for name, size in (("sha256", 64), ("sha512", 128))):
        return False
    if missing_companion and not receipt.get("official_checksums_unavailable"):
        return False
    if changed_source:
        expected_headers = revision.get("observed_headers", {})
        actual_headers = receipt.get("source", {}).get("headers", {})
        if not expected_headers.get("etag") or actual_headers.get("etag") != expected_headers["etag"]:
            return False
        if (expected_headers.get("last-modified")
                and actual_headers.get("last-modified") != expected_headers["last-modified"]):
            return False
    return True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--queue", required=True)
    args = parser.parse_args()
    queue_path = Path(args.queue)
    queue = json.loads(queue_path.read_text())
    jobs = queue["jobs"]
    root = Path(__file__).resolve().parents[1]
    directory = queue_path.parent
    cloud = boto3.Session(profile_name="tse-research", region_name="auto").client(
        "s3", endpoint_url="https://t3.storage.dev", config=Config(connect_timeout=20, read_timeout=30,
            retries={"max_attempts": 3}, request_checksum_calculation="when_required"))
    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, stop)

    def publish(status, active=None):
        progress = [dict(name=job["name"], **read_progress(job)) for job in jobs]
        report = {"updated_at": datetime.now(timezone.utc).isoformat(), "status": status,
                  "active_stage": active, "storage_limit_bytes": queue["storage_limit_bytes"],
                  "planned_bytes_known": queue["planned_bytes_known"], "stages": progress,
                  "selected": sum(p["selected"] for p in progress),
                  "verified": sum(p["verified"] for p in progress),
                  "verified_bytes": sum(p["verified_bytes"] for p in progress),
                  "failed": sum(p["failed"] for p in progress),
                  "unavailable": sum(p.get("unavailable", 0) for p in progress),
                  "pending": sum(p["pending"] for p in progress)}
        body = (json.dumps(report, ensure_ascii=False, indent=2) + "\n").encode()
        tmp = directory / "collection-status.json.tmp"
        tmp.write_bytes(body)
        tmp.replace(directory / "collection-status.json")
        try:
            cloud.put_object(Bucket=queue["bucket"], Key=queue["prefix"] + "/reports/collection-status.json",
                             Body=body, ContentType="application/json")
        except Exception as error:
            print("Status upload deferred:", type(error).__name__, flush=True)
        print(json.dumps({k: v for k, v in report.items() if k != "stages"}), flush=True)
        return report

    def reconcile_preserved_archives(job):
        path = Path(job["state_dir"]) / "progress.json"
        if not path.exists():
            return
        report = json.loads(path.read_text())
        manifest = json.loads(Path(job["manifest"]).read_text())
        rows = {row["path"]: row for row in manifest["resources"]}
        changed = False
        for index, item in enumerate(report.get("files", [])):
            if item["status"] not in ("failed", "unavailable"):
                continue
            identity = hashlib.sha256(item["url"].encode()).hexdigest()
            try:
                response = cloud.get_object(Bucket=queue["bucket"], Key=queue["prefix"] + "/provenance/" + identity + ".json")
                try:
                    receipt = json.load(response["Body"])
                finally:
                    response["Body"].close()
                if receipt.get("key") != queue["prefix"].rstrip("/") + "/" + item["path"]:
                    continue
                head = cloud.head_object(Bucket=queue["bucket"], Key=receipt["key"])
                if recovery_matches(item, rows.get(item["path"], {}), receipt, head,
                                    queue["bucket"], queue["prefix"]):
                    report["files"][index] = {**receipt, "resolved_via_preserved_object": True,
                                              "reconciled_failure": item}
                    changed = True
            except Exception:
                continue
        if changed:
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%f")
            path.with_name("progress-before-reconciliation-" + stamp + ".json").write_bytes(path.read_bytes())
            items = report["files"]
            for name in ("verified", "failed", "unavailable"):
                report[name] = sum(item["status"] == name for item in items)
            report["verified_bytes"] = sum(item.get("bytes", 0) for item in items if item["status"] == "verified")
            report["updated_at"] = datetime.now(timezone.utc).isoformat()
            report["reconciled_at"] = report["updated_at"]
            body = (json.dumps(report, ensure_ascii=False, indent=2) + "\n").encode()
            tmp = path.with_suffix(".reconciled.tmp")
            tmp.write_bytes(body)
            tmp.replace(path)
            key = queue["prefix"] + "/" + manifest.get("progress_relative_path", "reports/transfer-progress.json")
            cloud.put_object(Bucket=queue["bucket"], Key=key, Body=body, ContentType="application/json")

    for job in jobs:
        process = None
        pid = job.get("running_pid")
        if not pid:
            state = Path(job["state_dir"])
            state.mkdir(exist_ok=True, parents=True)
            command = [sys.executable, str(root / "scripts/cloud_transfer.py"), "--manifest", job["manifest"],
                       "--state-dir", job["state_dir"], "--profile", "tse-research", "--workers", str(job.get("workers", 3))]
            if STOP or (directory / "STOP").exists():
                publish("stopped")
                return 1
            with (state / "transfer.log").open("ab", buffering=0) as output:
                process = subprocess.Popen(command, stdout=output, stderr=subprocess.STDOUT,
                                           stdin=subprocess.DEVNULL, start_new_session=True)
            pid = process.pid
            job["running_pid"] = pid
            queue_path.write_text(json.dumps(queue, indent=2) + "\n")
        while process.poll() is None if process else alive(pid):
            if STOP or (directory / "STOP").exists():
                if alive(pid):
                    os.kill(pid, signal.SIGTERM)
                publish("stopping", job["name"])
                return 1
            publish("running", job["name"])
            for _ in range(30):
                if STOP or (directory / "STOP").exists():
                    break
                time.sleep(1)
        reconcile_preserved_archives(job)
        if read_progress(job)["pending"]:
            publish("interrupted_needs_resume", job["name"])
            return 1
    report = publish("finished")
    if report["failed"] or report["unavailable"]:
        publish("finished_with_gaps")
    return 1 if report["failed"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
