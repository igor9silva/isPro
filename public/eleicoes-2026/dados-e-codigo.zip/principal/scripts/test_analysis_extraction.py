import io
import unittest
import zipfile

from parse_urna_logs import parse_package
from s3_archive import S3RangeReader


class FakeS3:
    def __init__(self, data):
        self.data = data
        self.calls = []
        self.bad_range = False

    def head_object(self, **kwargs):
        return {"ContentLength": len(self.data), "ETag": '"stable"'}

    def get_object(self, **kwargs):
        self.calls.append(kwargs)
        a, b = map(int, kwargs["Range"][6:].split("-"))
        return {"ContentRange": "bad" if self.bad_range else f"bytes {a}-{b}/{len(self.data)}",
                "Body": io.BytesIO(self.data[a:b + 1])}


def package(files):
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", zipfile.ZIP_DEFLATED) as z:
        for name, content in files.items():
            z.writestr(name, content)
    return stream.getvalue()


def line(date, time, message, mac, machine="00002468149"):
    return f"{date} {time}\tINFO\t{machine}\tVOTA\t{message}\t{mac:016x}\n".encode("latin1")


class RangeTests(unittest.TestCase):
    def test_seek_boundaries_and_cache(self):
        data = bytes(range(256)) * 8
        client = FakeS3(data)
        with S3RangeReader(client, "bucket", "key", block_size=64, cache_blocks=2) as r:
            r.seek(60)
            self.assertEqual(r.read(9), data[60:69])
            self.assertEqual(len(client.calls), 2)
            r.seek(61)
            self.assertEqual(r.read(2), data[61:63])
            self.assertEqual(len(client.calls), 2)
            r.seek(-10, 2)
            self.assertEqual(r.read(50), data[-10:])
            self.assertEqual(r.read(1), b"")
            self.assertTrue(all(c["IfMatch"] == '"stable"' for c in client.calls))

    def test_identity_and_range_failure(self):
        client = FakeS3(b"123456789")
        with self.assertRaises(ValueError):
            S3RangeReader(client, "b", "k", expected_size=10)
        with self.assertRaises(ValueError):
            S3RangeReader(client, "b", "k", expected_etag='"different"')
        client.bad_range = True
        with self.assertRaises(ValueError):
            S3RangeReader(client, "b", "k").read(1)

    def test_zip_members_and_unbounded_read_guard(self):
        payload = package({"a": b"small text", "b": bytes(range(256)) * 20})
        with S3RangeReader(FakeS3(payload), "b", "k", block_size=64) as reader:
            with zipfile.ZipFile(reader) as z:
                self.assertEqual(z.read("a"), b"small text")
                self.assertEqual(z.read("b"), bytes(range(256)) * 20)
        with self.assertRaises(ValueError):
            S3RangeReader(FakeS3(payload), "b", "k", max_single_read=5).read()


class LogTests(unittest.TestCase):
    member = "o03221ac0100700090001-log.jez"

    def test_round_filter_and_no_office_double_count(self):
        raw = line("04/10/2026", "16:00:00", "O voto do eleitor foi computado", 1)
        raw += line("25/10/2026", "15:00:01", "Voto confirmado para [Presidente]", 2)
        raw += line("25/10/2026", "15:00:02", "O voto do eleitor foi computado", 3)
        rows, stats = parse_package(package({"logd.dat": raw}), self.member, ["25/10/2026"])
        self.assertEqual(rows[0]["computed_count"], 1)
        self.assertEqual(rows[0]["computed_seconds"], [54002])
        self.assertEqual(stats["raw_computed_date:04/10/2026"], 1)
        self.assertEqual(rows[0]["municipality"], 1007)

    def test_nested_overlap_equal_second_distinct_mac_and_clock_backwards(self):
        a = line("25/10/2026", "15:00:01", "O voto do eleitor foi computado", 1)
        b = line("25/10/2026", "15:00:01", "O voto do eleitor foi computado", 2)
        c = line("25/10/2026", "14:59:55", "Procedimento de encerramento confirmado", 3)
        raw = package({"logd.dat": a + b + c, "logs/older.jez": package({"logd.dat": a})})
        rows, stats = parse_package(raw, self.member, ["25/10/2026"])
        row = rows[0]
        self.assertEqual(row["raw_computed_count"], 3)
        self.assertEqual(row["computed_count"], 2)
        self.assertEqual(row["duplicate_computed_count"], 1)
        self.assertEqual(row["clock_backwards_count"], 1)
        self.assertEqual(row["largest_backward_seconds"], 6)
        self.assertEqual(stats["nested_archives"], 1)

    def test_suspension_absence_and_invalid_clock(self):
        raw = line("25/10/2026", "15:01:02", "Eleitor foi suspenso e não confirmou nenhum voto", 1)
        raw += line("25/10/2026", "25:01:02", "O voto do eleitor foi computado", 2)
        rows, stats = parse_package(package({"logd.dat": raw}), self.member, ["25/10/2026", "26/10/2026"])
        self.assertEqual(rows[0]["computed_count"], 0)
        self.assertEqual(rows[0]["suspended_without_vote_seconds"], [54062])
        self.assertEqual(rows[1]["line_count"], 0)
        self.assertEqual(stats["invalid_clock_lines"], 1)

    def test_reject_nonzip_and_unknown_section_name(self):
        with self.assertRaises(ValueError):
            parse_package(b"invalid", self.member, ["25/10/2026"])
        with self.assertRaises(ValueError):
            parse_package(package({"logd.dat": b""}), "not-official.jez", ["25/10/2026"])


if __name__ == "__main__":
    unittest.main()
