import hashlib
import io
import unittest

import py7zr
from parse_urna_logs_legacy import parse_package
from test_analysis_extraction import line


def seven(files):
    stream = io.BytesIO()
    with py7zr.SevenZipFile(stream, "w") as z:
        for name, data in files.items():
            z.writestr(data, name)
    return stream.getvalue()


class LegacyTests(unittest.TestCase):
    def test_7z_original_identity_and_nested_overlap(self):
        record = line("30/10/2022", "15:01:00", "O voto do eleitor foi computado", 8)
        payload = seven({"logd.dat": record, "archived.jez": seven({"logd.dat": record})})
        name = "o00407-0101500020088.logjez"
        rows, stats = parse_package(payload, name, ["30/10/2022"], "AC")
        self.assertEqual(rows[0]["computed_count"], 1)
        self.assertEqual(rows[0]["duplicate_computed_count"], 1)
        self.assertEqual(rows[0]["source_member"], name)
        self.assertEqual(rows[0]["package_sha256"], hashlib.sha256(payload).hexdigest())
        self.assertEqual(rows[0]["uf"], "AC")
        self.assertEqual(rows[0]["municipality"], 1015)
        self.assertEqual(rows[0]["zone"], 2)
        self.assertEqual(rows[0]["section"], 88)
        self.assertEqual(stats["seven_zip_containers_decoded"], 2)


if __name__ == "__main__":
    unittest.main()
