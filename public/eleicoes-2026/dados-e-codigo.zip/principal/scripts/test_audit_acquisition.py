import copy
import unittest

from audit_acquisition import MISSING_SHA1, receipt_issues


class ReceiptAuditTest(unittest.TestCase):
    def setUp(self):
        self.row = {"path": "raw/2026/example.zip", "url": "https://cdn.tse.jus.br/example.zip",
                    "bytes_remote": 5}
        self.receipt = {"path": self.row["path"], "url": self.row["url"], "bucket": "tse-research",
                        "key": "tse/2026-10-29/" + self.row["path"], "status": "verified", "bytes": 5,
                        "etag": '"opaque-2"', "hashes": {"md5": "a" * 32, "sha1": "b" * 40,
                        "sha256": "c" * 64, "sha512": "d" * 128}, "official_checksums": [],
                        "official_checksums_unavailable": [],
                        "verification_method": "source_hashes_and_server_validated_content_md5_per_part"}
        self.head = {"ContentLength": 5, "ETag": '"opaque-2"'}

    def check(self, remote=None):
        return receipt_issues(self.row, self.receipt, remote or copy.deepcopy(self.receipt), self.head,
                              "tse-research", "tse/2026-10-29")

    def test_valid_receipt_accepts_opaque_multipart_etag(self):
        self.assertEqual(self.check(), [])

    def test_wrong_remote_identity_is_rejected(self):
        remote = copy.deepcopy(self.receipt)
        remote["url"] = "https://cdn.tse.jus.br/different.zip"
        self.assertIn("identity:url", self.check(remote))

    def test_stored_size_and_object_version_are_checked(self):
        self.head.update(ContentLength=6, ETag='"other"')
        self.assertIn("stored_size", self.check())
        self.assertIn("stored_etag", self.check())

    def test_digest_change_and_invalid_digest_are_rejected(self):
        remote = copy.deepcopy(self.receipt)
        remote["hashes"]["sha256"] = "not-a-sha256"
        self.assertIn("local_remote_receipt:hashes", self.check(remote))
        self.assertIn("digest_format:sha256", self.check(remote))

    def test_official_comparison_requires_matching_digest_and_flag(self):
        self.receipt["official_checksums"] = [{"algorithm": "sha512", "digest": "d" * 128,
                                               "matched": True}]
        self.assertEqual(self.check(), [])
        self.receipt["official_checksums"][0]["digest"] = "e" * 128
        self.assertIn("official_digest_record", self.check())
        self.receipt["official_checksums"][0].update(digest="d" * 128, matched=False)
        self.assertIn("official_digest_record", self.check())

    def test_approved_revision_is_required_to_match(self):
        self.row["source_revision_refresh"] = {"observed_headers": {"etag": '"approved"',
                                                                   "last-modified": "today"}}
        self.receipt["source"] = {"headers": {"etag": '"different"', "last-modified": "today"}}
        self.assertIn("approved_source_revision:etag", self.check())

    def test_only_documented_missing_checksum_is_accepted(self):
        self.receipt["official_checksums_unavailable"] = [{"source_url": MISSING_SHA1, "http_status": 404}]
        self.assertEqual(self.check(), [])
        self.receipt["official_checksums_unavailable"][0]["http_status"] = 403
        self.assertIn("unexpected_unavailable_checksum", self.check())


if __name__ == "__main__":
    unittest.main()
