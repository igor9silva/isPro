"""Failure-path tests for integrity, resume, range handling, and the storage cap."""
import base64
import hashlib
import io
import json
import tempfile
import unittest
from unittest.mock import patch

from botocore.exceptions import ClientError
import cloud_transfer as transfer
import requests


def error(code):
    return ClientError({"Error": {"Code": code}}, "test")


class Pages:
    def __init__(self, callback):
        self.callback = callback

    def paginate(self, **kwargs):
        yield self.callback(**kwargs)


class MemoryS3:
    def __init__(self):
        self.objects, self.uploads, self.upload_calls = {}, {}, []

    def head_object(self, Key, **kwargs):
        if Key not in self.objects:
            raise error("NoSuchKey")
        body = self.objects[Key]
        return {"ContentLength": len(body), "ETag": hashlib.md5(body).hexdigest()}

    def get_object(self, Key, **kwargs):
        if Key not in self.objects:
            raise error("NoSuchKey")
        return {"Body": io.BytesIO(self.objects[Key])}

    def put_object(self, Key, Body, ContentMD5, **kwargs):
        assert base64.b64encode(hashlib.md5(Body).digest()).decode() == ContentMD5
        if kwargs.get("IfNoneMatch") == "*" and Key in self.objects:
            raise error("PreconditionFailed")
        self.objects[Key] = Body
        return {}

    def create_multipart_upload(self, **kwargs):
        upload_id = str(len(self.uploads) + 1)
        self.uploads[upload_id] = {}
        return {"UploadId": upload_id}

    def upload_part(self, UploadId, PartNumber, Body, ContentMD5, **kwargs):
        assert base64.b64encode(hashlib.md5(Body).digest()).decode() == ContentMD5
        self.upload_calls.append(PartNumber)
        self.uploads[UploadId][PartNumber] = Body
        return {"ETag": hashlib.md5(Body).hexdigest()}

    def complete_multipart_upload(self, Key, UploadId, MultipartUpload, **kwargs):
        self.objects[Key] = b"".join(self.uploads[UploadId][p["PartNumber"]] for p in MultipartUpload["Parts"])
        del self.uploads[UploadId]

    def get_paginator(self, name):
        if name == "list_objects_v2":
            return Pages(lambda **kw: {"Contents": [{"Key": k, "Size": len(v)} for k, v in self.objects.items()]})
        def parts(UploadId, **kw):
            if UploadId not in self.uploads:
                raise error("NoSuchUpload")
            return {"Parts": [{"PartNumber": n, "ETag": hashlib.md5(v).hexdigest()} for n, v in self.uploads[UploadId].items()]}
        return Pages(parts)


class FakeSource:
    body = b"PK0123456789abcdefghijklmnop"
    fail_at = None

    def __init__(self, url):
        self.url = url
        self.identity = {"etag": "fixed-validator"}

    def inspect(self):
        return {"size": len(self.body)}

    def read(self, offset, count):
        if self.fail_at is not None and offset >= self.fail_at:
            raise IOError("injected interruption")
        return self.body[offset:offset + count]

    def close(self):
        pass


class TransferTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.s3 = MemoryS3()
        self.row = {"url": "https://cdn.tse.jus.br/test.zip", "path": "raw/2026/test.zip",
                    "bytes_remote": len(FakeSource.body)}
        self.manifest = {"bucket": "test", "prefix": "collection", "storage_limit_bytes": 10**12,
                         "resources": [self.row]}
        self.runner = transfer.Transfer(self.s3, self.manifest, self.temp.name, 1)
        FakeSource.fail_at = None
        transfer.STOP.clear()

    @patch.object(transfer, "PART_BYTES", 8)
    @patch.object(transfer, "Source", FakeSource)
    def test_resume_reuses_uploaded_parts_and_verifies_full_hash(self):
        FakeSource.fail_at = 8
        interrupted = self.runner.copy(self.row)
        self.assertEqual(interrupted["status"], "failed")
        self.assertEqual(self.s3.upload_calls, [1])
        self.assertNotIn(self.runner.key(self.row), self.s3.objects)
        FakeSource.fail_at = None
        result = self.runner.copy(self.row)
        self.assertEqual(result["status"], "verified")
        self.assertEqual(self.s3.upload_calls, [1, 2, 3, 4])
        self.assertEqual(self.s3.objects[self.runner.key(self.row)], FakeSource.body)
        self.assertEqual(result["hashes"]["sha512"], hashlib.sha512(FakeSource.body).hexdigest())

    @patch.object(transfer, "PART_BYTES", 8)
    @patch.object(transfer, "Source", FakeSource)
    def test_resume_rejects_changed_source_prefix(self):
        FakeSource.fail_at = 8
        self.runner.copy(self.row)
        FakeSource.fail_at = None
        with patch.object(FakeSource, "body", b"PKchanged" + FakeSource.body[9:]):
            result = self.runner.copy(self.row)
        self.assertEqual(result["status"], "failed")
        self.assertIn("differs", result["error"])
        self.assertNotIn(self.runner.key(self.row), self.s3.objects)

    @patch.object(transfer, "PART_BYTES", 64)
    @patch.object(transfer, "Source", FakeSource)
    def test_checksum_failure_does_not_publish_object(self):
        self.row["local_hashes"] = {"sha512": "0" * 128}
        result = self.runner.copy(self.row)
        self.assertEqual(result["status"], "failed")
        self.assertNotIn(self.runner.key(self.row), self.s3.objects)

    def test_budget_rejects_before_any_write(self):
        self.runner.reservations[self.runner.key(self.row)] = 995_000_000_000
        with self.assertRaisesRegex(ValueError, "ceiling"):
            self.runner.preflight()
        self.assertEqual(self.s3.objects, {})

    def test_existing_corruption_is_detected_without_overwrite(self):
        self.row["local_hashes"] = {"sha256": hashlib.sha256(b"expected").hexdigest()}
        key = self.runner.key(self.row)
        self.s3.objects[key] = b"corrupt"
        result = self.runner.copy(self.row)
        self.assertEqual(result["status"], "failed")
        self.assertEqual(self.s3.objects[key], b"corrupt")

    @patch.object(transfer, "PART_BYTES", 64)
    def test_missing_official_checksum_does_not_discard_available_archive(self):
        class WithMissingHash(FakeSource):
            def read_small(self):
                response = requests.Response()
                response.status_code = 404
                raise requests.HTTPError(response=response)
        companion = {"url": self.row["url"] + ".sha512", "path": self.row["path"] + ".sha512"}
        self.runner.by_url[companion["url"]] = companion
        with patch.object(transfer, "Source", WithMissingHash):
            result = self.runner.copy(self.row)
        self.assertEqual(result["status"], "verified")
        self.assertEqual(result["official_checksums"], [])
        self.assertEqual(result["official_checksums_unavailable"][0]["http_status"], 404)
        self.assertEqual(self.s3.objects[self.runner.key(self.row)], FakeSource.body)

    def test_checksum_requires_matching_filename(self):
        digest = "a" * 128
        with self.assertRaises(ValueError):
            transfer.checksum_from_text(digest + "  other.zip", "sha512", "test.zip")
        self.assertEqual(transfer.checksum_from_text(digest + "  test.zip", "sha512", "test.zip"), digest)

    def test_resume_rejects_ignored_range(self):
        source = transfer.Source("https://cdn.tse.jus.br/test.zip")
        self.addCleanup(source.close)
        source.identity, source.size = {}, 10
        class Response:
            status_code, headers, url = 200, {}, source.url
            def raise_for_status(self): pass
            def close(self): pass
        with patch.object(source.http, "get", return_value=Response()):
            with self.assertRaisesRegex(ValueError, "byte range"):
                source.connect(5)

    @patch.object(transfer, "SOURCE_CONNECTION_BYTES", 8)
    def test_source_rotation_preserves_offset_and_validator(self):
        source = transfer.Source("https://cdn.tse.jus.br/test.zip")
        self.addCleanup(source.close)
        source.identity, source.size = {"etag": '"stable"'}, 16

        class Response:
            url = source.url

            def __init__(self, body, status, headers):
                self.body = io.BytesIO(body)
                self.raw = self
                self.status_code, self.headers = status, headers
                self.closed = False

            def read(self, count, **kwargs): return self.body.read(count)
            def raise_for_status(self): pass
            def close(self): self.closed = True

        first = Response(b"abcdefgh", 200, {"etag": '"stable"'})
        second = Response(b"ijklmnop", 206, {"etag": '"stable"', "Content-Range": "bytes 8-15/16"})
        with patch.object(source.http, "get", side_effect=[first, second]) as get:
            data = source.read(0, 4) + source.read(4, 4) + source.read(8, 8)
        self.assertEqual(data, b"abcdefghijklmnop")
        self.assertTrue(first.closed)
        self.assertEqual(get.call_count, 2)
        self.assertEqual(get.call_args_list[1].kwargs["headers"],
                         {"Range": "bytes=8-", "If-Match": '"stable"'})

    @patch.object(transfer, "SOURCE_CONNECTION_BYTES", 8)
    def test_source_rotation_rejects_changed_validator(self):
        source = transfer.Source("https://cdn.tse.jus.br/test.zip")
        self.addCleanup(source.close)
        source.identity, source.size = {"etag": '"original"'}, 16
        source.connection_bytes = 8

        class Response:
            status_code, url = 206, source.url
            headers = {"Content-Range": "bytes 8-15/16", "etag": '"changed"'}
            def raise_for_status(self): pass
            def close(self): pass

        source.response = Response()
        with patch.object(source.http, "get", return_value=Response()):
            with self.assertRaisesRegex(ValueError, "validator changed"):
                source.read(8, 8)


if __name__ == "__main__":
    unittest.main()
