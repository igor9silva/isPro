import unittest
from scipy.stats import hypergeom
from context_sampling_bounds import hypergeom_upper
class BoundsTests(unittest.TestCase):
 def test_census_and_no_sample(self):
  for N in [1,10,1000]:
   self.assertEqual(hypergeom_upper(N,0,0),N)
   for e in [0,1,N]:self.assertEqual(hypergeom_upper(N,N,e),e)
 def test_nonrejection_boundary(self):
  N,n,e,alpha=10000,500,0,.05/21
  u=hypergeom_upper(N,n,e,alpha)
  self.assertGreaterEqual(hypergeom.cdf(e,N,u,n),alpha)
  self.assertLess(hypergeom.cdf(e,N,u+1,n),alpha)
 def test_exact_small_population_coverage(self):
  alpha=.1
  for N in range(1,13):
   for n in range(1,N+1):
    bounds=[hypergeom_upper(N,n,e,alpha) for e in range(n+1)]
    for K in range(N+1):
     miss=sum(hypergeom.pmf(e,N,K,n) for e,u in enumerate(bounds) if u<K)
     self.assertLessEqual(miss,alpha+1e-12)
if __name__=='__main__':unittest.main()
