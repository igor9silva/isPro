import unittest
import pandas as pd
from correct_canonical_dates import parse_dates, fix_frame


class DateParsingTests(unittest.TestCase):
    def test_iso_ambiguous_day_is_not_swapped(self):
        x = parse_dates(pd.Series(['2024-10-06 00:00:00', '2024-10-07 00:02:16']))
        self.assertEqual((x[1] - x[0]).total_seconds(), 86536)

    def test_brazilian_day_first_and_iso_match(self):
        x = parse_dates(pd.Series(['06/10/2024 07:12:45', '2024-10-06 07:12:45']))
        self.assertEqual(x[0], x[1])

    def test_month_boundary_and_missing(self):
        x = parse_dates(pd.Series(['2026-10-31 23:59:59', '2026-11-01 00:00:01', None, '', '#NULO#']))
        self.assertEqual((x[1] - x[0]).total_seconds(), 2)
        self.assertTrue(pd.isna(x[2]) and pd.isna(x[3]) and pd.isna(x[4]))

    def test_unknown_format_is_rejected(self):
        with self.assertRaises(ValueError):
            parse_dates(pd.Series(['10-06-2024']))

    def test_fix_preserves_votes_and_corrects_only_derived_times(self):
        f = pd.DataFrame([{'election_date': '2024-10-06 00:00:00', 'opened': '2024-10-06 08:00:00',
            'closed': '2024-10-07 00:02:16', 'emitted': '2024-10-07 00:03:00',
            'opened_elapsed_seconds': 28800., 'closed_elapsed_seconds': 2592136., 'emitted_elapsed_seconds': 2592180.,
            'ordinary_deadline_local_seconds': 61200, 'close_seconds_after_ordinary_deadline': 2530936.,
            'open_seconds_after_ordinary_start': 0., 'usable_timing': False, 'usable_turnout': True,
            'uf': 'PI', 'attendance': 299, 'total_votes': 299}])
        c = fix_frame(f)
        self.assertEqual(c.closed_elapsed_seconds.iloc[0], 86536)
        self.assertTrue(c.usable_timing.iloc[0])
        self.assertEqual(c.attendance.iloc[0], 299)


if __name__ == '__main__':
    unittest.main()
