import io
import unittest
import zipfile
from audit_log_context import audit, context_class


def line(message, n, hour='08:00:00'):
    return f'02/10/2022 {hour}\tINFO\t67305985\tVOTA\t{message}\t{n:016X}\n'.encode('latin1')


class ContextTests(unittest.TestCase):
    def test_foreign_section_is_not_selected_by_total(self):
        root=io.BytesIO()
        with zipfile.ZipFile(root,'w') as z:
            for sec,n in [(524,1),(529,10)]:
                b=b''.join([line('Município: 71072',n),line('Zona Eleitoral: 0389',n+1),
                    line(f'Seção Eleitoral: {sec}',n+2),line('O voto do eleitor foi computado',n+3)])
                z.writestr(f'{sec}.dat',b)
        r=audit(root.getvalue(),'package','02/10/2022',{'municipality':71072,'zone':389,'section':529},1)
        self.assertEqual(len(r['completion_seconds']['target']),1)
        self.assertEqual(len(r['completion_seconds']['foreign']),1)
        self.assertEqual(r['unique_completions_all_contexts'],2)

    def test_unknown_and_nonofficial_or_wrong_turn(self):
        target={'municipality':1,'zone':2,'section':3}
        self.assertEqual(context_class({},target,1),'unknown')
        self.assertEqual(context_class({**target,'section':0},target,1),'unknown')
        self.assertEqual(context_class({**target,'turn':2},target,1),'foreign')
        self.assertEqual(context_class({**target,'phase':'Simulado'},target,1),'foreign')
        self.assertEqual(context_class({**target,'phase':'Oficial'},target,1),'target')

    def test_log_boot_resets_context(self):
        b=b''.join([line('Município: 1',1),line('Zona Eleitoral: 2',2),line('Seção Eleitoral: 3',3),
            line('O voto do eleitor foi computado',4),line('Início das operações do logd',5),
            line('O voto do eleitor foi computado',6)])
        root=io.BytesIO()
        with zipfile.ZipFile(root,'w') as z:z.writestr('logd.dat',b)
        r=audit(root.getvalue(),'package','02/10/2022',{'municipality':1,'zone':2,'section':3},1)
        self.assertEqual(len(r['completion_seconds']['target']),1)
        self.assertEqual(len(r['completion_seconds']['unknown']),1)


if __name__=='__main__':unittest.main()
