import itertools
import unittest
from margin_bounds import removal_margin_bounds


class SharpBoundsTests(unittest.TestCase):
    def test_small_populations_against_all_feasible_allocations(self):
        for a,b,o in itertools.product(range(5),repeat=3):
            for cap in range(a+b+o+1):
                for exact in [False,True]:
                    feasible=[y-x for x in range(a+1) for y in range(b+1) for z in range(o+1)
                              if (x+y+z==cap if exact else x+y+z<=cap)]
                    result=removal_margin_bounds(a,b,o,cap,exact)
                    self.assertEqual((result['minimum_margin_change'],result['maximum_margin_change']),
                                     (min(feasible),max(feasible)),(a,b,o,cap,exact))

    def test_one_added_voter_changes_margin_by_one_not_two(self):
        result=removal_margin_bounds(60,40,0,1)
        self.assertEqual((result['minimum_counterfactual_margin'],result['maximum_counterfactual_margin']),(19,21))

    def test_invalid_counts_rejected(self):
        for values in [(-1,1,0,0),(1,1,0,3),(1.5,1,0,1)]:
            with self.assertRaises(ValueError):removal_margin_bounds(*values)


if __name__=='__main__':unittest.main()
