import unittest
from unittest.mock import patch
from recover_native_members import validate_checkpoint, validate_rows


class RecoveryTests(unittest.TestCase):
    def test_rejects_running_archive_and_changed_source(self):
        cp={'status':'running','next_member_index':1,'member_count':2,'failed_members':[{'member':'x'}],
            'source_sha256':'a','source_etag':'b','code':{'parser.py':'c'}}
        row={'hashes':{'sha256':'a'},'etag':'b'}
        with self.assertRaises(ValueError):validate_checkpoint(cp,row)
        cp.update(status='complete_with_member_errors',next_member_index=2)
        with patch('recover_native_members.code_fingerprint',return_value={'parser.py':'c'}):
            validate_checkpoint(cp,row)
            with self.assertRaises(ValueError):validate_checkpoint(cp,{'hashes':{'sha256':'changed'},'etag':'b'})

    def test_rejects_changed_parser(self):
        cp={'status':'complete_with_member_errors','next_member_index':2,'member_count':2,'failed_members':[{'member':'x'}],
            'source_sha256':'a','source_etag':'b','code':{'parser.py':'c'}}
        with patch('recover_native_members.code_fingerprint',return_value={'parser.py':'different'}):
            with self.assertRaises(ValueError):validate_checkpoint(cp,{'hashes':{'sha256':'a'},'etag':'b'})

    def test_complete_unique_date_and_member_contract(self):
        rows=[{'source_member':'x','event_date':'a'},{'source_member':'x','event_date':'b'}]
        validate_rows(rows,'x',['a','b'])
        for bad in [rows[:1],rows+rows[:1],[rows[0],rows[0]]]:
            with self.assertRaises(ValueError):validate_rows(bad,'x',['a','b'])
        with self.assertRaises(ValueError):validate_rows(rows,'y',['a','b'])


if __name__=='__main__':unittest.main()
