import unittest
from review_temporal_features import reviewed_context


class ReviewedContextTests(unittest.TestCase):
    def fixture(self):
        return {'package_sha256': 'identity', 'unique_completions_all_contexts': 4,
                'completion_seconds': {'target': [61200, 61200, 61201], 'foreign': [63000],
                                       'unknown': [], 'conflicting': []}}

    def test_explicit_foreign_removed_without_collapsing_same_second(self):
        times, counts, resolved = reviewed_context(self.fixture(), 4, 'identity')
        self.assertEqual(times, [61200, 61200, 61201])
        self.assertEqual(counts['foreign'], 1)
        self.assertTrue(resolved)

    def test_unknown_kept_unresolved_not_forced_to_match(self):
        r = self.fixture();r['completion_seconds']['unknown'] = r['completion_seconds'].pop('foreign')
        r['completion_seconds']['foreign'] = []
        times, counts, resolved = reviewed_context(r, 4, 'identity')
        self.assertFalse(resolved);self.assertEqual(counts['unknown'], 1);self.assertEqual(len(times), 3)

    def test_wrong_source_and_population_rejected(self):
        for count, sha in [(4, 'different'), (3, 'identity')]:
            with self.assertRaises(ValueError): reviewed_context(self.fixture(), count, sha)


if __name__ == '__main__': unittest.main()
