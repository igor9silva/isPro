"""Reconciliation must never convert an unrelated or unverified object to success."""
import copy
import unittest

from supervise_transfer import recovery_matches


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.item = {"status": "failed", "path": "raw/2024/example.zip",
                     "url": "https://cdn.tse.jus.br/example.zip",
                     "error": "ValueError: Official source length changed since cataloguing"}
        self.headers = {"etag": '"official-current"', "last-modified": "current-date"}
        self.row = {"path": self.item["path"], "url": self.item["url"], "bytes_remote": 17,
                    "source_revision_refresh": {"previous_bytes_remote": 16, "observed_headers": self.headers}}
        self.receipt = {"status": "verified", "bucket": "archive", "key": "prefix/" + self.item["path"],
                        "path": self.item["path"], "url": self.item["url"], "bytes": 17,
                        "etag": '"stored-object"', "hashes": {"sha256": "a" * 64, "sha512": "b" * 128},
                        "source": {"headers": self.headers}}
        self.head = {"ETag": '"stored-object"', "ContentLength": 17}

    def check(self, item=None, row=None, receipt=None, head=None):
        return recovery_matches(item or self.item, row or self.row, receipt or self.receipt,
                                head or self.head, "archive", "prefix")

    def test_approved_revision_reconciles(self):
        self.assertTrue(self.check())

    def test_changed_source_requires_explicit_catalog_revision(self):
        row = copy.deepcopy(self.row)
        del row["source_revision_refresh"]
        self.assertFalse(self.check(row=row))

    def test_rejects_wrong_object_identity_size_or_digest(self):
        for field, value in [("path", "raw/other.zip"), ("url", "https://cdn.tse.jus.br/other.zip"),
                             ("key", "elsewhere/example.zip"), ("bucket", "other"), ("bytes", 16),
                             ("etag", '"different"'), ("status", "failed"), ("hashes", {})]:
            with self.subTest(field=field):
                receipt = copy.deepcopy(self.receipt)
                receipt[field] = value
                self.assertFalse(self.check(receipt=receipt))

    def test_rejects_different_official_revision_even_when_size_matches(self):
        for field in ("etag", "last-modified"):
            receipt = copy.deepcopy(self.receipt)
            receipt["source"]["headers"][field] = "changed-again"
            self.assertFalse(self.check(receipt=receipt))

    def test_missing_checksum_recovery_remains_supported(self):
        item = {**self.item, "status": "unavailable", "error": "HTTP 404 for example.zip.sha1"}
        row = {k: v for k, v in self.row.items() if k != "source_revision_refresh"}
        receipt = {**self.receipt, "official_checksums_unavailable": [{"algorithm": "sha1", "http_status": 404}]}
        self.assertTrue(self.check(item=item, row=row, receipt=receipt))
        self.assertFalse(self.check(item=item, row=row))

    def test_unrelated_failure_cannot_be_relabelled(self):
        self.assertFalse(self.check(item={**self.item, "error": "ValueError: sha512 checksum mismatch"}))


if __name__ == "__main__":
    unittest.main()
