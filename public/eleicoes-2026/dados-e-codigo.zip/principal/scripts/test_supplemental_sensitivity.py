import unittest
from types import SimpleNamespace
from analyze_supplemental_sensitivity import decision


class WholeSequenceSensitivity(unittest.TestCase):
    def setUp(self):
        self.case = dict(year=2022, municipality=123, zone=4, section=5,
                         unknown_completions=0, conflicting_completions=0,
                         secondary_clock_reversals=0, secondary_parse_flags=0)
        self.context = dict(date='02/10/2022', turn=1,
                            target=dict(municipality=123, zone=4, section=5),
                            completion_seconds={'target': [40000, 40000, 40100]})

    def test_missing_primary_accepts_without_imputing_its_timestamp(self):
        p = SimpleNamespace(log_present=False, reviewed_observed_completions=float('nan'))
        self.assertEqual(decision(p, self.case, self.context), 'accepted_whole_target_sequence')
        self.assertEqual(len(self.context['completion_seconds']['target']), 3)

    def test_positive_partial_primary_is_not_merged(self):
        p = SimpleNamespace(log_present=True, reviewed_observed_completions=1)
        self.assertEqual(decision(p, self.case, self.context), 'positive_primary_not_merged')

    def test_present_unknown_primary_is_not_treated_as_zero(self):
        p = SimpleNamespace(log_present=True, reviewed_observed_completions=float('nan'))
        self.assertEqual(decision(p, self.case, self.context), 'unresolved_primary_count')

    def test_clock_and_identity_exceptions_remain_explicit(self):
        p = SimpleNamespace(log_present=True, reviewed_observed_completions=0)
        self.assertEqual(decision(p, self.case | {'secondary_clock_reversals': 1}, self.context), 'clock_or_parse_exception')
        with self.assertRaises(ValueError):
            decision(p, self.case, self.context | {'target': dict(municipality=123, zone=4, section=6)})


if __name__ == '__main__':
    unittest.main()
