import unittest
import pandas as pd
from derive_temporal_features import threshold_counts
from review_section_tables import is_zero_vote_placeholder


class TemporalMeasurementTests(unittest.TestCase):
    def test_boundary_conventions_and_acre_clock(self):
        # Same real instants in Brasilia and Acre: exactly17h is separate.
        a=threshold_counts([61199,61200,61201,64800,64801,68401],61200)
        b=threshold_counts([53999,54000,54001,57600,57601,61201],54000)
        for key in ['after_ordinary_p0','after_ordinary_p3600','after_ordinary_p7200','at_ordinary_deadline']:
            self.assertEqual(a[key],b[key])
        self.assertEqual((a['after_ordinary_p0'],a['at_ordinary_deadline']), (4,1))
        self.assertEqual(a['after_ordinary_p3600'],2)

    def test_next_day_and_unknown_zone_are_not_midnight_zero(self):
        self.assertEqual(threshold_counts([86400+30],61200)['after_ordinary_p7200'],1)
        unknown=threshold_counts([61210],None)
        self.assertEqual(unknown['observed_completions'],1)
        self.assertIsNone(unknown['after_ordinary_p0'])

    def test_placeholder_is_not_a_repeated_candidate(self):
        table=pd.DataFrame([
            {'candidate_rows':1,'distinct_votables':0,'total_votes':0,'attendance':0,'invalid_vote_rows':1},
            {'candidate_rows':2,'distinct_votables':1,'total_votes':10,'attendance':10,'invalid_vote_rows':0},
            {'candidate_rows':1,'distinct_votables':0,'total_votes':1,'attendance':1,'invalid_vote_rows':1}])
        self.assertEqual(is_zero_vote_placeholder(table).tolist(),[True,False,False])


if __name__=='__main__': unittest.main()
