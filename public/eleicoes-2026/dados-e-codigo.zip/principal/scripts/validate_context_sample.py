"""Additional2026context validation: governor-state census and probability sample elsewhere.

Immutable sampling frame and seed precede internal-context inspection. No voter
identifiers or candidate-time links are retained. Original measurements stay intact.
"""
import argparse,hashlib,json,random,time
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from analysis_common import ROOT,archive,atomic_json,code_fingerprint,digest,inputs,now,require_disk
from audit_log_context import audit
from extract_native_logs import DATES

OUT=ROOT/'analysis/source-audit/context-validation-v2'
SEED=20261031
CENSUS_UFS={'AC','AM','DF','ES','RN','TO'}
CODE=['validate_context_sample.py','audit_log_context.py','parse_urna_logs.py','parse_urna_logs_legacy.py','analysis_common.py','s3_archive.py']

def prepare():
 if (OUT/'plan.json').exists():return json.loads((OUT/'plan.json').read_text())
 OUT.mkdir(parents=True,exist_ok=True)
 strata=[]
 for mp in sorted((ROOT/'analysis/derived/temporal-reviewed-v1/2026').glob('*/complete.json')):
  m=json.loads(mp.read_text());uf=m['uf'];turn=m['round'];p=mp.parent/'sections.parquet'
  if digest(p)!=next(x['sha256'] for x in m['outputs'] if x['path'].endswith('sections.parquet')):raise ValueError('Reviewed input changed')
  f=pd.read_parquet(p);remaining=f[f.log_present & ~f.context_audited].copy().sort_values('source_member')
  census=turn==2 and uf in CENSUS_UFS;n=len(remaining) if census else min(500,len(remaining))
  seed=int.from_bytes(hashlib.sha256(f'{SEED}:{turn}:{uf}'.encode()).digest(),'big')
  positions=sorted(random.Random(seed).sample(range(len(remaining)),n))
  chosen=remaining.iloc[positions][['municipality','zone','section','source_member','source_package_sha256','attendance','reviewed_observed_completions']].copy()
  folder=OUT/f'2026-{turn}t-{uf}';folder.mkdir(exist_ok=True)
  frame=folder/'selection.parquet';chosen.to_parquet(frame,index=False,compression='zstd')
  stratum={'year':2026,'round':turn,'uf':uf,'population':len(remaining),'sample_size':n,'is_census':census or n==len(remaining),
           'design':'simple_random_without_replacement' if n<len(remaining) else 'census_of_unaudited_complement',
           'seed':str(seed),'selection_path':str(frame.relative_to(ROOT)),'selection_sha256':digest(frame),
           'reviewed_manifest':str(mp.relative_to(ROOT)),'reviewed_manifest_sha256':digest(mp),
           'prior_context_audited_sections':int(f.context_audited.sum()),'all_log_sections':int(f.log_present.sum()),
           'source':f'raw/2026/arquivos_urna/bu_imgbu_logjez_rdv_vscmr_2026_{turn}t_{uf}.zip'}
  strata.append(stratum)
 plan={'created_at':now(),'status':'frame_fixed_before_inspection','base_seed':SEED,'code':code_fingerprint(CODE),'strata':strata,
       'purpose':'Validate internal municipality/zone/section agreement outside the earlier exception census and deterministic checks. This is an exploratory measurement audit, not a public preregistration.',
       'inference_protocol':'Finite-population hypergeometric upper bounds for observed context failures per probability stratum; Bonferroni simultaneous95percent coverage across sampled second-turn strata if applied to margin sensitivity. Census strata have no sampling interval.',
       'rule':'Any detected error is retained and reviewed; never silently fit event counts to BWeb. Output does not automatically overwrite primary measures.'}
 atomic_json(OUT/'plan.json',plan);return plan


def work(s):
 folder=OUT/f"2026-{s['round']}t-{s['uf']}";mp=folder/'complete.json'
 if mp.exists():return json.loads(mp.read_text())
 frame=ROOT/s['selection_path']
 if digest(frame)!=s['selection_sha256']:raise ValueError('Sampling frame changed')
 chosen=pd.read_parquet(frame)
 cp_path=folder/'checkpoint.json';code=code_fingerprint(CODE)
 cp=json.loads(cp_path.read_text()) if cp_path.exists() else {'started_at':now(),'selection_sha256':s['selection_sha256'],'code':code,'next_index':0,'batches':[],'failures':[]}
 if cp['code']!=code or cp['selection_sha256']!=s['selection_sha256']:raise ValueError('Checkpoint code/frame changed')
 for b in cp['batches']:
  if digest(ROOT/b['path'])!=b['sha256']:raise ValueError('Validation batch changed')
 source=next(r for r in inputs() if r['path']==s['source'])
 buffer=[];start=cp['next_index'];attempt=time.time_ns()
 with archive(source,block_size=512*1024) as (z,stats):
  for i in range(start,len(chosen)):
   r=chosen.iloc[i];payload=z.read(r.source_member)
   if hashlib.sha256(payload).hexdigest()!=r.source_package_sha256:raise ValueError('Package differs from original extraction')
   target={k:int(r[k]) for k in ['municipality','zone','section']}
   result=audit(payload,r.source_member,DATES[2026][s['round']],target,s['round'])
   counts={k:len(v) for k,v in result['completion_seconds'].items()}
   passed=counts['target']==int(r.reviewed_observed_completions) and not sum(counts[k] for k in ['foreign','unknown','conflicting'])
   if result['unique_completions_all_contexts']!=int(r.reviewed_observed_completions):passed=False
   text_phase_unknown=any(x['phase'] is None and x['raw_completions']>0 for x in result['context_counts'])
   text_turn_unknown=any(x['turn'] is None and x['raw_completions']>0 for x in result['context_counts'])
   record={'year':2026,'round':s['round'],'uf':s['uf'],**target,'source_member':r.source_member,
           'source_package_sha256':r.source_package_sha256,'attendance':int(r.attendance),'observed_completions':int(r.reviewed_observed_completions),
           **{k+'_completions':v for k,v in counts.items()},'passed_internal_identity':bool(passed),
           'phase_not_explicit':text_phase_unknown,'turn_not_explicit':text_turn_unknown,
           'context_summary_json':json.dumps(result['context_counts'],ensure_ascii=False),'texts_sha256_json':json.dumps([{'member':t['member'],'sha256':t['sha256']} for t in result['texts']])}
   buffer.append(record)
   if not passed:
    issue=folder/f"issue-{target['municipality']}-{target['zone']}-{target['section']}.json"
    if not issue.exists():atomic_json(issue,result)
    cp['failures'].append(str(issue.relative_to(ROOT)))
   if len(buffer)>=100 or i+1==len(chosen):
    require_disk();p=folder/f'validated-{start:06d}-{i+1:06d}-{attempt}.parquet'
    if p.exists():raise ValueError('Refusing to overwrite evidence')
    pq.write_table(pa.Table.from_pylist(buffer),p,compression='zstd')
    cp['batches'].append({'path':str(p.relative_to(ROOT)),'sha256':digest(p),'rows':len(buffer)})
    cp.update(updated_at=now(),next_index=i+1);atomic_json(cp_path,cp)
    print(json.dumps({'at':now(),'year':2026,'round':s['round'],'uf':s['uf'],'processed':i+1,'selected':len(chosen),'failures':len(cp['failures'])}),flush=True)
    buffer=[];start=i+1
 cp.update(finished_at=now(),status='complete',read=stats,**{k:s[k] for k in ['year','round','uf','population','sample_size','is_census','design']})
 atomic_json(cp_path,cp);atomic_json(mp,cp);return cp


def main():
 p=argparse.ArgumentParser();p.add_argument('--prepare-only',action='store_true');p.add_argument('--workers',type=int,default=3);args=p.parse_args()
 plan=prepare()
 if args.prepare_only:
  print(json.dumps({'strata':len(plan['strata']),'selected':sum(s['sample_size'] for s in plan['strata']),'census_strata':sum(s['is_census'] for s in plan['strata'])}));return
 state={'started_at':now(),'status':'running','plan_sha256':digest(OUT/'plan.json'),'completed':[],'execution_errors':[]}
 with ProcessPoolExecutor(max_workers=args.workers) as pool:
  futures={pool.submit(work,s):s for s in sorted(plan['strata'],key=lambda s:(not(s['round']==2),-s['sample_size']))}
  for future in as_completed(futures):
   s=futures[future]
   try:
    result=future.result();state['completed'].append({'round':s['round'],'uf':s['uf'],'population':s['population'],'selected':s['sample_size'],'failures':len(result['failures']),'is_census':s['is_census']})
   except Exception as exc:state['execution_errors'].append({'round':s['round'],'uf':s['uf'],'error':repr(exc)})
   state['updated_at']=now();atomic_json(ROOT/'reports/context-validation-state.json',state)
 state.update(finished_at=now(),status='complete_pending_scientific_review' if not state['execution_errors'] else 'recoverable_execution_errors')
 atomic_json(ROOT/'reports/context-validation-state.json',state)
if __name__=='__main__':main()
