"""Compare extracted completed-voter events with BWeb section attendance."""
import argparse
import json
from pathlib import Path

import pandas as pd

from analysis_common import ROOT, atomic_json, digest, now


def validate(year, uf, round_no, native_root, bweb_root, output):
    natives = list((ROOT / native_root / str(year)).glob(f"*_{round_no}t_{uf}/complete.json"))
    bwebs = list((ROOT / bweb_root / str(year)).glob(f"*_{round_no}t_{uf}_*/complete.json"))
    if len(natives) != 1 or len(bwebs) != 1:
        raise ValueError(f"Expected one complete native and BWeb archive; got {len(natives)}, {len(bwebs)}")
    nmeta, bmeta = (json.loads(p.read_text()) for p in [natives[0], bwebs[0]])
    n = pd.concat([pd.read_parquet(ROOT / b["path"]) for b in nmeta["batches"]], ignore_index=True)
    b = pd.concat([pd.read_parquet(ROOT / f["path"]) for f in bmeta["outputs"]], ignore_index=True)
    date = {2026: {1: "04/10/2026", 2: "25/10/2026"}, 2022: {1: "02/10/2022", 2: "30/10/2022"},
            2024: {1: "06/10/2024", 2: "27/10/2024"}}[year][round_no]
    n = n[n["event_date"] == date].copy()
    office = "11" if year == 2024 else "1"
    b = b[b["CD_CARGO_PERGUNTA"] == office].copy()
    key = ["municipality", "zone", "section"]
    for old, new in [("CD_MUNICIPIO", "municipality"), ("NR_ZONA", "zone"), ("NR_SECAO", "section")]:
        b[new] = pd.to_numeric(b[old], errors="raise")
    for c in ["QT_COMPARECIMENTO", "QT_APTOS", "QT_ABSTENCOES", "QT_VOTOS", "NR_URNA_EFETIVADA"]:
        b[c] = pd.to_numeric(b[c], errors="raise")
    ng = n.groupby(key).size()
    unique_native = n.merge(ng.rename("native_rows"), on=key)
    fields = ["QT_COMPARECIMENTO", "QT_APTOS", "QT_ABSTENCOES", "DT_ENCERRAMENTO", "DT_ABERTURA", "NR_URNA_EFETIVADA"]
    consistency = b.groupby(key)[fields].nunique(dropna=False).max(axis=1).rename("bweb_max_distinct")
    agg = b.groupby(key).agg(comparecimento=("QT_COMPARECIMENTO", "first"), aptos=("QT_APTOS", "first"),
                             abstencoes=("QT_ABSTENCOES", "first"), candidate_sum=("QT_VOTOS", "sum"),
                             machine=("NR_URNA_EFETIVADA", "first"), close=("DT_ENCERRAMENTO", "first"),
                             open=("DT_ABERTURA", "first")).join(consistency).reset_index()
    joined = agg.merge(unique_native, on=key, how="outer", indicator=True)
    comparable = joined[(joined["_merge"] == "both") & (joined["bweb_max_distinct"] == 1) & (joined["native_rows"] == 1)].copy()
    comparable["difference"] = comparable["computed_count"] - comparable["comparecimento"]
    comparable["machine_in_log"] = comparable.apply(lambda r: int(r["machine"]) in r["machine_ids"], axis=1)
    comparable["candidate_sum_difference"] = comparable["candidate_sum"] - comparable["comparecimento"]
    anomalies = comparable[(comparable["difference"] != 0) | (~comparable["machine_in_log"]) |
                            (comparable["clock_backwards_count"] > 0) | (comparable["unparsed_target_date_lines"] > 0) |
                            (comparable["invalid_clock_lines"] > 0) | (comparable["candidate_sum_difference"] != 0)]
    output = ROOT / output
    output.parent.mkdir(parents=True, exist_ok=True)
    diagnostic_cols = key + ["comparecimento", "computed_count", "difference", "candidate_sum_difference", "machine",
                             "machine_in_log", "clock_backwards_count", "unparsed_target_date_lines", "invalid_clock_lines",
                             "duplicate_computed_count", "text_file_count", "nested_archive_count", "source_member"]
    anomalies[diagnostic_cols].to_csv(output.with_suffix(".exceptions.csv"), index=False)
    result = {"at": now(), "year": year, "uf": uf, "round": round_no, "office": office,
              "bweb_sections": len(agg), "native_section_rows": len(n), "bweb_only": int((joined["_merge"] == "left_only").sum()),
              "native_only": int((joined["_merge"] == "right_only").sum()),
              "ambiguous_bweb_sections": int((agg["bweb_max_distinct"] > 1).sum()),
              "ambiguous_native_sections": int((ng > 1).sum()), "unambiguous_matched_sections": len(comparable),
              "exact_attendance_matches": int((comparable["difference"] == 0).sum()),
              "attendance_mismatch_sections": int((comparable["difference"] != 0).sum()),
              "sum_native_completed": int(comparable["computed_count"].sum()),
              "sum_bweb_attendance": int(comparable["comparecimento"].sum()),
              "candidate_sum_mismatch_sections": int((comparable["candidate_sum_difference"] != 0).sum()),
              "electorate_identity_failures": int((agg["aptos"] != agg["comparecimento"] + agg["abstencoes"]).sum()),
              "machine_not_in_log_sections": int((~comparable["machine_in_log"]).sum()),
              "clock_backwards_sections": int((comparable["clock_backwards_count"] > 0).sum()),
              "unparsed_target_lines": int(n["unparsed_target_date_lines"].sum()),
              "invalid_clock_lines": int(n["invalid_clock_lines"].sum()),
              "duplicate_computed_records_removed": int(n["duplicate_computed_count"].sum()),
              "nested_log_sections": int((n["nested_archive_count"] > 0).sum()),
              "input_records": [{"path": str(p.relative_to(ROOT)), "sha256": digest(p)} for p in [natives[0], bwebs[0]]],
              "exceptions": str(output.with_suffix(".exceptions.csv").relative_to(ROOT)),
              "status": "requires_review" if len(anomalies) or len(comparable) != len(agg) else "all_sections_reconciled",
              "limits": "Pilot validation for this UF/year/round only; no causal claim or national completeness claim."}
    atomic_json(output, result)
    return result


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--year", type=int, default=2026)
    p.add_argument("--uf", default="AC")
    p.add_argument("--round", type=int, default=2)
    p.add_argument("--native-root", default="analysis/derived/native-logs-v1")
    p.add_argument("--bweb-root", default="analysis/derived/bweb-v1")
    p.add_argument("--output", default="reports/log-pilot-validation-2026-2t-AC.json")
    a = p.parse_args()
    print(json.dumps(validate(a.year, a.uf, a.round, a.native_root, a.bweb_root, a.output), ensure_ascii=False, indent=2))
