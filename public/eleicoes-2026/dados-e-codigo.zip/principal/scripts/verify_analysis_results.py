"""Numerical cross-checks of the completed analysis, separate from peer review."""
import json
import time

import numpy as np
import pandas as pd

from analysis_common import ROOT, atomic_json, digest, now
from margin_bounds import removal_margin_bounds


def main():
    reports = {n: json.loads((ROOT / f'reports/{n}.json').read_text()) for n in [
        'analysis-consolidation-state', 'temporal-population-state', 'margin-scenario-state',
        'intercompletion-state', 'context-sampling-bounds-state', 'supplemental-sensitivity-state']}
    checks, sources = [], []
    consolidation = reports['analysis-consolidation-state']
    assert not consolidation['coverage_gate']['missing']
    assert all(v['status'] == 'complete' for v in consolidation['steps'].values())
    assert set(consolidation['steps']) == {'context_uncertainty', 'temporal_population', 'intercompletion'}
    checks.append({'name': 'all_164_archives_and_three_consolidation_steps', 'passed': True})

    def frame(report, filename):
        p = ROOT / reports[report]['output_folder'] / filename
        sources.append({'path': str(p.relative_to(ROOT)), 'sha256': digest(p)})
        return pd.read_parquet(p) if p.suffix == '.parquet' else pd.read_csv(p)

    n = frame('temporal-population-state', 'national.csv')
    u = frame('temporal-population-state', 'uf.csv')
    m = frame('temporal-population-state', 'municipality.csv')
    coverage = frame('temporal-population-state', 'coverage.csv')
    assert len(coverage) == 6 and coverage.population_complete.all()
    additive = ['sections', 'eligible', 'attendance', 'sections_with_logs', 'sections_count_reconciled',
        'missing_log_sections', 'missing_log_attendance', 'count_mismatch_sections', 'recorded_completions',
        'unobserved_count_gap_if_no_spurious', 'strict_time_sections', 'startup_allowed_sections',
        'context_changed_sections', 'context_foreign_events_removed', 'clock_reversal_sections',
        'clock_reversal_after_completion_sections', 'recorded_strict_post_deadline',
        'recorded_inclusive_post_deadline', 'exact_deadline_events', 'recorded_17_18', 'recorded_18_19',
        'recorded_after_19', 'post_deadline_sections', 'strict_subset_late', 'startup_allowed_subset_late']
    for r in n[n.scope.eq('domestic')].itertuples():
        uf = u[(u.year == r.year) & (u['round'] == r.round) & u.uf.ne('ZZ')]
        mun = m[(m.year == r.year) & (m['round'] == r.round)]
        for field in additive:
            assert int(uf[field].sum()) == int(mun[field].sum()) == int(getattr(r, field)), (r.year, r.round, field)
        assert r.recorded_17_18 + r.recorded_18_19 + r.recorded_after_19 == r.recorded_strict_post_deadline
        assert r.recorded_inclusive_post_deadline - r.recorded_strict_post_deadline == r.exact_deadline_events
        assert r.sections_with_logs + r.missing_log_sections == r.sections
    checks.append({'name': 'municipal_uf_national_additive_reconciliation_and_temporal_identities', 'passed': True,
                   'domestic_populations': 6, 'fields': len(additive)})
    h = frame('temporal-population-state', 'minute-histograms.csv')
    for r in n[n.scope.eq('domestic')].itertuples():
        g = h[(h.year == r.year) & (h['round'] == r.round)]
        assert int(g.completions.sum()) == r.recorded_completions
        assert int(g.loc[g.minutes_after_ordinary_deadline >= 0, 'completions'].sum()) == r.recorded_inclusive_post_deadline
    checks.append({'name': 'minute_histograms_match_counts_and_inclusive_cutoffs', 'passed': True})
    bounds = frame('margin-scenario-state', 'conditional-margin-bounds.csv')
    c = frame('margin-scenario-state', 'section-bound-components.parquet')
    assert len(bounds) == 84 and not bounds.duplicated(['race', 'scenario', 'cutoff_shift_earlier_seconds']).any()
    rng = np.random.default_rng(20261031)
    for idx in rng.choice(len(c), min(1000, len(c)), replace=False):
        r = c.iloc[idx]
        scalar = removal_margin_bounds(r.winner_votes, r.runner_up_votes, r.other_outcomes, r.additional_voter_cap)
        assert scalar['minimum_margin_change'] == r.minimum_margin_change
        assert scalar['maximum_margin_change'] == r.maximum_margin_change
    for (race, scenario), g in c.groupby(['race', 'scenario']):
        b = bounds[(bounds.race == race) & (bounds.scenario == scenario) & (bounds.cutoff_shift_earlier_seconds == 0)].iloc[0]
        assert int(g.additional_voter_cap.sum()) == b.possible_added_voters_cap
        assert -int(g.minimum_margin_change.sum()) == b.maximum_adverse_margin_change
        assert int(g.maximum_margin_change.sum()) == b.maximum_favorable_margin_change
    for _, g in bounds.groupby(['race', 'scenario']):
        g = g.sort_values('cutoff_shift_earlier_seconds')
        assert (g.possible_added_voters_cap.diff().dropna() >= 0).all()
        assert (g.minimum_counterfactual_margin.diff().dropna() <= 0).all()
    assert (bounds.minimum_counterfactual_margin == bounds.observed_margin - bounds.maximum_adverse_margin_change).all()
    checks.append({'name': 'all_margin_sum_identities_and_1000_seeded_scalar_crosschecks', 'passed': True, 'seed': 20261031})
    audit = frame('context-sampling-bounds-state', 'presidential-bounds-with-audit-uncertainty.csv')
    alloc = frame('context-sampling-bounds-state', 'worst-case-context-allocations.csv')
    finite = frame('context-sampling-bounds-state', 'finite-population-audit-bounds.csv')
    assert finite.sample_size.sum() == 63362 and finite.observed_identity_failures.sum() == 0
    assert (finite.loc[finite.is_census, 'upper_possible_identity_failures'] == 0).all()
    for r in audit.itertuples():
        g = alloc[alloc.cutoff_shift_earlier_seconds == r.cutoff_shift_earlier_seconds]
        assert int(g.extra_adverse_votes.sum()) == r.additional_adverse_bound_from_context_sampling
        assert r.minimum_counterfactual_margin_with_audit_uncertainty == r.observed_margin - r.base_conditional_adverse_bound - r.additional_adverse_bound_from_context_sampling
    checks.append({'name': 'audit_frame_counts_census_and_adverse_allocations', 'passed': True})
    s = frame('supplemental-sensitivity-state', 'accepted-alternatives.csv')
    assert (s.primary_completions == 0).all() and (s.primary_event_overlap_count == 0).all()
    assert (s.alternative_excess == 0).all()
    assert int(s.additional_reconstructed_completions.sum()) == reports['supplemental-sensitivity-state']['additional_reconstructed_completions']
    assert (s.additional_reconstructed_completions == s.retained_target_completions).all()
    checks.append({'name': 'supplemental_whole_sequence_zero_overlap_and_coverage', 'passed': True})
    intervals = frame('intercompletion-state', 'national-intervals.csv')
    ih = frame('intercompletion-state', 'interval-histograms.parquet')
    for r in intervals.itertuples():
        g = ih[(ih.year == r.year) & (ih['round'] == r.round) & (ih.setting == r.setting)]
        assert int(g.intervals.sum()) == r.intervals
        assert int(g.loc[g.gap_seconds == 0, 'intervals'].sum()) == r.zero_second_intervals
        assert int(g.loc[g.is_over900_bin, 'intervals'].sum()) == r.intervals_over900_seconds
    checks.append({'name': 'intercompletion_histogram_denominators_and_tail', 'passed': True})
    out = ROOT / 'reports/analysis-numerical-verification' / str(time.time_ns())
    out.mkdir(parents=True, exist_ok=False)
    result = {'at': now(), 'status': 'passed_numerical_crosschecks_not_causal_identification',
              'output_folder': str(out.relative_to(ROOT)), 'checks': checks,
              'inputs': sources + [{'path': f'reports/{k}.json', 'sha256': digest(ROOT / f'reports/{k}.json')} for k in reports],
              'code_sha256': digest(ROOT / 'scripts/verify_analysis_results.py')}
    atomic_json(out / 'verification.json', result)
    atomic_json(ROOT / 'reports/analysis-numerical-verification-state.json', result)
    print(json.dumps({'checks': len(checks), 'status': result['status'], 'folder': result['output_folder']}))


if __name__ == '__main__':
    main()
