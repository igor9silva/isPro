"""Verify downstream impact and refresh the next-day sensitivity, preserving it."""
import json
import time
from pathlib import Path
import pandas as pd
from analysis_common import ROOT, atomic_json, digest, now


def main():
    correction = json.loads((ROOT / 'reports/date-correction-state.json').read_text())
    assert correction['vote_event_counts_and_quality_subsets_identical']
    assert sum(r['changed_rows'] for r in correction['canonical']) == 1
    assert correction['reviewed_archives'] == 158
    assert all(r['all_counts_identity_quality_and_event_times_identical'] for r in correction['reviewed'])
    baseline = ROOT / json.loads((ROOT / 'reports/date-correction-recomputation-baseline.json').read_text())['folder']
    comparisons = []
    for name in ['temporal-population-state', 'election-comparison-state', 'closure-selection-state']:
        old = json.loads((baseline / (name + '.json')).read_text())
        new = json.loads((ROOT / 'reports' / (name + '.json')).read_text())
        of, nf = [ROOT / r.get('output_folder', r.get('folder', '')) for r in [old, new]]
        assert of != nf
        for op in sorted(of.glob('*.csv')):
            np = nf / op.name
            a, b = pd.read_csv(op), pd.read_csv(np)
            assert list(a) == list(b) and a.shape == b.shape
            difference = ~((a == b) | (a.isna() & b.isna()))
            fields = {c: int(difference[c].sum()) for c in a if difference[c].any()}
            changes = []
            for idx in a.index[difference.any(axis=1)]:
                changes.append({'row': int(idx), 'before': a.loc[idx].to_dict(), 'after': b.loc[idx].to_dict()})
            if name != 'election-comparison-state':
                assert not fields, (name, op.name, fields)
            else:
                assert set(fields) <= {'usable_close_time_sections', 'closed_more_than_10m_after_deadline',
                                       'closed_more_than_2h_after_deadline', 'median_close_seconds_after_deadline'}
            comparisons.append({'analysis': name, 'file': op.name, 'changed_fields': fields,
                'changes': changes, 'before': str(op.relative_to(ROOT)), 'before_sha256': digest(op),
                'after': str(np.relative_to(ROOT)), 'after_sha256': digest(np)})
    # All downstream components used for margins, probabilistic identity bounds,
    # event histograms and interval eligibility were asserted equal per archive.
    old_path = baseline / 'following-day-review-state.json'
    old = json.loads(old_path.read_text())
    out = ROOT / 'analysis/source-audit/following-day-v2' / str(time.time_ns())
    out.mkdir(parents=True, exist_ok=False)
    new = {**old, 'at': now(), 'output_folder': str(out.relative_to(ROOT)),
           'previous_report': str(old_path.relative_to(ROOT)), 'previous_report_sha256': digest(old_path),
           'date_correction_sha256': digest(ROOT / 'reports/date-correction-state.json')}
    for r in new['cases']:
        path = ROOT / f"analysis/derived/temporal-reviewed-v2/{r['year']}/{r['round']}t-{r['uf']}/sections.parquet"
        f = pd.read_parquet(path, filters=[(k, '=', r[k]) for k in ['municipality', 'zone', 'section']])
        assert len(f) == 1
        r['bweb_close_elapsed_seconds'] = float(f.closed_elapsed_seconds.iloc[0])
        r['corrected_temporal_table'] = str(path.relative_to(ROOT))
        r['corrected_temporal_table_sha256'] = digest(path)
        assert r['first_next_day_second'] + 86400 <= r['bweb_close_elapsed_seconds']
    pd.DataFrame(new['cases']).to_csv(out / 'next-day-cases.csv', index=False)
    atomic_json(out / 'analysis.json', new)
    atomic_json(ROOT / 'reports/following-day-review-state.json', new)
    result = {'at': now(), 'status': 'passed_date_correction_and_downstream_recomputation',
        'canonical_changed_rows': 1, 'reviewed_archives_checked': 158,
        'all_event_counts_quality_sets_margin_inputs_and_interval_inputs_identical': True,
        'all_2026_values_unchanged': True, 'comparison_files': comparisons,
        'new_following_day_report': str((out / 'analysis.json').relative_to(ROOT)),
        'scope': 'One first-turn 2024 PI mayoral section; BWeb closure/emission and derived timing qualification.',
        'inputs': [{'path': str(p.relative_to(ROOT)), 'sha256': digest(p)} for p in [
            ROOT / 'reports/date-correction-state.json', ROOT / 'reports/date-correction-recomputation-baseline.json']],
        'code_sha256': digest(__file__)}
    atomic_json(ROOT / 'reports/date-correction-verification.json', result)
    print(json.dumps({'status': result['status'], 'changed_csv_files': sum(bool(r['changed_fields']) for r in comparisons)}))


if __name__ == '__main__':
    main()
