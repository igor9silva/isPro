"""Validate each finished native archive while other extraction jobs continue.

This local supervisor does not download data, change source files or notify the
user. Scientific interpretation and exception review remain explicit next steps.
"""
import json
from pathlib import Path
import re
import time

import psutil
from analysis_common import ROOT, atomic_json, now
from validate_log_pilot import validate

JOBS = ["native-2026-v1", "native-history-v2"]
ROOTS = ["analysis/derived/native-logs-v1", "analysis/derived/native-logs-history-v2"]


def active_jobs():
    result = []
    for job in JOBS:
        launch = json.loads((ROOT / "metadata/analysis-jobs" / job / "launch.json").read_text())
        try:
            p = psutil.Process(launch["pid"])
            if p.is_running() and p.status() != psutil.STATUS_ZOMBIE:
                result.append(job)
        except psutil.NoSuchProcess:
            pass
    return result


def main():
    folder = ROOT / "reports/log-validation"
    folder.mkdir(parents=True, exist_ok=True)
    attempted_errors = {}
    while True:
        records = []
        for root in ROOTS:
            for p in sorted((ROOT / root).glob("*/*/complete.json")):
                m = re.search(r"_(\d{4})_([12])t_([A-Z]{2})$", p.parent.name)
                if not m:
                    continue
                year, turn, uf = int(m[1]), int(m[2]), m[3]
                # The original generic historical pilot is preserved but superseded.
                if root.endswith("native-logs-v1") and year != 2026:
                    continue
                dest = folder / f"{year}-{turn}t-{uf}.json"
                if dest.exists():
                    records.append(json.loads(dest.read_text()))
                    continue
                tables = list((ROOT / "analysis/derived/bweb-v1" / str(year)).glob(f"bweb_{turn}t_{uf}_*/complete.json"))
                if len(tables) != 1:
                    continue
                metadata = json.loads(p.read_text())
                try:
                    if metadata["status"] == "complete_no_sections":
                        result = {"at": now(), "year": year, "round": turn, "uf": uf,
                                  "status": "structural_absence_no_sections", "native_archive": str(p.relative_to(ROOT)),
                                  "evidence": metadata["structural_absence_evidence"]}
                        atomic_json(dest, result)
                    else:
                        result = validate(year, uf, turn, root, "analysis/derived/bweb-v1", str(dest.relative_to(ROOT)))
                    records.append(result)
                    print(json.dumps({"at": now(), "archive": p.parent.name, "validation_status": result["status"],
                                      "attendance_mismatch_sections": result.get("attendance_mismatch_sections")}), flush=True)
                except Exception as e:
                    attempted_errors[str(p.relative_to(ROOT))] = {"at": now(), "error": str(e)}
        active = active_jobs()
        summary = {"at": now(), "status": "running" if active else "finished_pending_scientific_review", "active_extraction_jobs": active,
                   "validated_archives": len(records),
                   "count_mismatch_sections": sum(r.get("attendance_mismatch_sections", 0) for r in records),
                   "coverage_mismatch_rows": sum(r.get("bweb_only", 0) + r.get("native_only", 0) for r in records),
                   "header_id_mismatch_sections": sum(r.get("machine_not_in_log_sections", 0) for r in records),
                   "clock_backwards_sections": sum(r.get("clock_backwards_sections", 0) for r in records),
                   "statuses": [{k: r.get(k) for k in ["year", "round", "uf", "status", "unambiguous_matched_sections", "attendance_mismatch_sections"]} for r in records],
                   "execution_errors": attempted_errors,
                   "note": "Per-section attendance validation only. Header ID caveats in 2022 are documented separately. Other scientific modules remain required."}
        atomic_json(ROOT / "reports/log-validation-summary.json", summary)
        if not active:
            return
        time.sleep(300)


if __name__ == "__main__":
    main()
