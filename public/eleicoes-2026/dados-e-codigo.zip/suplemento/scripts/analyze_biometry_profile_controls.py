"""Descriptive profile controls; no causal or individual voting interpretation."""
import json,time,re
from pathlib import Path
import numpy as np
import pandas as pd
from biometry_history_extension import ROOT,now,sha,save_json,cluster_ols,correlations,Study,centered,weighted_corr
from scipy.stats import t as student_t

KEY=['uf','municipality','zone','section']
RENAME={'SG_UF':'uf','CD_MUNICIPIO':'municipality','NR_ZONA':'zone','NR_SECAO':'section','NR_LOCAL_VOTACAO':'profile_polling_place'}

def normalized_aggregation(x):
    if pd.isna(x):return None
    if str(x).strip() in ['','#NULO#','-1','-3']:return ''
    return ','.join(str(n) for n in sorted(set(int(y) for y in re.findall(r'\d+',str(x)))))

def main():
    state=json.loads((ROOT/'reports/biometry-profile-state.json').read_text())
    if state['status']!='complete' or state['errors'] or state['completed']!=state['expected']:raise RuntimeError('Profile coverage incomplete')
    source=ROOT/json.loads((ROOT/'reports/biometry-history-computation-state.json').read_text())['output']
    out=ROOT/'analysis/extensions/biometry-history-v1'/('profile-analysis-'+str(time.time_ns()));out.mkdir()
    coverage=[];models=[];national=[];diagnostics=[];effects=[];ufcluster=[];leaveout=[]
    for year in [2018,2022,2026]:
        files=sorted((ROOT/state['output']/str(year)).glob('*/complete.json'));frames=[]
        for f in files:
            x=json.loads(f.read_text());p=ROOT/x['output']
            if sha(p)!=x['output_sha256']:raise ValueError('Profile changed')
            frames.append(pd.read_parquet(p))
        # The extractor's legacy name education_unknown counts negative codes only.
        # Official code 0 is also "NAO INFORMADO"; it was not separately aggregated.
        # Rename the derived field to its measured definition, without rewriting extraction.
        prof=pd.concat(frames,ignore_index=True).rename(columns={**RENAME,'education_unknown':'education_negative_code'})
        # Duplicate key across polling places is documented and not arbitrarily selected.
        dup=prof.duplicated(KEY,keep=False)
        national.append({'year':year,'profile_records':len(prof),'ambiguous_key_records':int(dup.sum()),
            'registered':int(prof.registered.sum()),'enrolled':int(prof.enrolled.sum()),
            'enrolled_share':prof.enrolled.sum()/prof.registered.sum(),
            'age_unknown':int(prof.age_unknown.sum()),'education_negative_code':int(prof.education_negative_code.sum())})
        prof=prof[~dup].copy()
        sec=pd.read_parquet(source/f'sections-{year}.parquet')
        sec=sec[sec.uf.ne('ZZ')&sec.usable_turnout&sec.nominal_votes.gt(0)]
        q=sec.merge(prof,on=KEY,how='left',validate='many_to_one',indicator=True)
        for col in ['enrolled','age60plus','low_education','female','age_unknown','education_negative_code']:
            q['profile_'+col+'_share']=q[col]/q.registered.where(q.registered>0)
        q['same_place']=pd.to_numeric(q.polling_place,errors='coerce').eq(q.profile_polling_place)
        q['eligible_relative_difference']=(q.registered-q.eligible).abs()/q.eligible.where(q.eligible>0)
        q['profile_link_strict']=q.same_place & q.eligible_relative_difference.le(.01)
        q['observed_count_exceeds_enrolled_eligible']=q.biometry_without_auth>q.enrolled
        q['non_auth_per_registered_biometric']=(q.biometry_without_auth/q.enrolled.where(q.enrolled>0)).where(q.biometry_valid)
        q.to_parquet(out/f'linked-profiles-{year}.parquet',index=False,compression='zstd')
        for rnd,g in q.groupby('round'):
            for uf in sorted(g.uf.unique()):
                z=g[g.uf.ne(uf)].dropna(subset=['biometry_rate','pt_share'])
                leaveout.append({'year':year,'round':rnd,'excluded_uf':uf,'n':len(z),
                    'pearson':weighted_corr(z.biometry_rate,z.pt_share),
                    'within_municipality_pearson':weighted_corr(centered(z.biometry_rate,z.municipality_key),centered(z.pt_share,z.municipality_key))})
            for subset,mask in [('key_link',g._merge.eq('both')),('strict_place_and_eligible_1pct',g.profile_link_strict)]:
                t=g[mask]
                coverage.append({'year':year,'round':rnd,'subset':subset,'total_bweb_sections':len(g),'matched':len(t),
                    'share_bweb_attendance':t.attendance.sum()/g.attendance.sum(),'count_exceeds_enrolled':int(t.observed_count_exceeds_enrolled_eligible.sum()),
                    'zero_enrolled_positive_non_auth':int((t.enrolled.eq(0)&t.biometry_without_auth.gt(0)).sum()),
                    'median_relative_registered_difference':t.eligible_relative_difference.median()})
                features=['biometry_rate','log_eligible','turnout','invalid_fraction','profile_enrolled_share','profile_age60plus_share','profile_low_education_share']
                t=t.dropna(subset=features+['pt_share'])
                for weighting in ['equal_section','attendance']:
                    r=cluster_ols(t.pt_share,t[features],t.municipality_key,t.attendance if weighting=='attendance' else None,True)
                    w=t.attendance.to_numpy(float) if weighting=='attendance' else np.ones(len(t))
                    yc=centered(t.pt_share,t.municipality_key,w);xc=centered(t[features],t.municipality_key,w)
                    u=cluster_ols(yc,xc,t.uf,w,False);ng=t.municipality_key.nunique();n=len(t);k=len(features)
                    corrected_se=u['se'][0]*np.sqrt((n-k)/(n-k-ng))
                    crit=student_t.ppf(.975,u['clusters']-1)
                    ufcluster.append({'year':year,'round':rnd,'subset':subset,'weighting':weighting,'n':n,'uf_clusters':u['clusters'],
                        'absorbed_municipalities':ng,'effect_pp_per_10pp_biometry':u['beta'][0]*10,
                        'lower':(u['beta'][0]-crit*corrected_se)*10,'upper':(u['beta'][0]+crit*corrected_se)*10})
                    for i,term in enumerate(features):
                        models.append({'year':year,'round':rnd,'subset':subset,'weighting':weighting,'term':term,'coefficient':r['beta'][i],
                            'effect_pp_per_10pp' if term!='log_eligible' else 'effect_pp_per_log_unit':r['beta'][i]*(100 if term=='log_eligible' else 10),
                            'lower_scaled':r['lower'][i]*(100 if term=='log_eligible' else 10),'upper_scaled':r['upper'][i]*(100 if term=='log_eligible' else 10),
                            'n':r['n'],'clusters':r['clusters'],'within_r2':r['r2']})
                for col in ['profile_enrolled_share','profile_age60plus_share','profile_low_education_share']:
                    diagnostics.append(correlations(t,col,'biometry_rate',{'year':year,'round':rnd,'subset':subset,'x':col,'y':'biometry_rate'}))
                    diagnostics.append(correlations(t,col,'biometry_rate',{'year':year,'round':rnd,'subset':subset,'x':col,'y':'biometry_rate','within':True},group='municipality_key'))
                if rnd==2 and subset=='strict_place_and_eligible_1pct':
                    for uf,u in t.groupby('uf'):
                        try:r=cluster_ols(u.pt_share,u[features],u.municipality_key,None,True)
                        except ValueError as exc:
                            effects.append({'year':year,'uf':uf,'n':len(u),'status':'not_estimable_rank_deficiency','reason':str(exc)});continue
                        effects.append({'year':year,'uf':uf,'n':r['n'],'clusters':r['clusters'],'effect_pp_per_10pp_biometry':r['beta'][0]*10,
                            'lower':r['lower'][0]*10,'upper':r['upper'][0]*10})
        print(now(),'profile_models',year,flush=True)
    for name,rows in [('profile-coverage',coverage),('profile-national',national),('profile-adjusted-models',models),('profile-operational-correlations',diagnostics),('regional-profile-adjusted-models',effects),('profile-uf-cluster-sensitivity',ufcluster),('leave-one-uf-out',leaveout)]:
        d=pd.DataFrame(rows);d.to_csv(out/(name+'.csv'),index=False);d.to_parquet(out/(name+'.parquet'),index=False,compression='zstd')
    # Normalize zero-padded aggregation lists when testing historical section stability.
    audit=[]
    def load(y):
        d=pd.read_parquet(source/f'sections-{y}.parquet')
        norm=d.aggregated_sections.map(normalized_aggregation)
        audit.append({'year':y,'rows':len(d),'changed_representation':int(d.aggregated_sections.fillna('').ne(norm.fillna('')).sum()),'polling_place_unavailable':int(pd.to_numeric(d.polling_place,errors='coerce').fillna(-1).le(0).sum())})
        d['aggregated_sections']=norm;return d
    helper=object.__new__(Study);helper.out=out;helper.tables={};helper.load=load;helper.checkpoint=lambda step:print(now(),step,flush=True)
    helper.panels()
    save_json(out/'aggregation-normalization-review.json',{'reason':'Canonical source retains formatting: 2018 includes leading zeros, later years may not. Numeric identity avoids spurious exclusions. Raw tables and first panel run retained. 2014 unavailable polling-place information cannot establish place stability across years.','changes':audit})
    result={'at':now(),'status':'computed_pending_review','output':str(out.relative_to(ROOT)),'source':str(source.relative_to(ROOT)),'profile_inputs':state['output'],'code_sha256':sha(__file__),
        'outputs':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.iterdir())]}
    save_json(out/'state.json',result);save_json(ROOT/'reports/biometry-profile-analysis-state.json',result)

if __name__=='__main__':main()
