"""Exploratory extension: biometric non-authentication and electoral history.

Uses only preserved local derivatives; never associates a voter's identity,
authentication method or time with a candidate. See the timestamped plan.
"""
import argparse
import hashlib
import json
import math
import time
from datetime import datetime, timezone
from pathlib import Path

import duckdb
import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
KEY = ['uf', 'municipality', 'zone', 'section']
YEARS = [2014, 2018, 2022, 2024, 2026]
SEED = 20261031


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def save_json(path, obj):
    def clean(v):
        if isinstance(v, dict): return {str(k):clean(x) for k,x in v.items()}
        if isinstance(v, (list,tuple,np.ndarray)): return [clean(x) for x in v]
        if isinstance(v,np.generic): return clean(v.item())
        if isinstance(v,float) and not math.isfinite(v): return None
        return v
    path.write_text(json.dumps(clean(obj), ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def weighted_corr(x, y, w=None):
    x, y = np.asarray(x, float), np.asarray(y, float)
    w = np.ones(len(x)) if w is None else np.asarray(w, float)
    keep = np.isfinite(x) & np.isfinite(y) & np.isfinite(w) & (w > 0)
    x, y, w = x[keep], y[keep], w[keep]
    if len(x) < 2 or w.sum() == 0:
        return np.nan
    x = x - np.average(x, weights=w)
    y = y - np.average(y, weights=w)
    denom = np.sqrt(np.dot(w, x*x) * np.dot(w, y*y))
    return np.dot(w, x*y) / denom if denom > 0 else np.nan


def centered(values, groups, weights=None):
    values = np.asarray(values, float)
    one_dim = values.ndim == 1
    if one_dim:
        values = values[:, None]
    w = np.ones(len(values)) if weights is None else np.asarray(weights, float)
    g, unique = pd.factorize(groups, sort=True)
    sw = np.bincount(g, weights=w, minlength=len(unique))
    result = values.copy()
    for j in range(values.shape[1]):
        means = np.bincount(g, weights=w*values[:, j], minlength=len(unique)) / sw
        result[:, j] -= means[g]
    return result[:, 0] if one_dim else result


def cluster_ols(y, x, groups, weights=None, fixed_effects=False):
    """WLS with municipality cluster sandwich; FE uses weighted demeaning.

    Inference is conditional on this descriptive model and independent clusters,
    not sampling uncertainty of the observed census or a causal interval.
    """
    y, x = np.asarray(y, float), np.asarray(x, float)
    w = np.ones(len(y)) if weights is None else np.asarray(weights, float)
    g, unique = pd.factorize(groups, sort=True)
    if fixed_effects:
        y, x = centered(y, g, w), centered(x, g, w)
    rootw = np.sqrt(w)
    xw, yw = x*rootw[:, None], y*rootw
    rank = np.linalg.matrix_rank(xw)
    if rank < x.shape[1]:
        raise ValueError('Rank deficient descriptive model')
    bread = np.linalg.inv(xw.T @ xw)
    beta = np.linalg.lstsq(xw, yw, rcond=None)[0]
    resid = y - x @ beta
    scores = np.zeros((len(unique), x.shape[1]))
    np.add.at(scores, g, x*(w*resid)[:, None])
    n, k, ng = len(y), x.shape[1], len(unique)
    df = n-k-(ng if fixed_effects else 0)
    factor = (ng/(ng-1))*((n-1)/df) if ng > 1 and df > 0 else np.nan
    covariance = bread @ (scores.T @ scores) @ bread * factor
    se = np.sqrt(np.maximum(np.diag(covariance), 0))
    critical = stats.t.ppf(.975, ng-1)
    denom = np.dot(w, (y-np.average(y, weights=w))**2)
    return {'beta': beta, 'se': se, 'lower': beta-critical*se,
            'upper': beta+critical*se, 'n': n, 'clusters': ng,
            'r2': 1-np.dot(w, resid**2)/denom if denom else np.nan}


def correlations(df, x, y, context, weights='attendance', group=None):
    q = df[[x, y, weights] + ([group] if group else [])].replace([np.inf, -np.inf], np.nan).dropna()
    q = q[q[weights] > 0]
    if len(q) < 30:
        return {**context, 'n': len(q), 'pearson': np.nan, 'spearman': np.nan,
                'weighted_pearson': np.nan, 'reason': 'fewer_than_30'}
    a, b = q[x].to_numpy(float), q[y].to_numpy(float)
    w = q[weights].to_numpy(float)
    if group:
        a, b = centered(a, q[group]), centered(b, q[group])
        aw, bw = centered(q[x], q[group], w), centered(q[y], q[group], w)
    else:
        aw, bw = a, b
    return {**context, 'n': len(q), 'pearson': weighted_corr(a, b),
            'spearman': weighted_corr(stats.rankdata(a), stats.rankdata(b)),
            'weighted_pearson': weighted_corr(aw, bw, w),
            'within_municipality': bool(group), 'weight_sum': w.sum()}


class Study:
    def __init__(self):
        self.out = ROOT / 'analysis/extensions/biometry-history-v1' / ('run-' + str(time.time_ns()))
        self.out.mkdir(parents=True)
        self.tables = {}
        self.inputs = []
        self.state = {'started_at': now(), 'status': 'running', 'output': str(self.out.relative_to(ROOT)),
                      'plan': 'analysis/extensions/biometry-history-v1/plan.json',
                      'code_sha256': sha(__file__), 'steps': [], 'inputs': self.inputs}
        self.checkpoint('start')

    def checkpoint(self, step):
        self.state['updated_at'] = now()
        self.state['steps'].append({'at': now(), 'step': step})
        save_json(self.out/'run.json', self.state)
        save_json(ROOT/'reports/biometry-history-computation-state.json', self.state)
        print(now(), step, flush=True)

    def table(self, name, records):
        frame = records if isinstance(records, pd.DataFrame) else pd.DataFrame(records)
        frame.to_csv(self.out/(name+'.csv'), index=False)
        frame.to_parquet(self.out/(name+'.parquet'), index=False, compression='zstd')
        self.tables[name] = frame
        return frame

    def build(self, year):
        p = ROOT/f'analysis/derived/sections-v3/{year}/section-office.parquet'
        self.inputs.append({'path': str(p.relative_to(ROOT)), 'sha256': sha(p)})
        cols = ['year','round','uf','municipality','municipality_name','zone','section','office',
                'polling_place','aggregated_sections','eligible','attendance','abstention','nominal_votes',
                'blank_votes','null_votes','biometry_without_auth','distinct_biometry_without_auth',
                'metadata_conflict','usable_turnout','usable_timing','closed_elapsed_seconds',
                'close_seconds_after_ordinary_deadline','open_seconds_after_ordinary_start','machine_type']
        d = pd.read_parquet(p, columns=cols)
        d = d[d.office == (11 if year == 2024 else 1)].copy()
        if d.duplicated(['round']+KEY).any():
            raise ValueError('Duplicate canonical section key')
        base = 'bweb-2014-v1' if year == 2014 else 'bweb-v1'
        manifests = sorted((ROOT/f'analysis/derived/{base}/{year}').glob('*/complete.json'))
        files=[]
        for m in manifests:
            self.inputs.append({'path': str(m.relative_to(ROOT)), 'sha256': sha(m)})
            for f in json.loads(m.read_text())['outputs']:
                target=ROOT/f['path']
                if sha(target)!=f['sha256']:raise ValueError('BWeb input digest changed: '+str(target))
                files.append(str(target))
        con=duckdb.connect(); con.execute("SET threads=2");con.execute("SET memory_limit='2GB'")
        con.from_parquet(files, union_by_name=True).create_view('raw')
        names=set(con.table('raw').columns)
        uf='SG_UF' if 'SG_UF' in names else 'SG_ UF'
        con.sql(f'''CREATE VIEW v AS SELECT try_cast(NR_TURNO AS INTEGER) AS round,
            "{uf}" AS uf,try_cast(CD_MUNICIPIO AS INTEGER) AS municipality,
            try_cast(NR_ZONA AS INTEGER) AS zone,try_cast(NR_SECAO AS INTEGER) AS section,
            try_cast(NR_VOTAVEL AS INTEGER) AS candidate,try_cast(QT_VOTOS AS BIGINT) AS votes
            FROM raw WHERE try_cast(CD_CARGO_PERGUNTA AS INTEGER)={11 if year==2024 else 1}
            AND try_cast(CD_TIPO_VOTAVEL AS INTEGER)=1''')
        national=con.sql('SELECT round,candidate,sum(votes) AS votes FROM v GROUP BY ALL').df()
        national['year']=year
        self.table(f'candidate-totals-{year}',national)
        candidates=con.sql('SELECT round,uf,municipality,zone,section,candidate,sum(votes) AS votes FROM v GROUP BY ALL').df()
        sums=candidates.groupby(['round']+KEY,observed=True).votes.sum().rename('check_nominal')
        d=d.merge(sums,on=['round']+KEY,how='left',validate='one_to_one')
        d['check_nominal']=d.check_nominal.fillna(0)
        if (d.check_nominal != d.nominal_votes).any():
            raise ValueError('Candidate and canonical nominal totals differ')
        pt=candidates[candidates.candidate==13].set_index(['round']+KEY).votes.rename('pt_votes')
        d=d.merge(pt,on=['round']+KEY,how='left',validate='one_to_one')
        d['pt_votes']=d.pt_votes.fillna(0).astype('int64')
        # For second turns the largest non-PT total identifies the actual opposing candidate.
        runner={int(r):int(g[g.candidate!=13].sort_values('votes',ascending=False).iloc[0].candidate)
                for r,g in national.groupby('round')}
        other=candidates[candidates.candidate==candidates['round'].map(runner)]
        other=other.set_index(['round']+KEY).votes.rename('opponent_votes')
        d=d.merge(other,on=['round']+KEY,how='left',validate='one_to_one')
        d['opponent_votes']=d.opponent_votes.fillna(0).astype('int64')
        d['opponent_code']=d['round'].map(runner)
        d['biometry_valid']=(d.distinct_biometry_without_auth==1)&d.biometry_without_auth.between(0,d.attendance)&(~d.metadata_conflict)
        d['biometry_rate']=(d.biometry_without_auth/d.attendance.where(d.attendance>0)).where(d.biometry_valid)
        d['pt_share']=d.pt_votes/d.nominal_votes.where(d.nominal_votes>0)
        d['opponent_share']=d.opponent_votes/d.nominal_votes.where(d.nominal_votes>0)
        d['turnout']=d.attendance/d.eligible.where(d.eligible>0)
        d['invalid_fraction']=(d.blank_votes+d.null_votes)/d.attendance.where(d.attendance>0)
        d['log_eligible']=np.log(d.eligible.where(d.eligible>0))
        d['close_asinh_minutes']=np.arcsinh(d.close_seconds_after_ordinary_deadline/60).where(d.usable_timing)
        d['municipality_key']=d.uf+':'+d.municipality.astype(str)
        d['zone_key']=d.municipality_key+':'+d.zone.astype(str)
        d.to_parquet(self.out/f'sections-{year}.parquet',index=False,compression='zstd')
        con.close()
        self.checkpoint('built_'+str(year))
        return d

    def load(self,year):
        return pd.read_parquet(self.out/f'sections-{year}.parquet')

    def summaries(self):
        summaries=[];cors=[];models=[];bins=[];extremes=[];digits=[];geo_extremes=[];quality=[]
        for year in YEARS:
            d=self.load(year)
            for (rnd,overseas),full in d.groupby(['round',d.uf.eq('ZZ')]):
                bio=full.biometry_valid & full.attendance.gt(0)
                quality.append({'year':year,'round':rnd,'overseas':overseas,'sections':len(full),
                    'missing_biometry':int(full.biometry_without_auth.isna().sum()),
                    'negative_biometry':int(full.biometry_without_auth.lt(0).sum()),
                    'biometry_over_attendance':int(full.biometry_without_auth.gt(full.attendance).sum()),
                    'biometry_conflicts':int(full.distinct_biometry_without_auth.gt(1).sum()),
                    'unusable_turnout':int((~full.usable_turnout).sum()),'zero_attendance':int(full.attendance.eq(0).sum())})
                summaries.append({'year':year,'round':rnd,'overseas':overseas,'sections':len(full),
                    'attendance':full.attendance.sum(),'eligible':full.eligible.sum(),
                    'nominal_votes':full.nominal_votes.sum(),'pt_votes':full.pt_votes.sum(),
                    'biometry_count_valid':full.loc[bio,'biometry_without_auth'].sum(),
                    'biometry_observed_attendance':full.loc[bio,'attendance'].sum(),
                    'biometry_rate_valid':full.loc[bio,'biometry_without_auth'].sum()/full.loc[bio,'attendance'].sum() if bio.any() else np.nan,
                    'valid_biometry_sections':int(bio.sum()),'positive_biometry_sections':int(full.biometry_without_auth.gt(0).sum())})
                if overseas or year==2024:
                    continue
                q=full[full.usable_turnout & full.nominal_votes.gt(0) & full.attendance.gt(0)].copy()
                for x in ['biometry_rate','close_asinh_minutes','turnout','log_eligible']:
                    ctx={'year':year,'round':rnd,'x':x,'y':'pt_share'}
                    cors.append(correlations(q,x,'pt_share',{**ctx,'level':'section'}))
                    cors.append(correlations(q,x,'pt_share',{**ctx,'level':'section_within_municipality'},group='municipality_key'))
                for level,keys in [('uf',['uf']),('municipality',['uf','municipality'])]:
                    z=q[q.biometry_valid].groupby(keys,observed=True).agg(attendance=('attendance','sum'),
                        biometry_without_auth=('biometry_without_auth','sum'),pt_votes=('pt_votes','sum'),nominal_votes=('nominal_votes','sum')).reset_index()
                    z['biometry_rate']=z.biometry_without_auth/z.attendance
                    z['pt_share']=z.pt_votes/z.nominal_votes
                    if level=='uf':
                        # UF aggregates are all 27 units; retain the finite descriptive coefficient.
                        ctx={'year':year,'round':rnd,'x':'biometry_rate','y':'pt_share','level':level,'n':len(z),
                            'pearson':weighted_corr(z.biometry_rate,z.pt_share),
                            'spearman':weighted_corr(stats.rankdata(z.biometry_rate),stats.rankdata(z.pt_share)),
                            'weighted_pearson':weighted_corr(z.biometry_rate,z.pt_share,z.attendance)}
                        cors.append(ctx)
                    else:cors.append(correlations(z,'biometry_rate','pt_share',{'year':year,'round':rnd,'x':'biometry_rate','y':'pt_share','level':level}))
                    z['year']=year;z['round']=rnd
                    self.table(f'{level}-biometry-{year}-{rnd}',z)
                for uf,g in q.groupby('uf'):
                    cors.append(correlations(g,'biometry_rate','pt_share',{'year':year,'round':rnd,'x':'biometry_rate','y':'pt_share','level':'section_in_uf','uf':uf}))
                for spec,features in [('within_biometry',['biometry_rate']),
                        ('within_adjusted',['biometry_rate','log_eligible','turnout','invalid_fraction']),
                        ('within_adjusted_timing',['biometry_rate','log_eligible','turnout','invalid_fraction','close_asinh_minutes'])]:
                    for weighting in ['equal_section','attendance']:
                        t=q.dropna(subset=features+['pt_share'])
                        if len(t)<100:continue
                        res=cluster_ols(t.pt_share,t[features],t.municipality_key,
                            t.attendance if weighting=='attendance' else None,True)
                        for j,term in enumerate(features):
                            scale=10 if term=='biometry_rate' else 100
                            models.append({'year':year,'round':rnd,'spec':spec,'weighting':weighting,'term':term,
                                'coefficient':res['beta'][j],'se_cluster_municipality':res['se'][j],
                                'effect_pp_per_10pp_biometry' if term=='biometry_rate' else 'effect_pp_per_unit':res['beta'][j]*scale,
                                'interval_lower_scaled':res['lower'][j]*scale,'interval_upper_scaled':res['upper'][j]*scale,
                                'n':res['n'],'clusters':res['clusters'],'within_r2':res['r2']})
                z=q.dropna(subset=['biometry_rate']).copy()
                z['biometry_bin']=pd.cut(z.biometry_rate,[-.000001,0,.02,.04,.06,.08,.10,.15,.25,1],include_lowest=True)
                for interval,g in z.groupby('biometry_bin',observed=True):
                    bins.append({'year':year,'round':rnd,'bin':str(interval),'sections':len(g),'attendance':g.attendance.sum(),
                        'biometry_rate':g.biometry_without_auth.sum()/g.attendance.sum(),
                        'pt_share':g.pt_votes.sum()/g.nominal_votes.sum(),'mean_close_minutes':g.close_seconds_after_ordinary_deadline.mean()/60})
                for party,vcol in [('PT','pt_votes'),('largest_other','opponent_votes')]:
                    for minimum in [1,10]:
                        s=q[q.nominal_votes>=minimum].copy();v=s[vcol];n=s.nominal_votes
                        ext={'year':year,'round':rnd,'candidate_group':party,'minimum_valid_votes':minimum,
                            'sections':len(s),'unanimous':int((v==n).sum()),'above90':int((v/n>.9).sum()),
                            'unanimous_median_valid':float(n[v==n].median()) if (v==n).any() else np.nan,
                            'above90_median_valid':float(n[v/n>.9].median()) if (v/n>.9).any() else np.nan}
                        for group in ['municipality_key','zone_key']:
                            gn=s.groupby(group,observed=True).nominal_votes.transform('sum')-n
                            gv=s.groupby(group,observed=True)[vcol].transform('sum')-v
                            p=(gv/gn).where(gn>0)
                            keep=p.between(0,1)
                            expected=np.power(p[keep],n[keep])
                            ext[f'illustrative_loo_{group}_expected_unanimous']=expected.sum()
                            ext[f'illustrative_loo_{group}_supported_sections']=int(keep.sum())
                        extremes.append(ext)
                    for uf,g in q.groupby('uf'):
                        geo_extremes.append({'year':year,'round':rnd,'candidate_group':party,'uf':uf,'sections':len(g),
                            'unanimous':int((g[vcol]==g.nominal_votes).sum()),'above90':int((g[vcol]/g.nominal_votes>.9).sum())})
                    for mincount in [1,10]:
                        v=q.loc[q[vcol]>=mincount,vcol].to_numpy(np.int64)
                        first=(v//(10**np.floor(np.log10(v)).astype(int))).astype(int)
                        count=np.bincount(first,minlength=10)[1:10]
                        expected=np.log10(1+1/np.arange(1,10))
                        for digit,c,e in zip(range(1,10),count,expected):
                            digits.append({'year':year,'round':rnd,'candidate_group':party,'minimum_count':mincount,
                                'digit':digit,'count':c,'n':len(v),'fraction':c/len(v),'benford_fraction':e,
                                'MAD':float(np.mean(np.abs(count/len(v)-expected)))})
            self.checkpoint('summarized_'+str(year))
        for name,records in [('coverage',quality),('national-summary',summaries),('correlations',cors),
            ('within-municipality-models',models),('biometry-bins',bins),('extreme-sections',extremes),
            ('extreme-sections-uf',geo_extremes),('first-digit-diagnostics',digits)]:self.table(name,records)

    def paired(self,a,b,keys=KEY):
        cols=list(dict.fromkeys(keys+['polling_place','aggregated_sections','eligible','attendance','pt_votes','nominal_votes',
            'biometry_without_auth','biometry_rate','pt_share','turnout','log_eligible','close_seconds_after_ordinary_deadline']))
        return a[cols].merge(b[cols],on=keys,suffixes=('_a','_b'),how='inner',validate='one_to_one')

    def panels(self):
        pairing=[];pc=[];pm=[];pe=[]
        elections={y:self.load(y) for y in YEARS}
        for y,d in elections.items():elections[y]=d[(d.uf!='ZZ') & d.usable_turnout & d.nominal_votes.gt(0)].copy()
        specifications=[(y,1,y,2) for y in [2014,2018,2022,2026]]+[(a,2,b,2) for a,b in [(2014,2018),(2018,2022),(2022,2026)]]
        specifications += [(2022,1,2024,1),(2024,1,2026,1)]
        for ya,ra,yb,rb in specifications:
            a=elections[ya].query('round==@ra');b=elections[yb].query('round==@rb'); p=self.paired(a,b)
            label=f'{ya}-{ra}t_to_{yb}-{rb}t';p['municipality_key']=p.uf+':'+p.municipality.astype(str)
            sameplace=p.polling_place_a.eq(p.polling_place_b)&p.aggregated_sections_a.fillna('').eq(p.aggregated_sections_b.fillna(''))
            stable=sameplace & ((p.eligible_b-p.eligible_a).abs()/p.eligible_a.replace(0,np.nan)<=.05)
            p['d_biometry']=p.biometry_rate_b-p.biometry_rate_a;p['d_pt_share']=p.pt_share_b-p.pt_share_a
            p['d_turnout']=p.turnout_b-p.turnout_a;p['d_log_eligible']=p.log_eligible_b-p.log_eligible_a
            p['attendance']=p.attendance_b
            p['same_place_aggregation']=sameplace;p['stable_electorate_5pct']=stable
            p.to_parquet(self.out/f'panel-{label}.parquet',index=False,compression='zstd')
            for subset,mask in [('exact_key',np.ones(len(p),bool)),('same_place_aggregation',sameplace),('stable_electorate_5pct',stable)]:
                z=p[mask]; ctx={'comparison':label,'subset':subset,'primary_year':yb}
                pairing.append({**ctx,'earlier_sections':len(a),'later_sections':len(b),'matched':len(z),
                    'earlier_unmatched_or_excluded':len(a)-len(z),'later_unmatched_or_excluded':len(b)-len(z),
                    'share_later_attendance':z.attendance_b.sum()/b.attendance.sum(),
                    'mean_biometry_change_pp':100*z.d_biometry.mean(),'mean_pt_share_change_pp':100*z.d_pt_share.mean() if 2024 not in (ya,yb) else np.nan})
                pairs=[('biometry_rate_a','biometry_rate_b'),('turnout_a','turnout_b'),
                    ('close_seconds_after_ordinary_deadline_a','close_seconds_after_ordinary_deadline_b')]
                if 2024 not in (ya,yb):pairs += [('pt_share_a','pt_share_b'),('d_biometry','d_pt_share'),('biometry_rate_a','pt_share_b')]
                for x,y in pairs:
                    pc.append(correlations(z,x,y,{**ctx,'x':x,'y':y,'level':'section'}))
                    if (x,y)==('d_biometry','d_pt_share'):
                        pc.append(correlations(z,x,y,{**ctx,'x':x,'y':y,'level':'section_within_municipality'},group='municipality_key'))
                if 2024 not in (ya,yb):
                    features=['d_biometry','pt_share_a','d_turnout','d_log_eligible']
                    t=z.dropna(subset=features+['d_pt_share'])
                    if len(t)>100:
                        res=cluster_ols(t.d_pt_share,t[features],t.municipality_key,None,True)
                        pm.append({**ctx,'n':res['n'],'clusters':res['clusters'],
                            'delta_pt_pp_per_10pp_delta_biometry':res['beta'][0]*10,
                            'lower':res['lower'][0]*10,'upper':res['upper'][0]*10,'within_r2':res['r2']})
                    for cut in [0.9,1]:
                        ea=z.pt_share_a.gt(cut) if cut<1 else z.pt_share_a.eq(1)
                        eb=z.pt_share_b.gt(cut) if cut<1 else z.pt_share_b.eq(1)
                        pe.append({**ctx,'threshold':cut,'earlier_extreme':int(ea.sum()),'later_extreme':int(eb.sum()),
                            'both':int((ea&eb).sum()),'new_in_later':int((~ea&eb).sum()),
                            'persistence_fraction':(ea&eb).sum()/ea.sum() if ea.any() else np.nan})
            if 2024 not in (ya,yb):
                ga=a.groupby(['uf','municipality'],observed=True).agg(attendance=('attendance','sum'),biometry=('biometry_without_auth','sum'),pt=('pt_votes','sum'),valid=('nominal_votes','sum')).reset_index()
                gb=b.groupby(['uf','municipality'],observed=True).agg(attendance=('attendance','sum'),biometry=('biometry_without_auth','sum'),pt=('pt_votes','sum'),valid=('nominal_votes','sum')).reset_index()
                # Missing biometric fields remain missing, not a group sum of zero.
                for g,source in [(ga,a),(gb,b)]:
                    valid=source.groupby(['uf','municipality'],observed=True).biometry_rate.apply(lambda v:v.notna().all()).rename('bio_complete')
                    g['bio_complete']=pd.MultiIndex.from_frame(g[['uf','municipality']]).map(valid)
                    g['bio_rate']=(g.biometry/g.attendance).where(g.bio_complete)
                    g['share']=g.pt/g.valid
                g=ga.merge(gb,on=['uf','municipality'],suffixes=('_a','_b'),validate='one_to_one');g['attendance']=g.attendance_b
                g['d_biometry']=g.bio_rate_b-g.bio_rate_a;g['d_pt_share']=g.share_b-g.share_a
                for x,y in [('bio_rate_a','bio_rate_b'),('share_a','share_b'),('d_biometry','d_pt_share')]:
                    pc.append(correlations(g,x,y,{'comparison':label,'subset':'municipality_key','x':x,'y':y,'level':'municipality'}))
            self.checkpoint('panel_'+label)
        for n,r in [('panel-coverage',pairing),('panel-correlations',pc),('panel-change-models',pm),('extreme-persistence',pe)]:self.table(n,r)

    def prediction(self):
        a=self.load(2022).query('round==2 and uf!="ZZ"');b=self.load(2026).query('round==2 and uf!="ZZ"');first=self.load(2026).query('round==1 and uf!="ZZ"')
        p=self.paired(a[a.usable_turnout],b[b.usable_turnout]);p=p.merge(first[KEY+['pt_share','biometry_rate']],on=KEY,validate='one_to_one')
        p=p.dropna(subset=['pt_share_a','pt_share_b','pt_share','biometry_rate_a','biometry_rate_b','biometry_rate','log_eligible_b','turnout_b'])
        p['fold']=[int(hashlib.sha256(f'{SEED}:{u}:{int(m)}'.encode()).hexdigest()[:8],16)%5 for u,m in zip(p.uf,p.municipality)]
        p['constant']=1.
        dummies=pd.get_dummies(p.uf,prefix='uf',drop_first=True,dtype=float)
        p=pd.concat([p,dummies],axis=1)
        common=['constant','pt_share_a','log_eligible_b','turnout_b']+list(dummies)
        specs={'history':common,'history_and_first_round':common+['pt_share'],
            'history_first_round_prior_biometry':common+['pt_share','biometry_rate_a','biometry_rate'],
            'plus_current_biometry':common+['pt_share','biometry_rate_a','biometry_rate','biometry_rate_b']}
        rows=[];predictions=p[KEY+['pt_share_b','attendance_b','fold']].copy()
        for weighting in ['equal_section','attendance']:
            w=np.ones(len(p)) if weighting=='equal_section' else p.attendance_b.to_numpy(float)
            for spec,features in specs.items():
                predicted=np.full(len(p),np.nan);x=p[features].to_numpy(float);y=p.pt_share_b.to_numpy(float)
                for fold in range(5):
                    train=p.fold.ne(fold).to_numpy();test=~train
                    beta=np.linalg.lstsq(x[train]*np.sqrt(w[train,None]),y[train]*np.sqrt(w[train]),rcond=None)[0]
                    predicted[test]=x[test]@beta
                error=y-predicted
                rows.append({'weighting':weighting,'spec':spec,'n':len(p),'municipalities':p.groupby(['uf','municipality']).ngroups,
                    'oof_rmse_pp':100*np.sqrt(np.average(error**2,weights=w)),
                    'oof_mae_pp':100*np.average(np.abs(error),weights=w),
                    'oof_r2':1-np.dot(w,error**2)/np.dot(w,(y-np.average(y,weights=w))**2),
                    'outside_unit_interval':int(((predicted<0)|(predicted>1)).sum())})
                predictions[weighting+'_'+spec]=predicted
        self.table('out-of-municipality-prediction',rows)
        predictions.to_parquet(self.out/'prediction-records.parquet',index=False,compression='zstd')
        self.checkpoint('prediction_complete')

    def report_claims(self):
        d=self.load(2026).query('round==2').copy();rows=[]
        for geography in ['all','domestic']:
            q=d if geography=='all' else d[d.uf!='ZZ']
            for timing in ['raw_local','ordinary_deadline_normalized']:
                delta=q.closed_elapsed_seconds-61200 if timing=='raw_local' else q.close_seconds_after_ordinary_deadline
                for label,mask in [('at_or_before_17',delta<=0),('after_17',delta>0),
                    ('17h01_to17h15',delta.between(60,900)),('17h16_to18h59',delta.between(960,7199)),('after19',delta>7200)]:
                    g=q[mask]
                    rows.append({'geography':geography,'timing':timing,'cohort':label,'sections':len(g),
                        'attendance':g.attendance.sum(),'valid':g.nominal_votes.sum(),'pt_votes':g.pt_votes.sum(),
                        'opponent_votes':g.opponent_votes.sum(),'pt_share':g.pt_votes.sum()/g.nominal_votes.sum() if len(g) else np.nan,
                        'opponent_share':g.opponent_votes.sum()/g.nominal_votes.sum() if len(g) else np.nan,
                        'pt_margin':g.pt_votes.sum()-g.opponent_votes.sum()})
        self.table('closure-claim-reproduction',rows)
        self.checkpoint('claim_reproduction_complete')

    def finish(self):
        outputs=[]
        for p in sorted(self.out.glob('*')):
            if p.suffix in ['.csv','.parquet']:
                outputs.append({'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p),
                    'rows':pq.ParquetFile(p).metadata.num_rows if p.suffix=='.parquet' else None})
        self.state['outputs']=outputs;self.state['status']='computed_pending_scientific_review'
        self.checkpoint('computation_finished')


def main():
    study=Study()
    try:
        for y in YEARS:study.build(y)
        study.summaries();study.panels();study.prediction();study.report_claims();study.finish()
    except Exception as e:
        study.state['status']='failed';study.state['error']=repr(e);study.checkpoint('failed');raise


if __name__=='__main__':main()
