"""Build a traceable Portuguese supplement after all extension computations."""
import json,time,html,re
from pathlib import Path
import pandas as pd
import numpy as np
from biometry_history_extension import ROOT,save_json,sha,now
import build_final_scientific_report as renderer

def pt(x,digits=0):
    if pd.isna(x):return 'não disponível'
    return f'{float(x):,.{digits}f}'.replace(',','@').replace('.',',').replace('@','.')

def main():
    def state(name):return json.loads((ROOT/f'reports/{name}.json').read_text())
    source=ROOT/state('biometry-history-computation-state')['output']
    review=ROOT/state('biometry-history-review-state')['output']
    profiles=ROOT/state('biometry-profile-analysis-state')['output']
    pstate=state('biometry-profile-state')
    if pstate['status']!='complete' or pstate['completed']!=84 or pstate['errors']:raise ValueError('Profiles incomplete')
    if not state('biometry-history-review-state')['checks_passed']:raise ValueError('Numerical review not passed')
    out=ROOT/'analysis/extensions/biometry-history-v1'/('report-'+str(time.time_ns()));out.mkdir()
    tables={};inputs=[]
    def read(folder,name):
        f=folder/(name+'.csv');inputs.append({'path':str(f.relative_to(ROOT)),'sha256':sha(f)});return pd.read_csv(f)
    def tab(name,title,headers,rows,note):tables[name]={'title':title,'headers':headers,'rows':[[str(x) for x in r] for r in rows],'note':note}
    corr=read(source,'correlations');nat=read(source,'national-summary');panel=read(profiles,'panel-correlations');coverage=read(profiles,'panel-coverage')
    adjusted=read(profiles,'profile-adjusted-models');pcoverage=read(profiles,'profile-coverage');ufcluster=read(profiles,'profile-uf-cluster-sensitivity')
    extremes=read(review,'extreme-definition-sensitivity');pred=read(source,'out-of-municipality-prediction');closure=read(review,'closure-definition-sensitivity')
    reg=read(review,'regional-correlations');changes=read(profiles,'panel-change-models');qc=read(source,'coverage')
    regional_models=read(profiles,'regional-profile-adjusted-models')
    envelope=json.loads((review/'hypothetical-biometry-margin-envelope.json').read_text())
    simfolder=ROOT/state('biometry-digit-simulation-state')['output'];sim=read(simfolder,'illustrative-digit-simulations')
    countfolder=ROOT/state('biometry-count-definition-state')['output'];countdefs=read(countfolder,'count-versus-rate-correlations')
    compatibility=read(ROOT/state('biometry-profile-compatibility-state')['output'],'compatible-profile-models')
    n=nat.query('round==2 and overseas==False and year in [2018,2022,2026]')
    rows=[]
    for r in n.itertuples():
        c=corr.query('year==@r.year and round==2 and x=="biometry_rate"');s=c[c.level=='section'].iloc[0];w=c[c.level=='section_within_municipality'].iloc[0]
        rows.append([r.year,pt(s.n),pt(r.biometry_count_valid),pt(r.biometry_rate_valid*100,3)+'%',pt(s.pearson,3),pt(s.spearman,3),pt(w.pearson,3)])
    tab('correlations','Tabela 1. Segundo turno doméstico: biometria e voto no PT',
        ['Ano','Seções com taxa','Não autenticados','Taxa / comparec.','Pearson','Spearman','Pearson no município'],rows,
        'Unidade: seção. Peso igual por seção nas correlações; taxa nacional é a razão entre somas. Não são correlações de contagens brutas. Em 2014 o BWeb analisado não contém o campo biométrico. A correlação interna subtrai as médias municipais das duas variáveis.')
    rows=[]
    for label in ['2014-2t_to_2018-2t','2018-2t_to_2022-2t','2022-2t_to_2026-2t','2026-1t_to_2026-2t']:
        p=panel.query('comparison==@label and subset=="exact_key" and x=="pt_share_a"').iloc[0]
        c=coverage.query('comparison==@label and subset=="exact_key"').iloc[0]
        rows.append([label.replace('-2t',' / 2º').replace('-1t',' / 1º').replace('_to_',' → '),pt(p.n),pt(100*c.share_later_attendance,2)+'%',pt(p.pearson,4),pt(p.spearman,4)])
    tab('persistence','Tabela 2. Persistência da votação do PT nas seções ligadas',
        ['Comparação','Seções ligadas','Cobertura do comparecimento posterior','Pearson','Spearman'],rows,
        'Ligação por UF, município, zona e seção; não é acompanhamento dos mesmos indivíduos. Dilma, Haddad e Lula são candidatos diferentes, e as coalizões mudam. Sensibilidades de local/agregação e variação do eleitorado constam das tabelas completas.')
    rows=[]
    for y in [2018,2022,2026]:
        r=adjusted.query('year==@y and round==2 and subset=="strict_place_and_eligible_1pct" and weighting=="equal_section" and term=="biometry_rate"').iloc[0]
        u=ufcluster.query('year==@y and round==2 and subset=="strict_place_and_eligible_1pct" and weighting=="equal_section"').iloc[0]
        rows.append([y,pt(r.n),pt(r.effect_pp_per_10pp,3),f'[{pt(r.lower_scaled,3)}; {pt(r.upper_scaled,3)}]',f'[{pt(u.lower,3)}; {pt(u.upper,3)}]'])
    tab('profiles','Tabela 4. Associação ajustada dentro do município',
        ['Ano','Seções vinculadas','p.p. no voto / +10 p.p. na taxa','Intervalo por município','Intervalo por UF'],rows,
        'Controle por cadastro biométrico, proporção de pessoas com 60 anos ou mais, baixa escolaridade, tamanho, comparecimento e votos brancos/nulos. Mesmo local e diferença de até 1% no eleitorado entre produtos. Intervalos de 95% condicionais ao modelo, não intervalos amostrais do censo nem efeitos causais. Agrupamento por UF é sensibilidade com 27 grupos.')
    q=pred.query('weighting=="equal_section"')
    names={'history':'2022 + controles','history_and_first_round':'+ 1º turno de 2026','history_first_round_prior_biometry':'+ biometria anterior','plus_current_biometry':'+ biometria do 2º turno'}
    tab('prediction','Tabela 5. Predição em municípios fora do treino',['Modelo acumulativo','RMSE (p.p.)','Erro absoluto (p.p.)','R² fora do treino','Predições fora de 0-1'],
        [[names[r.spec],pt(r.oof_rmse_pp,4),pt(r.oof_mae_pp,4),pt(r.oof_r2,5),pt(r.outside_unit_interval)] for r in q.itertuples()],
        '460.290 seções de 5.551 municípios, cinco partições fixadas por município. A especificação inicial inclui voto de 2022, UF, tamanho e comparecimento de 2026; é previsão retrospectiva. Predições lineares fora de 0-1 são contadas, não truncadas. Avaliação com peso por comparecimento também está disponível. DF fica sem exemplo da própria UF no treino; a sensibilidade que o exclui da avaliação é apresentada no apêndice.')
    rows=[]
    for y in [2014,2018,2022,2026]:
        a=extremes.query('year==@y and geography=="domestic" and candidate=="PT"').iloc[0];b=extremes.query('year==@y and geography=="domestic" and candidate=="opponent"').iloc[0]
        rows.append([y,pt(a.unanimous),pt(b.unanimous),pt(a.above90),pt(b.above90),pt(a.median_valid_unanimous,1)])
    tab('extremes','Tabela 6. Extremos históricos de votação, segundo turno doméstico',['Ano','100% PT','100% adversário','>90% PT','>90% adversário','Mediana de válidos nas unânimes PT'],rows,
        'Somente seções com votos válidos positivos. O patamar estrito >90% é diferente de >=90%. O candidato adversário é identificado pelo total nacional de votos, sem supor identidade política constante entre anos.')
    claim_rows=[
        ['499.205 seções / 128.236.074','Reproduzido','O segundo número é comparecimento; votos válidos são 124.082.273.'],
        ['8.632.488 sem autenticação biométrica','Reproduzido','6,7317% do comparecimento total; 6,7518% do doméstico. Não identifica votos ilegais.'],
        ['52,39% para Flávio até 17h','Reproduzido com convenção','Até 17:00:59, horário local: 52,3949%; corte literal 17:00:00: 59,7212%.'],
        ['Vantagem de >6,1 milhões depois','Reproduzido com convenção','6.177.738 na coorte que fecha a partir de 17:01, contando todos os seus votos.'],
        ['339.593 seções entre 17:01 e 17:15','Reproduzido','Inclui até 17:15:59; comparecimento 88.071.750.'],
        ['2.472 seções entre 17:16 e 18:59','Reproduzido','Comparecimento 674.799; participação PT 57,1648%, ante 57,21% publicado.'],
        ['6.333 seções depois de 19h','Não reproduzido exatamente','6.326 no corte estrito, 6.342 incluindo 19:00:00. Não foi inferida a causa da diferença.'],
        ['106 x 4 unânimes','Reproduzido','Total nacional; não é prova autônoma de irregularidade.'],
        ['6.899 x 384 acima de 90%','Reproduzido como >=90%','Com corte estrito e exterior: 6.816 x 378; doméstico: 6.802 x 368.']]
    tab('claims','Tabela 7. Auditoria das alegações quantitativas do post',['Alegação','Conferência','Definição / ressalva'],claim_rows,
        'Sete páginas do relatório foram preservadas com hash. O autor não disponibilizou código executável ou os gráficos estatísticos mencionados nessas páginas. Diferentes versões ou regras podem explicar resíduos, mas essa hipótese não foi tratada como fato.')
    rows=[]
    for uf in ['AL','CE','PE','SP','AM','RS']:
        a=reg.query('year==2026 and uf==@uf and level=="within_uf"').iloc[0];b=reg.query('year==2026 and uf==@uf and level=="within_municipality"').iloc[0]
        rows.append([uf,pt(a.n),pt(a.pearson,3),pt(b.pearson,3)])
    tab('regional','Tabela 3. Heterogeneidade regional ilustrativa',['UF','Seções','Correlação na UF','Dentro dos municípios'],rows,
        'Seleção explícita de exemplos positivos e negativos; a tabela completa contém as 27 UFs e três eleições. Não se atribui causalidade nem se seleciona um único resultado significativo.')
    rows=[]
    for r in pcoverage.query('round==2').itertuples():rows.append([r.year,'Código' if r.subset=='key_link' else 'Local + aptos ±1%',pt(r.matched),pt(100*r.share_bweb_attendance,3)+'%',pt(r.count_exceeds_enrolled),pt(r.zero_enrolled_positive_non_auth)])
    tab('profile_coverage','Tabela A1. Vinculação dos perfis cadastrais',['Ano','Restrição','Seções','Cobertura comparec.','Contagem > cadastrados','Cadastro zero / contagem positiva'],rows,
        'Perfil refere-se a elegíveis cadastrados, BWeb a pessoas que compareceram. Migração cadastral, BIOEX, agregação e datas podem produzir incompatibilidades. Casos são contabilizados e não classificados automaticamente como fraude. A taxa condicional entre votantes com biometria permanece não observada.')
    rows=[]
    for r in coverage.query('comparison in ["2018-2t_to_2022-2t","2022-2t_to_2026-2t"]').itertuples():
        c=panel.query('comparison==@r.comparison and subset==@r.subset and x=="pt_share_a"').iloc[0]
        rows.append([r.comparison.replace('-2t','').replace('_to_',' → '),r.subset,pt(r.matched),pt(100*r.share_later_attendance,2)+'%',pt(c.pearson,4)])
    tab('linkage','Tabela A3. Sensibilidade da persistência eleitoral',['Anos','Restrição','Seções','Cobertura posterior','Pearson PT'],rows,
        'Listas de seções agregadas foram comparadas por identidade numérica, retirando zeros à esquerda. A primeira rodada, que retinha a grafia original, foi preservada. Em 2014 falta informação comparável de local para a restrição entre anos; ausência de vínculo sob esse critério não significa ausência de seção.')
    rows=[]
    for r in changes.query('comparison=="2022-2t_to_2026-2t"').itertuples():rows.append([r.subset,pt(r.n),pt(r.delta_pt_pp_per_10pp_delta_biometry,4),f'[{pt(r.lower,4)}; {pt(r.upper,4)}]'])
    tab('changes','Tabela A4. Mudanças de 2022 a 2026, comparação interna ao município',['Restrição','Seções','p.p. no voto / +10 p.p. na taxa','Intervalo de modelo'],rows,
        'Regressão da mudança do voto sobre mudança da taxa, voto anterior, mudança no comparecimento e log do eleitorado; efeitos municipais. Pode haver erro de mensuração, mudanças demográficas e confundidores. Não é diferenças-em-diferenças causal.')
    rows=[]
    for y in [2018,2022,2026]:
        c=corr.query('year==@y and round==2 and x=="close_asinh_minutes"');a=c[c.level=='section'].iloc[0];b=c[c.level=='section_within_municipality'].iloc[0]
        rows.append([y,pt(a.n),pt(a.pearson,4),pt(b.pearson,4),pt(a.spearman,4)])
    tab('closure_history','Tabela A6. Encerramento e voto no PT nos segundos turnos',['Ano','Seções','Pearson nacional','Pearson no município','Spearman nacional'],rows,
        'Atraso normalizado pelo prazo ordinário, transformado por asinh em minutos. Em 2018 o prazo doméstico era 17h local; em 2022/2026, 17h de Brasília com conversão municipal. Encerramento não é horário do último voto nem exposição causal à extensão.')
    rows=[]
    for (y,c),g in sim.groupby(['year','candidate_group']):rows.append([y,'PT' if c=='PT' else 'Adversário',f'{pt(g.MAD.min(),4)} a {pt(g.MAD.max(),4)}',f'{pt(g.unanimous.min())} a {pt(g.unanimous.max())}'])
    tab('digit_simulation','Tabela A5. Modelo artificial de contagens por seção',['Ano','Candidato','MAD de primeiro dígito','Seções unânimes simuladas'],rows,
        'Cinco simulações binomiais com semente fixa, tamanhos observados e proporção municipal calculada sem a própria seção. Não se introduz operação de adulteração. Não é modelo validado de eleição limpa, pois condiciona nos dados observados e supõe homogeneidade que falha nos extremos.')
    rows=[]
    for y in [2018,2022,2026]:
        c=countdefs.query('year==@y and round==2')
        a=c.query('x=="biometry_without_auth" and y=="pt_votes" and definition=="unadjusted"').iloc[0]
        b=c.query('x=="biometry_rate" and y=="pt_share"').iloc[0]
        d=c.query('definition=="linear_residual_after_attendance"').iloc[0]
        rows.append([y,pt(a.n),pt(a.pearson,4),pt(b.pearson,4),pt(d.pearson,4)])
    tab('count_definitions','Tabela A7. Quantidades e taxas respondem a perguntas diferentes',
        ['Ano','Seções','Contagens brutas','Taxa e proporção','Contagens ajustadas por comparecimento'],rows,
        'Segundo turno doméstico, Pearson. Contagens: não autenticados versus votos PT. Taxas: não autenticados/comparecimento versus votos PT/válidos. Última coluna: resíduos das duas contagens após regressão linear separada sobre comparecimento, com intercepto. Não é correção causal nem estimativa de irregularidade.')
    tab('regional_profiles','Tabela A2. Modelos com perfis em todas as UFs, segundo turno de 2026',
        ['UF','Seções','Municípios','p.p. no voto / +10 p.p. na taxa','Intervalo por município'],
        [[r.uf,pt(r.n),pt(r.clusters),pt(r.effect_pp_per_10pp_biometry,3),
          f'[{pt(r.lower,3)}; {pt(r.upper,3)}]' if pd.notna(r.lower) else 'Não calculável: um grupo']
         for r in regional_models.query('year==2026').itertuples()],
        'Mesma especificação estrita com cadastro, idade, escolaridade e controles operacionais; pesos iguais por seção. Exploração de heterogeneidade sem inferência causal e sem seleção de significância. No DF há um único grupo municipal; o intervalo agrupado por município não é identificável por essa fórmula.')
    # Build report prose from tested tables, with every important number traceable.
    r26=adjusted.query('year==2026 and round==2 and subset=="strict_place_and_eligible_1pct" and weighting=="equal_section" and term=="biometry_rate"').iloc[0]
    cv26=pcoverage.query('year==2026 and round==2 and subset=="strict_place_and_eligible_1pct"').iloc[0]
    refs=[
      {'id':'S1','title':'TSE. Resolução 23.751/2026, identificação do eleitor e fluxo de votação.','url':'https://www.tse.jus.br/legislacao/compilada/res/2026/resolucao-no-23-751-de-26-de-fevereiro-de-2026'},
      {'id':'S2','title':'Justiça Eleitoral. Identificação biométrica, histórico e BIOEX.','url':'https://www.justicaeleitoral.jus.br/biometria/'},
      {'id':'S3','title':'Mebane (2020). Inappropriate Applications of Benford’s Law Regularities to Some Data from the 2020 Presidential Election in the United States.','url':'https://www.umich.edu/~wmebane/inapB.pdf'},
      {'id':'S4','title':'Cameron e Miller (2015). A Practitioner’s Guide to Cluster-Robust Inference. Journal of Human Resources 50(2); versão de trabalho arquivada.','url':'https://www.econ.ucdavis.edu/faculty/cameron/research/Cameron_Miller_JHR_2014_July_09.pdf'},
      {'id':'S5','title':'Deckert, Myagkov e Ordeshook (2011). Benford’s Law and the Detection of Election Fraud. Political Analysis 19, 245-268.','url':'https://doi.org/10.1093/pan/mpr014'},
      {'id':'S6','title':'TSE. Boletins de urna de 2026; mesmos catálogos oficiais de 2014, 2018 e 2022 constam dos manifestos.','url':'https://dadosabertos.tse.jus.br/dataset/resultados-2026-boletim-de-urna'},
      {'id':'S7','title':'TSE. Perfil do eleitorado de 2026; perfis de 2018 e 2022 também processados.','url':'https://dadosabertos.tse.jus.br/dataset/eleitorado-2026'},
      {'id':'S8','title':'Relatório #2 publicado por @Youvebeenpwned_, páginas 1-4. Fonte da alegação, não da mensuração independente.','url':'https://x.com/Youvebeenpwned_/status/2115548464222482516'},
      {'id':'S9','title':'Continuação do relatório, páginas 5-7 e anexo técnico.','url':'https://x.com/Youvebeenpwned_/status/2115548501861884315'}]
    sections=[]
    def sec(title,paragraphs,table=None,figures=None):sections.append({'title':title,'paragraphs':paragraphs,**({'table':table} if table else {}),**({'figures':figures} if figures else {})})
    sec('1. Resposta à pergunta e alcance da extensão',[
      'A relação com eleições anteriores é forte para a geografia da votação e fraca para uma relação específica entre não autenticação biométrica e ganho de votos do PT em 2026. Nas 460.290 seções ligadas de 2022 a 2026, a correlação da participação do PT nos votos válidos é 0,973. A correlação nacional entre a taxa de não autenticação e voto no PT em 2026 é 0,068; dentro do mesmo município, 0,012. A correlação entre as mudanças de ambas as variáveis cai de 0,145 para -0,0027 ao retirar as médias municipais.',
      'Esses resultados enfraquecem a leitura de uma relação forte, nova e uniforme entre não autenticação e o resultado de 2026. Não demonstram que todas as liberações de votação foram regulares, nem identificam a preferência de quem foi liberado sem autenticação biométrica. Associações locais positivas também foram preservadas.',
      'O estudo anterior tratou da prorrogação judicial, horários, participação, diferenças entre turnos e anos e limites para margens eleitorais. Faltava esta auditoria específica das correlações biométricas, unanimidades e dígitos. Este suplemento atende à ampliação solicitada pelo usuário; não apresenta a comparação histórica como algo ausente de todo o estudo anterior.',
      'A extensão é exploratória. O plano foi registrado internamente antes dos primeiros cálculos desta extensão, mas com conhecimento dos resultados do estudo principal e das alegações públicas. Os controles de perfil e as revisões de definições foram adicionados após observar resultados iniciais, com alterações datadas. Não houve cegamento nem pré-registro público.'])
    sec('2. O que o campo biométrico mede',[
      'O BWeb informa pessoas com biometria cadastrada que não foram habilitadas por meio dela. Não é uma lista de todos os eleitores sem biometria, de todas as tentativas falhas do sensor ou de votos ilegais. A análise conta o campo uma vez por seção e turno, usando a linha canônica presidencial; a soma por candidato multiplicaria indevidamente essa contagem. Para 2024 usa-se prefeito apenas como comparação operacional. [S6]',
      'A Resolução 23.751/2026 prevê conferência documental, tentativas de reconhecimento e um procedimento alternativo quando o reconhecimento falha, com ano de nascimento, registro no caderno e habilitação pela digital do mesário. A existência desse procedimento não prova que foi cumprido em cada caso; o total agregado tampouco prova seu descumprimento. [S1]',
      'A taxa principal é a quantidade não autenticada dividida pelo comparecimento. O denominador necessário para medir a probabilidade de falha entre votantes com biometria cadastrada não está observado nessa combinação de produtos. Os perfis adicionais medem cadastro entre elegíveis, não cadastro entre os que de fato compareceram. Mudanças na cobertura biométrica e importações BIOEX limitam a comparação bruta entre anos. [S2, S7]'], 'correlations',['historical-biometry'])
    sections[-1]['paragraphs'].append('Também foram testadas as contagens brutas: em 2026, não autenticados versus votos no PT têm correlação 0,158, comparada a 0,218 em 2018 e 0,127 em 2022. Ao retirar apenas a relação linear de ambas as contagens com o comparecimento da seção, os valores são 0,054, 0,182 e 0,111, respectivamente. Isso evidencia a importância do tamanho da seção; não permite tratar qualquer dessas definições como prova de mecanismo. Todas as combinações de contagens e taxas estão no apêndice e nos derivados.')
    sec('3. A comparação histórica e a estabilidade geográfica',[
      'A persistência cresce de 0,860 entre 2014 e 2018 para 0,950 entre 2018 e 2022 e 0,973 entre 2022 e 2026, nas seções que puderam ser ligadas. Isso descreve estabilidade de padrões territoriais, não identidade de eleitoras e eleitores ao longo dos anos. Reorganização de seções, migração e mudança de candidatos afetam a interpretação.',
      'A ligação de 2022 a 2026 cobre 93,46% do comparecimento doméstico posterior. Restringir a mesmo local e agregação, e depois a variação de no máximo 5% nos aptos, reduz a cobertura; a correlação do voto permanece em torno de 0,973. As perdas estão abertas nas tabelas. A comparação por município também é elevada: 0,989, evitando depender exclusivamente da numeração de seção.',
      'Os segundos turnos municipais de 2024 têm seleção de municípios e candidatos locais. Foram usados para comparação da operação e persistência da taxa biométrica, sem substituir uma eleição presidencial por uma municipal. O esquema BWeb de 2014 não contém o indicador biométrico, portanto ele entra na história do voto e dos extremos, não numa série biométrica artificial de zeros.'], 'persistence',['historical-panel'])
    sec('4. Geografia, controles e relações que não desaparecem',[
      'A agregação muda a resposta. Em 2026, a correlação entre as 27 médias estaduais é 0,377, mas entre seções é 0,068 e entre médias municipais é -0,020. Com peso por comparecimento, os valores também mudam. Não se deve escolher somente o nível que produz a associação desejada.',
      'AL, CE e PE têm associações positivas entre seções; RS, AM e SP têm associações negativas. O anexo inclui todas as UFs, relações internas aos municípios e modelos com perfil. Uma média nacional pequena não significa que todas as associações regionais sejam pequenas. Tampouco uma associação regional forte separa influência do cadastro, composição social, localização e funcionamento da seção.',
      'As relações regionais não desaparecem todas com os controles: no modelo estrito, +10 pontos percentuais na taxa se associam a +0,615 ponto na votação do PT em AL, +0,676 em CE e +0,555 em PE, enquanto no RS a associação é -1,162 ponto. A tabela integral do apêndice inclui as 27 UFs, inclusive estimativas imprecisas. São análises exploratórias de heterogeneidade, não testes confirmatórios de irregularidade.',
      f'No modelo de 2026 com perfis, mesmo local e diferença de até 1% entre os aptos dos dois produtos, +10 pontos percentuais na taxa biométrica se associam a {pt(r26.effect_pp_per_10pp,3)} ponto percentual na votação do PT. O intervalo condicionado ao modelo e agrupado por município é [{pt(r26.lower_scaled,3)}; {pt(r26.upper_scaled,3)}]. O sinal e a precisão devem ser lidos juntamente com as outras especificações, não como um efeito identificado.',
      'Os ajustes incluem características agregadas de idade, escolaridade, cadastro biométrico, tamanho da seção, comparecimento e votos inválidos. Parte desses controles pode ser contemporânea ou afetada pela própria operação. Por isso são análises descritivas de sensibilidade, sem transformar a regressão em prova causal. Intervalos agrupados por UF e pesos por comparecimento estão publicados. [S4]'], 'regional',['regional-correlation'])
    sec('5. Modelos com perfis cadastrais',[
      'Os 84 arquivos estaduais de perfil de 2018, 2022 e 2026 foram lidos em blocos, conferidos contra o inventário auditado e agregados sem guardar os grandes ZIPs no Mac. Os membros CSV foram lidos até o fim, verificando o CRC do ZIP. Datas de geração, chaves ambíguas e divergências de aptos foram registradas; a distinção entre códigos desconhecidos e negativos consta do apêndice.',
      'A especificação estrita exige o mesmo local de votação e diferença relativa de no máximo 1% nos aptos. Isso melhora a compatibilidade entre cadastro e urna, mas seleciona uma população mais estável; não garante identidade individual nem elimina todos os confundidores. A especificação de vínculo por código sem essa restrição permanece disponível.',
      f'No segundo turno de 2026, essa ligação estrita retém {pt(cv26.matched)} seções e {pt(100*cv26.share_bweb_attendance,3)}% do comparecimento doméstico; o modelo efetivamente usa {pt(r26.n)} seções após exigir os campos necessários. As perdas são parte da interpretação, não evidência de ausência de dados brutos.',
      'Os modelos estimam associações entre seções do mesmo município. Os intervalos usam dependência interna ao município; uma versão agrupa por UF para permitir dependência mais ampla. Nenhum desses intervalos mede a incerteza sobre fraude ou o erro de contagem de um censo. A interpretação permanece condicionada ao modelo e à dependência suposta.'], 'profiles')
    sec('6. Mudanças, precedência temporal e previsão',[
      'A mudança na taxa biométrica de 2022 a 2026 tem correlação positiva nacional com a mudança na participação do PT, mas a correlação interna ao município é -0,0027. A regressão de mudanças com voto anterior, mudança no comparecimento e tamanho também é próxima de zero. Não se trata de diferenças-em-diferenças causal: não há atribuição de tratamento nem grupo contrafactual identificado.',
      'A predição é avaliada em municípios inteiros fora do treino. História eleitoral, UF, tamanho e comparecimento produzem erro de 3,7743 pontos percentuais; acrescentar o primeiro turno de 2026 reduz para 2,4427. Acrescentar as taxas biométricas anteriores reduz para 2,3930 e acrescentar a taxa do segundo turno para 2,3925. Há informação associativa adicional, mas o ganho específico do indicador contemporâneo é muito pequeno nesta especificação.',
      'A relação entre fechamento e votação também foi comparada historicamente. A correlação nacional com o atraso transformado do fechamento foi 0,016 em 2018, 0,050 em 2022 e 0,113 em 2026. Dentro do município, foi 0,031, 0,025 e 0,008, respectivamente. Logo, o aumento nacional de 2026 não se traduz na mesma relação quando se compara a operação de seções dentro dos municípios; não foi tratado como efeito da decisão judicial.',
      'O experimento é retrospectivo: inclui covariáveis contemporâneas e não promete antecipar o resultado antes da votação. Modelos não lineares poderiam ter desempenho diferente; não foi feita busca extensa de hiperparâmetros nem usado o melhor resultado de muitas divisões. A separação por município impede que seções do mesmo município apareçam simultaneamente no treino e na validação.'], 'prediction',['historical-prediction'])
    sec('7. Unanimidades, concentrações e Benford',[
      'Os 106 casos unânimes do PT e quatro do adversário em 2026 são reproduzidos. O número de seções domésticas com mais de 90% para o PT diminui de 14.957 em 2018 e 9.424 em 2022 para 6.802 em 2026. Nas seções ligadas entre 2022 e 2026, 5.107 das 5.935 que ultrapassam 90% em 2026 já ultrapassavam esse nível em 2022. Isso não torna cada seção regular, mas contradiz a descrição de um padrão inteiramente novo.',
      'Um modelo binomial ilustrativo que usa a preferência média do restante do município prevê cerca de 0,325 seção unânime para o PT em 2026, diante de 106 observadas. Esse modelo falha também em anos anteriores. O resultado foi preservado: não afirmamos que a média municipal explica integralmente os extremos. Ele pressupõe eleitores independentes e homogêneos no município, hipóteses inadequadas quando há concentração de comunidades e preferências por local. Rejeitar esse modelo não identifica a causa do excesso.',
      'Os primeiros dígitos das contagens de ambos os candidatos desviam de Benford em vários anos. O desvio absoluto médio do PT é 0,0793 em 2026, contra 0,0807 em 2022; para o adversário, 0,0749 contra 0,0712. Não há um resultado binário de fraude nessa comparação. Contagens limitadas pelo tamanho das seções e preferências territorialmente concentradas não recebem automaticamente a distribuição de Benford.',
      'Cinco simulações por ano, sem introduzir operação de adulteração e preservando os tamanhos das seções, produziram MAD de aproximadamente 0,0845 para o PT em 2026, maior que o observado. Isso demonstra que um desvio substancial pode nascer da estrutura de contagens. Não transforma o modelo em padrão-ouro: ele continua subestimando as unanimidades e é condicionado aos agregados observados.',
      'A literatura discute diferentes testes de dígitos e suas condições. A crítica não é que toda técnica forense seja inútil: é que este teste de primeiro dígito precisa de um modelo nulo válido e evidência operacional adicional. Mebane, que desenvolve métodos de análise forense eleitoral, também descreve a inadequação de inferir fraude desses gráficos de primeiro dígito. [S3, S5]'], 'extremes',['extreme-history','first-digit-history'])
    sec('8. O que se reproduz no post e o que a reprodução não prova',[
      'A auditoria tratou o relatório fornecido como alegações a conferir, não como prova nem como algo a descartar por sua autoria. Vários números se reproduzem, mas exigem definições diferentes da leitura literal. A vantagem de 52,39% aparece quando "até 17h" inclui todo o minuto 17:00 e usa o horário local sem normalizar os fusos. O intervalo de 17:01 a 17:15 também inclui o último minuto inteiro. [S8, S9]',
      'Mesmo com essa reprodução, o total da coorte que fecha tarde inclui seus votos depositados durante o dia inteiro. Ele não informa quantos foram depositados depois do prazo e muito menos quantos foram causados pela prorrogação. Nos dados domésticos normalizados, a mesma coorte de fechamento até 17:00:59 dá 50,9917% ao adversário, em vez de 52,3949%. As definições e a exclusão do exterior precisam ser declaradas.',
      'A contagem de 6.899 x 384 se reproduz com pelo menos 90%, incluindo o exterior. Com mais de 90% estritos, são 6.816 x 378. Os resíduos da faixa de 19h e do percentual de 17:16 a 18:59 permanecem documentados; não foram resolvidos ajustando arbitrariamente cortes até coincidir.'], 'claims')
    sec('9. Implicações para o resultado e limites da evidência',[
      'A hipótese de votos adicionais causados pela prorrogação e a hipótese de identificação indevida durante o dia inteiro são diferentes. O estudo principal sustentou a estabilidade das sete margens analisadas sob o mecanismo restrito de participantes adicionais após os cortes e suas sensibilidades. No cenário presidencial conservador com antecipação de 15 minutos e incerteza de contexto, a menor margem ainda era 2.262.970 votos. Isso não é uma certificação de todo mecanismo imaginável de irregularidade.',
      f'Para a hipótese diferente de que uma parte desconhecida dos 8.632.488 comparecimentos não autenticados fosse indevida e adicional, sem alterar as escolhas dos demais, os agregados permitem matematicamente margens entre {pt(envelope["counterfactual_margin_lower"])} e {pt(envelope["counterfactual_margin_upper"])}. O intervalo cruza zero porque não se sabe quais votos pertencem a esse grupo nem se existe qualquer irregularidade nele. Não é estimativa de fraude, probabilidade ou intervalo de confiança.',
      'A possibilidade algébrica exige uma premissa não demonstrada. Para reverter a margem observada apenas removendo participantes adicionais favoráveis ao vencedor, seriam necessários pelo menos 4.430.192 votos líquidos, equivalentes a 51,32% de todo o total não autenticado se todos esses casos favorecessem o vencedor. A análise não observou esses votos indevidos, não atribuiu candidato a nenhum eleitor e não estimou esse percentual como algo ocorrido.',
      'Portanto: os dados temporais e os cenários restritos do estudo principal não sustentam que a prorrogação tenha virado a eleição. As correlações e comparações históricas desta extensão também não fornecem evidência de uma vantagem nova e forte decorrente da não autenticação biométrica. Mas nenhum desses resultados substitui uma auditoria dos procedimentos de identificação, atas e cadernos, se a pergunta passar a ser fraude de identidade em casos concretos.'])
    sec('10. Cobertura, limitações e conclusão proporcional',[
      'As principais limitações são a natureza ecológica das variáveis, o denominador biométrico condicional não observado, alterações de cadastro e códigos, versões dos produtos, dependência territorial, erro de mensuração de relógios e ausência de atribuição causal. Os dados históricos também não são um padrão-ouro externo de regularidade. Persistência pode ser compatível com vários mecanismos; não permite provar ausência universal de irregularidade.',
      'A aquisição principal permanece auditada em 3.388 objetos e 521.157.604.697 bytes. Foram comparados 1.318 companheiros oficiais de hash; 638 objetos tiveram releitura integral na aquisição. A auditoria final não releu todos os grandes arquivos. Permanecem o SHA1 de 2014 indisponível, com seu ZIP preservado, e os dez documentos auxiliares originalmente não arquivados. Textos oficiais consultados pela ferramenta web não foram reclassificados como cópias binárias arquivadas. As novas tentativas HTTP de duas páginas oficiais também retornaram 403, enquanto três documentos metodológicos foram preservados.',
      'Esta extensão entrega medidas de associação, heterogeneidade, persistência e limites explícitos. Não atribui votos individuais, não chama correlação de prova de fraude e não usa uma correlação pequena como prova de integridade total. As tabelas que enfraquecem a hipótese inicial e as associações regionais que não desaparecem estão preservadas junto com o código.'])
    doc={'title':'Biometria, votação e história eleitoral','subtitle':'Suplemento científico à análise da eleição de 2026: correlações, persistência, extremos e limites de inferência',
         'document_status':'Extensão exploratória. Métodos, dados, limitações e revisão documentados no pacote de reprodução. Uso privado.',
         'sections':sections,'references':refs}
    # Keep the established renderer unchanged; this supplement uses exact figure IDs.
    figs=state('biometry-history-figures-state')
    figure_numbers={'historical-biometry':1,'historical-panel':2,'regional-correlation':3,
                    'historical-prediction':4,'extreme-history':5,'first-digit-history':6}
    def supplement_figures(ids,figures):
        for name in ids:
            item=dict(next(i for i in figures['figures'] if i['name']==name))
            item['caption']=re.sub(r'^Figura \d+\.',f'Figura {figure_numbers[name]}.',item['caption'])
            yield ROOT/figures['output_folder'],item
    renderer.figure_items=supplement_figures
    save_json(out/'manuscript.json',doc);save_json(out/'tables.json',tables)
    renderer.build_html(doc,out/'suplemento-biometria-historico.html',tables,figs,now())
    renderer.build_pdf(doc,out/'suplemento-biometria-historico.pdf',tables,figs,now())
    appendix={'title':'Apêndice técnico do suplemento histórico e biométrico','subtitle':'Definições, estimadores, vínculos, hipóteses, revisão e reprodução',
      'document_status':'Parte integrante da extensão exploratória. Não é perícia judicial nem pré-registro público.','references':refs,
      'sections':[
        {'title':'A1. Unidade analítica e integridade','paragraphs':[
          'Uma observação é UF × município × zona × seção × turno × cargo presidencial, ou prefeito em 2024. Os perfis cadastrais são agregados por UF × município × zona × seção × local. As chaves do BWeb foram verificadas como únicas; a soma independente de linhas nominais por candidato coincide exatamente com o total nominal canônico em todos os cinco anos.',
          'O campo biométrico é válido se houver um único valor por seção, sem conflito de metadados e entre zero e comparecimento. Valores ausentes ou sentinelas negativos não viram zero. Em 2018 há quatro campos biométricos ausentes no primeiro turno doméstico e três no segundo; em 2014 o campo está ausente em todo o esquema. O exterior é separado; sentinelas negativos de 2022 e um caso municipal de 2024 estão nas tabelas de cobertura.']},
        {'title':'A2. Perfil cadastral e denominadores','paragraphs':[
          'Leitura dos 84 arquivos já aprovados com Range e If-Match, conferência de tamanho/ETag do inventário e CRC integral do membro CSV. Processamento em blocos de 150 mil linhas, três leitores, sem gravação dos ZIPs brutos. Os totais são soma de QT_ELEITORES_PERFIL ou QT_ELEITORES conforme o ano; QT_ELEITORES_BIOMETRIA é agregado separadamente.',
          'Idade >=60 usa o limite inferior do rótulo da faixa etária, incluindo 100 anos ou mais; rótulos não numéricos permanecem desconhecidos. Baixa escolaridade reúne códigos 1, 2 e 3 (analfabetismo, lê/escreve e fundamental incompleto), com todos os cadastrados no denominador. O código 0 de escolaridade, não informado, permanece nesse denominador, mas não foi somado separadamente. O campo auxiliar originalmente chamado education_unknown conta apenas códigos negativos e foi renomeado education_negative_code na camada vinculada; não se afirma que mede toda a escolaridade desconhecida. Esse campo não é controle dos modelos. Gênero também não foi necessário na especificação principal. Ambiguidade de chave por locais múltiplos é excluída com contagem explícita.',
          'Os cabeçalhos dos perfis de 2018 registram geração em 12/04/2021; os de 2022, em 12/07/2022 ou 26/08/2022; os de 2026, em 14/07/2026. São datas de geração dos produtos arquivados, não prova da data de cada atualização cadastral nem de disponibilidade pública naquele instante. A análise não os apresenta como cópias necessariamente congeladas no dia de cada eleição.',
          'O perfil se refere aos aptos na data de geração, não aos comparecentes. O quociente de não autenticação pelos cadastrados biométricos é apenas uma razão entre produtos, não estimador da probabilidade de falha. Casos em que a contagem excede o cadastro são uma advertência de incompatibilidade, não diagnóstico automático de voto indevido.',
          'Na ligação estrita do segundo turno há 7.452 dessas incompatibilidades em 2018, 1.088 em 2022 e uma em 2026. A causa administrativa não foi estabelecida. Excluindo apenas esses vínculos dos modelos com perfil, a associação por +10 pontos percentuais na taxa passa a +0,436; -0,325; +0,020 ponto percentual no voto, respectivamente, com peso igual. As estimativas originais, os vínculos excluídos e os intervalos da sensibilidade foram preservados. A contagem BWeb original não foi alterada.'], 'table':'profile_coverage'},
        {'title':'A3. Correlações e efeitos fixos','paragraphs':[
          'Pearson usa desvios em torno da média; a versão ponderada usa comparecimento. Spearman é Pearson dos postos médios. Para relações internas ao município, subtraem-se as médias municipais; o Spearman interno é a correlação dos postos desses desvios, não uma média de Spearmans municipais. Sem variação ou sem observações suficientes, não se força coeficiente.',
          'A regressão descritiva utiliza transformação interna ponderada quando cabível. O coeficiente de taxa biométrica é multiplicado por 10 para expressar pontos percentuais no voto por aumento de 10 pontos percentuais na taxa. Os intervalos empregam matriz sanduíche agrupada, correção de graus de liberdade que inclui efeitos municipais e quantil t com número de grupos menos um. A versão agrupada por UF mantém a mesma transformação municipal e usa 27 grupos.',
          'Esses intervalos requerem hipóteses de erro do modelo e independência entre os grupos adotados; 27 UFs não garantem bom comportamento assintótico em qualquer desenho. Não há seleção de significância, ajustes de múltiplos testes usados para declarar fraude nem interpretação amostral das contagens censitárias. Resultados exploratórios, pesos e especificações são publicados integralmente. [S4]']},
        {'title':'A3b. Heterogeneidade regional ajustada','paragraphs':['O ajuste nacional pode ocultar relações regionais em sentidos opostos. A tabela apresenta todas as UFs, sem filtrar os intervalos que excluem zero. A estrutura de dependência e os confundidores variam entre regiões; um intervalo estreito não atribui causalidade.'], 'table':'regional_profiles'},
        {'title':'A4. Ligação histórica e seleção','paragraphs':[
          'A ligação principal usa identidade de códigos. Para estabilidade adicional, exige-se o mesmo local e a mesma lista de seções agregadas, normalizada como conjunto ordenado de inteiros; depois, diferença relativa de aptos de no máximo 5%. Essa sensibilidade já era exploratória no estudo principal. Nesta extensão, a normalização de zeros à esquerda foi registrada antes de recalcular os subconjuntos.',
          'O vínculo exato não implica os mesmos indivíduos e pode sofrer reorganizações não observadas; o subconjunto estável não é representativo automaticamente. Por isso são publicadas as perdas em seções e a fração do comparecimento posterior coberto. A verificação municipal usa somas de votos e comparecimento, não média simples das porcentagens das seções.'], 'table':'linkage'},
        {'title':'A5. Primeiras diferenças e previsão','paragraphs':[
          'A especificação de mudanças inclui diferença na taxa biométrica, participação anterior do PT, diferença no comparecimento e no log dos aptos, com efeitos municipais. Ela mede associação e pode sofrer regressão à média e erros de mensuração correlacionados. Não foi tratada como efeito de tratamento.',
          'A predição usa cinco grupos de municípios, definidos deterministicamente por SHA256 de semente 20261031, UF e código municipal. OLS ou WLS é ajustado nos quatro grupos restantes. Os modelos são cumulativos e os erros são avaliados nas mesmas seções para comparabilidade. Todas as 277 predições lineares fora de 0-1 no modelo final de peso igual foram preservadas e contadas; não houve truncamento seletivo.',
          'A revisão encontrou 6.668 seções do DF cuja UF inteira fica fora do treino na partição 1; seu efeito estadual não pode ser aprendido nesse ajuste. As predições originais foram mantidas. Avaliando apenas as 453.622 seções com UF representada no treino, o RMSE dos quatro modelos de peso igual é 3,7665; 2,4164; 2,3695; 2,3691 pontos percentuais. O incremento contemporâneo permanece pequeno. Essa revisão de suporte foi registrada como exploratória após as predições iniciais e não escolheu uma nova partição.'], 'table':'changes'},
        {'title':'A6. Extremos e primeiro dígito','paragraphs':[
          'Unanimidade exige votos do candidato iguais ao total nominal positivo da seção. Mais de 90% usa desigualdade estrita; pelo menos 90% inclui o ponto de fronteira. As análises de tamanho mínimo usam >=1 e >=10 votos nominais. O cálculo ilustrativo binomial soma p_s elevado a n_s, onde p_s é a preferência dos demais votos do município ou zona, excluindo a própria seção.',
          'O modelo binomial impõe independência e homogeneidade que os dados eleitorais não asseguram. Exceder sua expectativa não diferencia segregação territorial, comunidades politicamente homogêneas, mobilização e irregularidade. Os excessos observados foram publicados mesmo quando enfraquecem uma explicação simples de regularidade.',
          'Para Benford, o primeiro dígito de cada contagem positiva é comparado a log10(1+1/d), d de 1 a 9. O MAD é a média dos desvios absolutos em frequência relativa. Há uma sensibilidade que remove contagens menores que 10. Não foi calculado um p-valor interpretado como probabilidade de fraude; a distribuição nula e a independência não foram estabelecidas. [S3, S5]',
          'A simulação usa Binomial(n_s,p_s), n_s igual aos votos nominais da seção e p_s igual à participação do PT no resto do município. O adversário recebe o complemento n_s menos o sorteio do PT. Cinco repetições por ano usam SeedSequence([20261031,ano,réplica]); os intervalos de mínimos e máximos na tabela são variação dessas cinco simulações, não intervalos de confiança.'], 'table':'digit_simulation'},
        {'title':'A6b. Comparação temporal histórica','paragraphs':['O horário de fechamento é normalizado pelo prazo da eleição e do município. A transformação asinh preserva ordenação e reduz o peso de extremos. A tabela compara associação, não o número de votos depositados tarde. A reconstrução por eventos de conclusão de voto permanece no estudo principal.'], 'table':'closure_history'},
        {'title':'A6c. Definição da correlação biométrica','paragraphs':['A alegação de correlação nas páginas públicas não é acompanhada de código ou tabela que fixe todas as unidades e denominadores. Para não refutar uma definição e omitir outra, foram calculadas quatro combinações: contagem com contagem, taxa com proporção, contagem com proporção e taxa com contagem. A correlação de resíduos lineares pelo comparecimento é um diagnóstico adicional de escala, sem substituir a análise geográfica. Essa extensão metodológica foi registrada antes desses cálculos.'], 'table':'count_definitions'},
        {'title':'A7. Limites para margens: mecanismos diferentes','paragraphs':[
          'No estudo principal, o limite se refere a participantes adicionais após determinado corte, com incertezas de horário/contexto e dados faltantes. Nesta extensão, o envelope biométrico é uma pergunta hipotética distinta, que admite qualquer subconjunto dos não autenticados como indevido e adicional, sem alterar votos dos demais.',
          'Se M é a margem presidencial observada, B_s o total não autenticado, W_s e L_s os votos do vencedor e adversário, então a margem sem um subconjunto hipotético está entre M - soma min(B_s,W_s) e M + soma min(B_s,L_s). As pessoas adicionais podem votar nulo ou branco; não é necessário imputar candidato individual. Os extremos são possíveis sob essas restrições, não estimados como ocorridos.',
          'O intervalo biométrico cruza zero, mas usa uma hipótese sem observação de quais casos seriam indevidos. Ele não contradiz o limite temporal porque trata de mecanismo e população diferentes. Um participante adicional muda a margem por no máximo um voto; troca de escolha de um eleitor já existente é outro mecanismo e não foi misturada ao cálculo.']},
        {'title':'A8. Reprodução, revisão e lacunas','paragraphs':[
          'A sequência executável é: biometry_history_extension.py; review_biometry_history.py; extract_biometry_profiles.py; analyze_biometry_profile_controls.py; simulate_biometry_digit_reference.py; check_biometry_count_definitions.py; review_biometry_prediction_coverage.py; review_profile_count_compatibility.py; plot_biometry_history.py; review_biometry_extension_final.py; build_biometry_history_report.py; document_biometry_extension.py. A extração depende do inventário auditado e de credenciais privadas apenas por referência de arquivo. O relatório pode ser reconstruído dos derivados preservados, sem nova aquisição.',
          'O ambiente e as versões constam de requirements-analysis.txt e do guia de reprodução. Entradas, saídas, planos, alterações, scripts, tabelas e documentos recebem SHA256. O relatório possui revisão numérica independente por operações pandas, testes sintéticos da estatística e da agregação de perfis, verificação das figuras e conferência visual de todas as páginas antes da entrega.',
          'A revisão é interna, sem alegação de parecer independente externo. Não se consultaram cadernos assinados ou atas de todas as seções, não se validou a identidade de cada comparecente e não se recuperou o horário de comunicação judicial por seção. O anexo técnico do post não fornece, nas páginas acessíveis, código, estimativas completas ou um modelo de dados que elimine essas lacunas. [S8, S9]']}
      ]}
    save_json(out/'technical-appendix.json',appendix)
    renderer.build_html(appendix,out/'apendice-biometria-historico.html',tables,figs,now())
    renderer.build_pdf(appendix,out/'apendice-biometria-historico.pdf',tables,figs,now())
    for name,t in tables.items():pd.DataFrame(t['rows'],columns=t['headers']).to_csv(out/(name+'.csv'),index=False)
    save_json(out/'input-manifest.json',{'at':now(),'inputs':inputs,'code_sha256':sha(__file__),'renderer_sha256':sha(ROOT/'scripts/build_final_scientific_report.py')})
    result={'at':now(),'status':'awaiting_visual_and_final_consistency_review','output':str(out.relative_to(ROOT)),'documents':['suplemento-biometria-historico.pdf','suplemento-biometria-historico.html','apendice-biometria-historico.pdf','apendice-biometria-historico.html'],'inputs':inputs,'code_sha256':sha(__file__)}
    save_json(ROOT/'reports/biometry-history-report-state.json',result);save_json(out/'state.json',result)
    print(json.dumps({k:v for k,v in result.items() if k!='inputs'},ensure_ascii=False))

if __name__=='__main__':main()
