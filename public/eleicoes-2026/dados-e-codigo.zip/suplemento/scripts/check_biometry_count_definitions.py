"""Raw count and rate associations answer different descriptive questions."""
import json,time
import numpy as np
import pandas as pd
from biometry_history_extension import ROOT,save_json,sha,now,correlations,weighted_corr

def main():
    source=ROOT/json.loads((ROOT/'reports/biometry-history-computation-state.json').read_text())['output'];out=ROOT/'analysis/extensions/biometry-history-v1'/('count-definitions-'+str(time.time_ns()));out.mkdir()
    rows=[]
    for year in [2018,2022,2026]:
        f=pd.read_parquet(source/f'sections-{year}.parquet');f=f[f.uf.ne('ZZ')&f.biometry_valid&f.nominal_votes.gt(0)&f.attendance.gt(0)]
        for rnd,d in f.groupby('round'):
            for x,y in [('biometry_without_auth','pt_votes'),('biometry_rate','pt_share'),('biometry_without_auth','pt_share'),('biometry_rate','pt_votes')]:
                rows.append(correlations(d,x,y,{'year':year,'round':rnd,'x':x,'y':y,'definition':'unadjusted'}))
            x=np.column_stack([np.ones(len(d)),d.attendance]);a=d.biometry_without_auth.to_numpy(float);b=d.pt_votes.to_numpy(float)
            a=a-x@np.linalg.lstsq(x,a,rcond=None)[0];b=b-x@np.linalg.lstsq(x,b,rcond=None)[0]
            rows.append({'year':year,'round':rnd,'x':'biometry_without_auth','y':'pt_votes','definition':'linear_residual_after_attendance','n':len(d),'pearson':weighted_corr(a,b)})
    d=pd.DataFrame(rows);d.to_csv(out/'count-versus-rate-correlations.csv',index=False);d.to_parquet(out/'count-versus-rate-correlations.parquet',index=False)
    state={'at':now(),'output':str(out.relative_to(ROOT)),'code_sha256':sha(__file__),'interpretation':'Raw counts partly share section size. Neither version establishes individual preference or wrongdoing.'};save_json(out/'state.json',state);save_json(ROOT/'reports/biometry-count-definition-state.json',state)
    print(d.query('round==2')[['year','x','y','definition','pearson']].to_string(index=False))

if __name__=='__main__':main()
