"""Dictionary, evidence matrix and exact reproduction manifest for the supplement."""
import json,time,html
from pathlib import Path
import pyarrow.parquet as pq
import pandas as pd
from biometry_history_extension import ROOT,sha,save_json,now

BASE={
 'year':'Ano da eleição, não ano da geração do arquivo.', 'round':'Turno da eleição.', 'uf':'UF; ZZ representa exterior.',
 'municipality':'Código TSE do município, não código IBGE.', 'municipality_name':'Nome publicado do município.',
 'zone':'Número da zona eleitoral.', 'section':'Número da seção.', 'office':'Código do cargo: 1 presidente, 11 prefeito.',
 'polling_place':'Código de local de votação no BWeb.', 'aggregated_sections':'Lista de seções agregadas no BWeb; normalização numérica é indicada em cada versão.',
 'eligible':'Eleitores aptos no BWeb.', 'attendance':'Comparecimentos no BWeb, incluindo votos não nominais.', 'abstention':'Abstenções no BWeb.',
 'nominal_votes':'Votos nominais válidos para o cargo.', 'blank_votes':'Votos brancos para o cargo.', 'null_votes':'Votos nulos no produto BWeb.',
 'biometry_without_auth':'Pessoas cadastradas com biometria e não habilitadas por ela, contadas uma vez por seção/turno.',
 'distinct_biometry_without_auth':'Quantidade de valores distintos do campo biométrico nas linhas originais da seção/cargo.',
 'metadata_conflict':'Indicador de conflito de metadados entre linhas da seção/cargo.',
 'usable_turnout':'Identidades de comparecimento/aptos/votos consideradas utilizáveis pela revisão canônica.',
 'usable_timing':'Indicador temporal canônico; exclui exterior e horários não utilizáveis.',
 'closed_elapsed_seconds':'Segundos do encerramento desde meia-noite da data de eleição, em horário local; não é horário do último voto.',
 'close_seconds_after_ordinary_deadline':'Encerramento menos prazo ordinário local aplicável, em segundos; comparação municipal de fuso.',
 'open_seconds_after_ordinary_start':'Abertura menos início ordinário local aplicável, em segundos.',
 'machine_type':'CD_TIPO_URNA do BWeb, situação de apuração; não identifica modelo físico da urna.',
 'check_nominal':'Soma independente de votos nominais por candidato conferida contra total canônico.',
 'pt_votes':'Votos no código 13; candidatos mudam entre eleições.', 'pt_share':'Votos código 13 divididos por votos nominais; fração 0-1.',
 'opponent_votes':'Votos do maior candidato não PT na totalização nacional do ano/turno; não identidade partidária constante.',
 'opponent_share':'Votos do adversário divididos por nominais; fração 0-1.', 'opponent_code':'Código do candidato não PT identificado pelo maior total nacional.',
 'biometry_valid':'Campo biométrico único, sem conflito e entre zero e comparecimento.',
 'biometry_rate':'Não autenticados / comparecimento; fração, não probabilidade de falha entre votantes biométricos.',
 'turnout':'Comparecimento / aptos; fração.', 'invalid_fraction':'(Brancos + nulos) / comparecimento.', 'log_eligible':'Logaritmo natural do número de aptos.',
 'close_asinh_minutes':'arcsinh do atraso de encerramento em minutos, para horários utilizáveis.',
 'municipality_key':'UF e código municipal concatenados; unidade de efeito fixo e agrupamento.',
 'zone_key':'UF, município e zona concatenados.', 'candidate':'Código do candidato publicado.', 'votes':'Contagem de votos do candidato no universo indicado.',
 'sections':'Número de seções no universo indicado.', 'overseas':'Verdadeiro para exterior ZZ.',
 'biometry_count_valid':'Soma dos campos biométricos considerados válidos.',
 'biometry_observed_attendance':'Comparecimento das seções com indicador biométrico válido e comparecimento positivo.',
 'biometry_rate_valid':'Razão entre as somas de não autenticação válida e comparecimento observado.',
 'valid_biometry_sections':'Número de seções com campo válido e comparecimento positivo.',
 'positive_biometry_sections':'Número de seções com contagem biométrica positiva.',
 'missing_biometry':'Número de campos biométricos ausentes.', 'negative_biometry':'Número de campos negativos/sentinelas, não convertidos a zero.',
 'biometry_over_attendance':'Número de seções com contagem biométrica maior que comparecimento.',
 'biometry_conflicts':'Número de seções com valores biométricos conflitantes.', 'unusable_turnout':'Seções excluídas por identidade canônica de participação.',
 'zero_attendance':'Número de seções com comparecimento zero.',
 'x':'Nome da variável explicativa/correlacionada.', 'y':'Nome da variável resposta/correlacionada.', 'level':'Escala de agregação ou comparação interna.',
 'n':'Número de observações efetivamente usadas pelo estimador.', 'pearson':'Correlação de Pearson, sem peso salvo indicação.',
 'spearman':'Correlação de postos médios; em modo interno, postos dos desvios municipais.',
 'weighted_pearson':'Pearson ponderado por comparecimento; médias internas também ponderadas quando aplicável.',
 'within_municipality':'Indica retirada das médias municipais antes de calcular o estimador.', 'within':'Indicador de comparação interna ao município.',
 'weight_sum':'Soma dos pesos por comparecimento no estimador.', 'reason':'Motivo de ausência/inaplicabilidade ou observação de auditoria.',
 'spec':'Identificador de especificação do modelo; fórmulas no código e apêndice.', 'weighting':'equal_section: pesos iguais; attendance: pesos por comparecimento.',
 'term':'Variável cuja associação é reportada.', 'coefficient':'Coeficiente em unidades de fração por unidade da variável.',
 'se_cluster_municipality':'Erro padrão da associação sob matriz sanduíche agrupada por município.',
 'effect_pp_per_10pp_biometry':'Mudança associada em pontos percentuais do voto por +10 p.p. na taxa biométrica; não causal.',
 'effect_pp_per_10pp':'Mudança associada em pontos percentuais do voto por +10 p.p. no preditor fracional.',
 'effect_pp_per_unit':'Mudança associada em pontos percentuais do voto por uma unidade do preditor.',
 'effect_pp_per_log_unit':'Mudança associada em pontos percentuais do voto por unidade de log(aptos).',
 'interval_lower_scaled':'Extremo inferior de intervalo condicionado ao modelo, na escala de efeito indicada.',
 'interval_upper_scaled':'Extremo superior de intervalo condicionado ao modelo, na escala de efeito indicada.',
 'lower_scaled':'Extremo inferior de intervalo condicionado ao modelo, escala indicada na linha.',
 'upper_scaled':'Extremo superior de intervalo condicionado ao modelo, escala indicada na linha.',
 'clusters':'Quantidade de grupos de dependência usados na matriz sanduíche.', 'uf_clusters':'Número de UFs na sensibilidade da matriz sanduíche.',
 'absorbed_municipalities':'Quantidade de efeitos fixos municipais retirados.', 'within_r2':'R² dos desvios internos ao município.',
 'bin':'Intervalo da taxa biométrica, com limites no rótulo.', 'mean_close_minutes':'Média do atraso de encerramento em minutos.',
 'candidate_group':'PT ou largest_other/adversário identificado no ano/turno.', 'minimum_valid_votes':'Mínimo de votos válidos para inclusão da seção.',
 'unanimous':'Quantidade de seções com 100% dos votos nominais no candidato e total nominal positivo.',
 'above90':'Quantidade com mais de 90% dos votos nominais, corte estrito.', 'at_least90':'Quantidade com pelo menos 90%, inclui exatamente 90%.',
 'unanimous_median_valid':'Mediana de votos nominais nas seções unânimes.', 'median_valid_unanimous':'Mediana de votos nominais nas seções unânimes.',
 'above90_median_valid':'Mediana de votos nominais nas seções acima de 90%.', 'positive_valid_sections':'Quantidade de seções com votos nominais positivos.',
 'minimum_count':'Mínimo de votos do candidato incluído na análise do primeiro dígito.', 'digit':'Primeiro dígito significativo, 1 a 9.',
 'count':'Contagem na categoria/dígito.', 'fraction':'Frequência relativa na categoria/dígito.',
 'benford_fraction':'log10(1+1/d) para o dígito d.', 'MAD':'Média dos desvios absolutos das nove frequências em relação a Benford; não probabilidade de fraude.',
 'comparison':'Anos e turnos ligados.', 'subset':'Regra de restrição do subconjunto, explícita no código e apêndice.', 'primary_year':'Ano posterior da comparação.',
 'earlier_sections':'Seções elegíveis no período anterior.', 'later_sections':'Seções elegíveis no período posterior.',
 'matched':'Seções vinculadas e que atendem à restrição.', 'earlier_unmatched_or_excluded':'Anterior sem vínculo ou excluída pela restrição.',
 'later_unmatched_or_excluded':'Posterior sem vínculo ou excluída pela restrição.',
 'share_later_attendance':'Comparecimento posterior coberto pelo subconjunto / comparecimento posterior elegível.',
 'mean_biometry_change_pp':'Média simples da mudança da taxa biométrica, em pontos percentuais.',
 'mean_pt_share_change_pp':'Média simples da mudança na participação do PT, em pontos percentuais.',
 'd_biometry':'Taxa biométrica posterior menos anterior, em fração.', 'd_pt_share':'Participação do PT posterior menos anterior, em fração.',
 'd_turnout':'Comparecimento relativo posterior menos anterior.', 'd_log_eligible':'Log(aptos posterior) menos log(aptos anterior).',
 'same_place_aggregation':'Mesmo código de local e identidade da lista de agregações.',
 'stable_electorate_5pct':'Mesmo local/agregação e variação absoluta de aptos <=5% dos aptos anteriores.',
 'delta_pt_pp_per_10pp_delta_biometry':'Coeficiente de primeira diferença: p.p. no voto por +10 p.p. na mudança da taxa.',
 'lower':'Extremo inferior de intervalo de associação condicionado ao modelo, na escala da linha.',
 'upper':'Extremo superior de intervalo de associação condicionado ao modelo, na escala da linha.',
 'threshold':'Limiar de participação eleitoral usado para classificar extremo; 0,9 estrito ou 1 exato.',
 'earlier_extreme':'Quantidade de seções extremas no período anterior.', 'later_extreme':'Quantidade no posterior.',
 'both':'Quantidade extrema nos dois períodos.', 'new_in_later':'Quantidade extrema no posterior e não no anterior.',
 'persistence_fraction':'Extremas nos dois períodos / extremas anteriores.',
 'municipalities':'Número de municípios no estimador.', 'oof_rmse_pp':'Raiz do erro quadrático médio fora do treino, em pontos percentuais.',
 'oof_mae_pp':'Erro absoluto médio fora do treino, em pontos percentuais.', 'oof_r2':'R² fora do treino.',
 'outside_unit_interval':'Quantidade de predições lineares abaixo de zero ou acima de um; mantidas sem truncamento.',
 'fold':'Partição de validação por município, 0 a 4, semente 20261031.',
 'geography':'all inclui exterior; domestic exclui ZZ.', 'timing':'Convenção de hora usada para classificar fechamento.',
 'clock_definition':'Convenção de hora local bruta ou normalizada pelo prazo ordinário.', 'cohort':'Conjunto de seções selecionado pelo horário de fechamento; inclui todos os seus votos.',
 'valid':'Total de votos nominais na coorte.', 'pt_margin':'Votos PT menos votos do adversário na coorte.',
 'registered':'Total cadastrado agregado no perfil, não comparecimento.', 'enrolled':'Total com biometria cadastral no perfil.',
 'age60plus':'Quantidade cadastrada em faixas com limite inferior >=60.', 'age_unknown':'Quantidade cadastrada com faixa etária não interpretável.',
 'low_education':'Cadastrados nos códigos de escolaridade 1, 2 e 3.', 'education_unknown':'Nome legado do extrator: somente códigos negativos de escolaridade, não inclui o código 0 não informado. Não representa a totalidade desconhecida.',
 'education_negative_code':'Cadastrados com código negativo de escolaridade; não inclui código 0 não informado, que permanece no denominador total. Não usado como controle.',
 'female':'Cadastradas no código de gênero 4 no perfil.', 'profile_polling_place':'Código de local no perfil cadastral.',
 'same_place':'Mesmo código de local entre BWeb e perfil.', 'eligible_relative_difference':'|cadastrados do perfil - aptos BWeb| / aptos BWeb.',
 'profile_link_strict':'Mesmo local e diferença relativa nos aptos <=1%.',
 'observed_count_exceeds_enrolled_eligible':'Não autenticação BWeb maior que cadastrados biométricos no perfil; incompatibilidade documentada, sem inferência de causa.',
 'non_auth_per_registered_biometric':'Não autenticação / cadastrados biométricos elegíveis, não taxa de falha entre comparecentes.',
 '_merge':'Resultado da ligação pandas: both ou left_only.', 'profile_records':'Registros de seção/local no perfil agregado.',
 'ambiguous_key_records':'Registros com chave de seção repetida em locais distintos; excluídos da ligação.',
 'enrolled_share':'Biometria cadastrada / total cadastrado no perfil.', 'total_bweb_sections':'Quantidade de seções BWeb elegíveis antes de ligar ao perfil.',
 'share_bweb_attendance':'Comparecimento coberto no vínculo / comparecimento BWeb elegível.',
 'count_exceeds_enrolled':'Seções com não autenticação BWeb maior que cadastrado biométrico do perfil.',
 'zero_enrolled_positive_non_auth':'Seções com cadastro biométrico zero no perfil e não autenticação positiva no BWeb.',
 'median_relative_registered_difference':'Mediana da diferença relativa absoluta de aptos entre produtos.',
 'excluded_uf':'UF retirada nesta análise de sensibilidade.', 'within_municipality_pearson':'Pearson após retirar médias municipais.',
 'status':'Situação de cálculo/auditoria; ausência de estimativa não é efeito zero.',
 'replicate':'Identificador da repetição da simulação, 0 a 4.',
 'definition':'Definição de correlação: bruta ou resíduos após regressões lineares separadas sobre comparecimento, com intercepto.',
 'n_positive':'Número de contagens positivas usadas nos dígitos.',
 'first_digit_fractions':'Vetor JSON de frequências dos primeiros dígitos 1 a 9, na simulação.'
}

def definition(col):
    if col in BASE:return BASE[col]
    for suffix,label in [('_a',' Período anterior.'),('_b',' Período posterior.')]:
        if col.endswith(suffix) and col[:-2] in BASE:return BASE[col[:-2]]+label
    if col.startswith('profile_') and col.endswith('_share'):
        var=col[len('profile_'):-len('_share')]
        if var in BASE:return BASE[var]+' Dividido pelo total cadastrado no perfil; fração.'
    if col.startswith('illustrative_loo_'):
        return 'Diagnóstico binomial ilustrativo com preferência do município/zona excluindo a seção; '+('soma das probabilidades de unanimidade, não expectativa validada de eleição sem fraude.' if col.endswith('expected_unanimous') else 'número de seções com probabilidade leave-one-out definida.')
    if col.startswith('equal_section_') or col.startswith('attendance_'):
        return 'Predição fora do município de treino para a especificação no nome; peso igual por seção ou por comparecimento. Fração de voto no PT, sem truncamento.'
    raise KeyError('No dictionary definition: '+col)

def main():
    paths=[]
    for name in ['biometry-history-computation-state','biometry-history-review-state','biometry-profile-analysis-state','biometry-digit-simulation-state','biometry-count-definition-state','biometry-prediction-coverage-state','biometry-profile-compatibility-state']:
        paths.append(ROOT/json.loads((ROOT/f'reports/{name}.json').read_text())['output'])
    report=ROOT/json.loads((ROOT/'reports/biometry-history-report-state.json').read_text())['output']
    visual_path=ROOT/'reports/biometry-extension-visual-review.json'
    visual=json.loads(visual_path.read_text()) if visual_path.exists() else {}
    visual_ok=visual.get('status')=='passed' and visual.get('report_output')==str(report.relative_to(ROOT))
    records=[]
    for folder in paths:
        for f in sorted(folder.glob('*.parquet')):
            schema=pq.read_schema(f)
            for field in schema:records.append({'dataset':str(f.relative_to(ROOT)),'field':field.name,'storage_type':str(field.type),'definition_pt':definition(field.name)})
        for f in sorted(folder.glob('*.csv')):
            if f.with_suffix('.parquet').exists():continue
            cols=pd.read_csv(f,nrows=0).columns
            for col in cols:records.append({'dataset':str(f.relative_to(ROOT)),'field':col,'storage_type':'CSV (consulte a tabela tipada quando houver)','definition_pt':definition(col)})
    df=pd.DataFrame(records);df.to_csv(report/'dicionario-dados.csv',index=False);df.to_parquet(report/'dicionario-dados.parquet',index=False,compression='zstd')
    matrix=[
      ['B01','O que é não autenticação?','Dicionários oficiais BWeb; coverage.csv; profile-coverage.csv','Contagem operacional reproduzida; denominador condicional não observado','Mensuração e compatibilidade cadastral','Não identifica ilegalidade nem candidato individual','Concluída com limitações explícitas'],
      ['B02','Os números do post se reproduzem?','closure-definition-sensitivity.csv; extreme-definition-sensitivity.csv','Principais totais reproduzidos com minuto inteiro e >=90%; resíduos preservados','Definições e versões','Código original não disponibilizado nas páginas','Concluída; dois resíduos quantitativos documentados'],
      ['B03','Há correlação com voto no PT?','correlations.csv; regional-correlations.csv; profile-adjusted-models.csv','Associação nacional fraca, dependente da agregação; heterogeneidade regional','Modelo, dependência e mensuração','Associação ecológica sem efeito causal','Concluída'],
      ['B04','O padrão se repete historicamente?','panel-correlations.csv; panel-coverage.csv; panel-change-models.csv','Forte persistência do voto e pequena relação interna nas mudanças biométricas','Vínculos, seleção e comparabilidade temporal','Identidade de código não acompanha indivíduos; 2014 sem campo biométrico','Concluída com cobertura por restrição'],
      ['B05','A taxa contemporânea acrescenta previsão?','out-of-municipality-prediction.csv; prediction-records.parquet','Incremento pequeno sobre história e taxas anteriores','Especificação e divisão de validação','Predição retrospectiva não prova causa ou regularidade','Concluída'],
      ['B06','Unanimidades e dígitos demonstram fraude?','extreme-sections.csv; extreme-persistence.csv; first-digit-diagnostics.csv','Extremos históricos e desvios de ambos os candidatos; modelo homogêneo falha','Modelo nulo não validado','Diagnóstico não identifica o mecanismo de uma seção concreta','Concluída; inferência de fraude não identificada'],
      ['B07','A evidência é consistente e sensível às escolhas?','numerical-review.json; testes; profile-uf-cluster-sensitivity.csv','Contagens e correlações conferidas; modelos e pesos publicados','Precisão numérica, mensuração e dependência','Revisão interna; não revisão externa por pares','Revisão numérica e visual concluída' if visual_ok else 'Revisão numérica concluída; revisão visual pendente'],
      ['B08','É reproduzível?','Scripts; hashes; dicionário; artefatos privados','Código e derivados versionados, originais preservados','Dependências e disponibilidade privada','Credenciais não integram a entrega','Documentação concluída; preservação privada verificada em registro próprio'],
      ['B09','Perfis e limites alteram a interpretação?','profile-coverage.csv; profile-adjusted-models.csv; hypothetical-biometry-margin-envelope.json','Controles de cadastro/demografia e envelope lógico de hipótese distinta','Modelo, ligação e identificação parcial','Não estima votos indevidos; intervalo lógico não é IC','Concluída com hipóteses explícitas']]
    columns=['frente','pergunta','evidencia','resultado','incerteza','limitacao','status']
    mx=pd.DataFrame(matrix,columns=columns);mx.to_csv(report/'matriz-pergunta-evidencia.csv',index=False)
    (report/'matriz-pergunta-evidencia.html').write_text('<!doctype html><meta charset="utf-8"><title>Matriz de evidências do suplemento</title><style>body{font-family:Arial;margin:32px;line-height:1.5}td,th{padding:10px;border:1px solid #ccd}table{border-collapse:collapse}th{background:#dcecf1}</style><h1>Matriz pergunta-evidência-resultado</h1>'+mx.to_html(index=False,escape=True))
    guide='''REPRODUÇÃO DO SUPLEMENTO HISTÓRICO E BIOMÉTRICO\n\nEscopo: uso privado, limite total 1 TB, dados originais preservados.\nNão sincronize metadata/private. Credenciais são apenas referência ao arquivo local protegido, perfil tse-research.\n\nNo diretório research/tse-2026, Python: metadata/cloud-venv/bin/python.\nDependências fixadas: scripts/requirements-analysis.txt.\n\n1. scripts/biometry_history_extension.py\n2. scripts/review_biometry_history.py\n3. scripts/extract_biometry_profiles.py (rede privada, leitura em blocos; conferência do inventário)\n4. scripts/analyze_biometry_profile_controls.py\n5. scripts/simulate_biometry_digit_reference.py\n6. scripts/check_biometry_count_definitions.py\n7. scripts/review_biometry_prediction_coverage.py\n8. scripts/plot_biometry_history.py\n9. scripts/review_profile_count_compatibility.py\n10. scripts/review_biometry_extension_final.py\n11. scripts/build_biometry_history_report.py\n12. scripts/document_biometry_extension.py\n\nExecute cada script com o Python indicado, na ordem.\nPara passos S3: AWS_SHARED_CREDENTIALS_FILE aponta ao arquivo protegido; AWS_EC2_METADATA_DISABLED=true. Nunca imprima as credenciais.\nPara figuras: MPLCONFIGDIR=metadata/matplotlib-cache; XDG_CACHE_HOME=metadata/font-cache.\nOs relatórios de estado em reports/biometry-*.json indicam as pastas únicas, hashes e verificações.\nNão execute duplicatas de extratores ativos.\n\nO código não reescreve o acervo bruto. Novas rodadas analíticas criam pastas de saída únicas; o extrator de perfis reutiliza saídas completas somente com hashes de entrada/código iguais.\nO ZIP de entrega contém documentos, tabelas agregadas e código; tabelas por seção e históricos completos permanecem na pasta local e no bucket privado com manifesto de hashes.\n\nMétodos: plano inicial e emendas datadas em analysis/extensions/biometry-history-v1 e analysis/plan-amendments.jsonl. A extensão é exploratória e conhece resultados anteriores.\nA coluna biometry_rate tem denominador comparecimento; profile_enrolled_share usa aptos cadastrados. Nenhuma das duas permite atribuir candidato a eleitor sem autenticação.\nOs intervalos de regressão são condicionais ao modelo; contagens de censo não recebem erro amostral artificial.\nO envelope biométrico é uma hipótese lógica de mecanismo distinto do limite temporal da prorrogação, não uma estimativa de fraude.\n\nRelatório principal anterior: analysis/reports/final/1793441881174112000/.\nRenderização final: Poppler do runtime local; todas as páginas devem ser inspecionadas. Consulte o registro de revisão visual final deste suplemento.\n'''
    (report/'guia-reproducao.txt').write_text(guide)
    files=[]
    for folder in paths:
        for f in sorted(folder.iterdir()):
            if f.is_file():files.append({'path':str(f.relative_to(ROOT)),'bytes':f.stat().st_size,'sha256':sha(f)})
    save_json(report/'manifesto-dados.json',{'at':now(),'files':files,'dictionary_entries':len(df),'unique_fields':df.field.nunique()})
    save_json(ROOT/'reports/biometry-extension-documentation-state.json',{'at':now(),'output':str(report.relative_to(ROOT)),'dictionary_entries':len(df),'unique_fields':df.field.nunique(),'matrix_rows':len(mx),'code_sha256':sha(__file__)})
    print(json.dumps({'dictionary_entries':len(df),'unique_fields':df.field.nunique(),'matrix_rows':len(mx)}))

if __name__=='__main__':main()
