"""Aggregate preserved voter profiles in bounded memory; retain source CRC/digests."""
import json, sys, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import pandas as pd
import numpy as np
from analysis_common import ROOT, inputs, archive, digest, now, atomic_json, require_disk

BASE=ROOT/'analysis/extensions/biometry-history-v1/profiles-v1'
KEY=['SG_UF','CD_MUNICIPIO','NR_ZONA','NR_SECAO','NR_LOCAL_VOTACAO']
NUM=['registered','enrolled','age60plus','age_unknown','low_education','education_unknown','female']

def aggregate_chunk(c):
    qty='QT_ELEITORES' if 'QT_ELEITORES' in c else 'QT_ELEITORES_PERFIL'
    for k in KEY[1:]+[qty,'QT_ELEITORES_BIOMETRIA','CD_FAIXA_ETARIA','CD_GRAU_ESCOLARIDADE','CD_GENERO']:
        c[k]=pd.to_numeric(c[k],errors='raise')
    if (c[qty]<0).any() or (c.QT_ELEITORES_BIOMETRIA<0).any() or (c.QT_ELEITORES_BIOMETRIA>c[qty]).any():
        raise ValueError('Invalid profile cell counts')
    n=c[qty];age=pd.to_numeric(c.DS_FAIXA_ETARIA.str.extract(r'(\d+)',expand=False),errors='coerce');school=c.CD_GRAU_ESCOLARIDADE
    c=c.assign(registered=n,enrolled=c.QT_ELEITORES_BIOMETRIA,
        age60plus=n.where(age.ge(60),0),age_unknown=n.where(age.isna(),0),
        low_education=n.where(school.isin([1,2,3]),0),education_unknown=n.where(school.lt(0),0),
        female=n.where(c.CD_GENERO.eq(4),0))
    return c.groupby(KEY,observed=True,dropna=False)[NUM].sum()

def extract(r):
    out=BASE/str(r['year'])/Path(r['path']).stem;out.mkdir(parents=True,exist_ok=True)
    done=out/'complete.json'
    if done.exists():
        p=json.loads(done.read_text())
        if p['source_sha256']!=r['hashes']['sha256'] or p['code_sha256']!=digest(__file__):raise ValueError('Existing profile version differs')
        if digest(ROOT/p['output'])!=p['output_sha256']:raise ValueError('Output changed')
        return p
    started=now();acc=None;total=0;gens=set();members=[];age_labels=set();education_labels=set()
    with archive(r,block_size=4*1024**2) as (z,stats):
        for i in z.infolist():
            if i.filename.lower().endswith('.pdf'):
                # Small official dictionary, never an entire raw ZIP.
                q=out/Path(i.filename).name
                if not q.exists():q.write_bytes(z.read(i))
            if not i.filename.lower().endswith('.csv'):continue
            with z.open(i) as raw:
                cols=set(KEY+['DT_GERACAO','HH_GERACAO','QT_ELEITORES','QT_ELEITORES_PERFIL','QT_ELEITORES_BIOMETRIA','CD_FAIXA_ETARIA','DS_FAIXA_ETARIA','CD_GRAU_ESCOLARIDADE','DS_GRAU_ESCOLARIDADE','CD_GENERO'])
                for c in pd.read_csv(raw,sep=';',encoding='latin1',dtype=str,usecols=lambda k:k in cols,chunksize=150000,keep_default_na=False):
                    total+=len(c);gens.update(c[['DT_GERACAO','HH_GERACAO']].drop_duplicates().itertuples(index=False,name=None))
                    age_labels.update(c[['CD_FAIXA_ETARIA','DS_FAIXA_ETARIA']].drop_duplicates().itertuples(index=False,name=None))
                    education_labels.update(c[['CD_GRAU_ESCOLARIDADE','DS_GRAU_ESCOLARIDADE']].drop_duplicates().itertuples(index=False,name=None))
                    a=aggregate_chunk(c);acc=a if acc is None else acc.add(a,fill_value=0)
                    atomic_json(out/'progress.json',{'status':'running','at':now(),'input_rows':total,'groups':len(acc),'source':r['path']})
                    require_disk()
            members.append({'name':i.filename,'crc32':f'{i.CRC:08x}','uncompressed_bytes':i.file_size})
    d=acc.reset_index();d[NUM]=d[NUM].astype('int64');p=out/'sections.parquet';d.to_parquet(p,index=False,compression='zstd')
    result={'status':'complete','started_at':started,'completed_at':now(),'source_path':r['path'],'source_sha256':r['hashes']['sha256'],
        'source_etag':r['etag'],'code_sha256':digest(__file__),'read':stats,'members':members,'generation':sorted(gens),
        'input_rows':total,'groups':len(d),'age_labels':sorted(age_labels),'education_labels':sorted(education_labels),'registered':int(d.registered.sum()),'enrolled':int(d.enrolled.sum()),
        'output':str(p.relative_to(ROOT)),'output_sha256':digest(p)}
    atomic_json(done,result);atomic_json(out/'progress.json',result);print(now(),r['path'],total,flush=True);return result

def main():
    BASE.mkdir(parents=True,exist_ok=True)
    rows=[r for r in inputs() if r['year'] in [2018,2022,2026] and r['category']=='perfil_eleitor_secao' and r['path'].endswith('.zip')]
    results=[];errors=[]
    with ThreadPoolExecutor(max_workers=3) as pool:
        tasks={pool.submit(extract,r):r for r in rows}
        for future in as_completed(tasks):
            try:results.append(future.result())
            except Exception as e:errors.append({'path':tasks[future]['path'],'error':repr(e)});print('ERROR',errors[-1],flush=True)
            atomic_json(ROOT/'reports/biometry-profile-state.json',{'at':now(),'status':'running','expected':len(rows),'completed':len(results),'errors':errors,'output':str(BASE.relative_to(ROOT))})
    atomic_json(ROOT/'reports/biometry-profile-state.json',{'at':now(),'status':'complete' if not errors else 'failed','expected':len(rows),'completed':len(results),'errors':errors,'output':str(BASE.relative_to(ROOT)),'records':results})
    if errors:raise RuntimeError('Incomplete profile extracts')

if __name__=='__main__':main()
