"""Package reviewed documents, aggregate tables and code; no credentials/raw ZIPs."""
import json,html,shutil,zipfile
from pathlib import Path
from biometry_history_extension import ROOT,save_json,sha,now

SCRIPTS=['biometry_history_extension.py','review_biometry_history.py','extract_biometry_profiles.py',
 'analyze_biometry_profile_controls.py','review_biometry_extension_final.py','review_biometry_prediction_coverage.py',
 'check_biometry_count_definitions.py','review_profile_count_compatibility.py','simulate_biometry_digit_reference.py','build_biometry_history_report.py',
 'plot_biometry_history.py','document_biometry_extension.py','package_biometry_extension.py',
 'test_biometry_history_extension.py','test_biometry_profiles.py','preserve_biometry_sources.py',
 'build_final_scientific_report.py','analysis_common.py','s3_archive.py','requirements-analysis.txt',
 'publish_analysis_artifacts.py']

def main():
    def state(name):return json.loads((ROOT/f'reports/{name}.json').read_text())
    out=ROOT/state('biometry-history-report-state')['output']
    assert state('biometry-extension-final-review')['status']=='passed'
    assert state('biometry-extension-visual-review')['status']=='passed'
    parent=ROOT/json.loads((ROOT/'reports/analysis-completion.json').read_text())['report_pdf']
    old=out/'estudo-principal';old.mkdir(exist_ok=True)
    for name in ['relatorio-cientifico.pdf','apendice-tecnico.pdf']:
        target=old/name
        if not target.exists():shutil.copy2(parent.parent/name,target)
        if sha(target)!=sha(parent.parent/name):raise ValueError('Main report copy mismatch')
    index='''<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Biometria e eleições passadas</title>
    <style>body{font:17px/1.65 Arial;color:#172737;max-width:900px;margin:55px auto;padding:0 25px}h1{line-height:1.15;color:#123c52}li{margin:8px 0}a{color:#145e80}.note{background:#eef4f6;padding:18px;border-left:4px solid #145e80}</style>
    <h1>Biometria, votação e história eleitoral</h1>
    <p>Extensão científica exploratória, com comparações de 2014, 2018, 2022 e 2026 e comparação operacional municipal de 2024.</p>
    <p class="note">Há forte persistência geográfica do voto. A correlação biométrica depende da definição e da geografia; as associações regionais também estão publicadas. Esses resultados não atribuem candidato a eleitor nem certificam a regularidade de cada procedimento. Os limites da prorrogação e a hipótese distinta de identificação indevida são analisados separadamente.</p>
    <ul><li><a href="suplemento-biometria-historico.html">Ler o suplemento completo</a> · <a href="suplemento-biometria-historico.pdf">PDF</a></li>
    <li><a href="apendice-biometria-historico.html">Apêndice técnico</a> · <a href="apendice-biometria-historico.pdf">PDF</a></li>
    <li><a href="matriz-pergunta-evidencia.html">Matriz de evidências e revisão das nove frentes adicionais</a></li>
    <li><a href="dicionario-dados.csv">Dicionário dos dados (CSV)</a> · <a href="guia-reproducao.txt">Guia de reprodução</a></li>
    <li><a href="suplemento-resultados-e-codigo.zip">Pacote de documentos, tabelas agregadas e código</a></li>
    <li><a href="estudo-principal/relatorio-cientifico.pdf">Estudo principal da prorrogação</a> · <a href="estudo-principal/apendice-tecnico.pdf">Apêndice principal</a></li></ul>
    <p>Uso privado. Os grandes arquivos originais continuam no bucket autorizado. O pacote portátil contém resultados agregados; a reprodução desde os registros por seção depende dos derivados privados descritos nos manifestos.</p></html>'''
    (out/'index.html').write_text(index)
    files={p for p in out.rglob('*') if p.is_file() and p.suffix not in ['.zip'] and 'rendered' not in p.parts}
    paths=[]
    for name in ['biometry-history-computation-state','biometry-history-review-state','biometry-profile-analysis-state',
                 'biometry-digit-simulation-state','biometry-count-definition-state','biometry-prediction-coverage-state','biometry-profile-compatibility-state']:
        st=state(name);folder=ROOT/st['output'];paths.append(folder)
        files.add(ROOT/f'reports/{name}.json')
        for p in folder.iterdir():
            if p.is_file() and (p.suffix=='.csv' or (p.suffix=='.json' and p.stat().st_size<5_000_000)):
                files.add(p)
    figs=ROOT/state('biometry-history-figures-state')['output_folder']
    files.update(p for p in figs.iterdir() if p.is_file())
    for name in SCRIPTS:files.add(ROOT/'scripts'/name)
    for name in ['biometry-extension-final-review','biometry-extension-visual-review','biometry-extension-documentation-state',
                 'biometry-history-report-state','biometry-history-figures-state','biometry-profile-state']:
        files.add(ROOT/f'reports/{name}.json')
    files.add(ROOT/'analysis/extensions/biometry-history-v1/plan.json');files.add(ROOT/'analysis/plan-amendments.jsonl')
    sources=ROOT/'analysis/extensions/biometry-history-v1/sources'
    files.update(p for p in sources.rglob('*') if p.is_file())
    records=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]
    # The archive uses original relative paths so state references stay meaningful.
    bundle=out/'suplemento-resultados-e-codigo.zip'
    if bundle.exists():raise ValueError('Use a new report directory; preserve prior package')
    readme='Abra '+str((out/'index.html').relative_to(ROOT))+'.\n'+(out/'guia-reproducao.txt').read_text()
    with zipfile.ZipFile(bundle,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        z.writestr('LEIA-ME.txt',readme)
        z.writestr('manifesto-pacote.json',json.dumps({'at':now(),'records':records},ensure_ascii=False,indent=2))
        for p in sorted(files):z.write(p,str(p.relative_to(ROOT)))
    with zipfile.ZipFile(bundle) as z:
        if z.testzip() is not None:raise ValueError('ZIP CRC failure')
        import hashlib
        for r in records:
            if hashlib.sha256(z.read(r['path'])).hexdigest()!=r['sha256']:raise ValueError('ZIP member SHA256 failure')
    result={'at':now(),'status':'complete_verified','output':str(out.relative_to(ROOT)),
            'bundle':str(bundle.relative_to(ROOT)),'bundle_bytes':bundle.stat().st_size,'bundle_sha256':sha(bundle),
            'files':len(records),'verification':'Every packaged member reread and SHA256 compared; ZIP CRC verified',
            'code_sha256':sha(__file__),'index':str((out/'index.html').relative_to(ROOT))}
    save_json(ROOT/'reports/biometry-extension-package-state.json',result);print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
