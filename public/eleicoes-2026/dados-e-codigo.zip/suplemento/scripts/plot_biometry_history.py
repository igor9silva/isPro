"""Conventional scientific figures for the historical-biometric extension."""
import json,time
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from biometry_history_extension import ROOT,save_json,now,sha

def main():
    s=json.loads((ROOT/'reports/biometry-history-computation-state.json').read_text());source=ROOT/s['output']
    review=ROOT/json.loads((ROOT/'reports/biometry-history-review-state.json').read_text())['output']
    out=ROOT/'analysis/extensions/biometry-history-v1'/('figures-'+str(time.time_ns()));out.mkdir()
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':120,'savefig.dpi':180})
    figures=[]
    def save(fig,name,caption):
        fig.tight_layout()
        for ext in ['png','svg','pdf']:fig.savefig(out/(name+'.'+ext),bbox_inches='tight')
        plt.close(fig);figures.append({'name':name,'caption':caption})
    n=pd.read_csv(source/'national-summary.csv');n=n.query('round==2 and overseas==False and year!=2024 and year!=2014')
    c=pd.read_csv(source/'correlations.csv');c=c.query('round==2 and x=="biometry_rate" and year!=2014')
    fig,ax=plt.subplots(1,2,figsize=(10,4))
    ax[0].plot(n.year,100*n.biometry_rate_valid,'o-',color='#186b80');ax[0].set(xticks=n.year,ylabel='Não autenticação / comparecimento (%)',xlabel='Ano',title='Taxa operacional no segundo turno',ylim=(0,10))
    for r in n.itertuples():ax[0].annotate(f'{r.biometry_rate_valid*100:.2f}%',(r.year,r.biometry_rate_valid*100),xytext=(0,9),textcoords='offset points',ha='center')
    for level,label,color in [('section','Entre seções','#d17a24'),('section_within_municipality','Dentro do município','#186b80')]:
        q=c[c.level==level];ax[1].plot(q.year,q.pearson,'o-',label=label,color=color)
    ax[1].axhline(0,color='#555',lw=.7);ax[1].set(xticks=n.year,ylabel='Correlação de Pearson com voto no PT',xlabel='Ano',title='Associação fraca e dependente da geografia',ylim=(-.04,.23));ax[1].legend(frameon=False,fontsize=9)
    save(fig,'historical-biometry','Figura 1. Dados domésticos, segundo turno. A taxa tem como denominador o comparecimento, não o número de votantes com biometria cadastrada. Correlações descritivas sem intervalo amostral de censo; 2014 não possui esse campo no esquema analisado.')
    p=pd.read_parquet(source/'panel-2022-2t_to_2026-2t.parquet',columns=['pt_share_a','pt_share_b','d_biometry','d_pt_share'])
    fig,ax=plt.subplots(1,2,figsize=(10,4.4))
    h=ax[0].hexbin(p.pt_share_a*100,p.pt_share_b*100,gridsize=65,bins='log',mincnt=1,cmap='viridis');fig.colorbar(h,ax=ax[0],label='Seções por célula (escala log)')
    ax[0].plot([0,100],[0,100],color='#b65b20',lw=1);ax[0].set(xlabel='PT em 2022 (% válidos)',ylabel='PT em 2026 (% válidos)',title='Persistência: r = 0,973',xlim=(0,100),ylim=(0,100))
    h=ax[1].hexbin(p.d_biometry*100,p.d_pt_share*100,gridsize=65,bins='log',mincnt=1,cmap='viridis');fig.colorbar(h,ax=ax[1],label='Seções por célula (escala log)')
    ax[1].set(xlabel='Mudança na taxa biométrica (p.p.)',ylabel='Mudança na votação do PT (p.p.)',title='Mudanças: r nacional = 0,145')
    save(fig,'historical-panel','Figura 2. 460.290 seções ligadas pelo código territorial, zona e seção. A associação das mudanças é -0,0027 após retirar as médias municipais. Identidade de código não garante composição idêntica do eleitorado; a restrição de local/agregação e eleitorado está nas tabelas de sensibilidade.')
    r=pd.read_csv(review/'regional-correlations.csv').query('year==2026 and level=="within_uf"').sort_values('pearson')
    fig,ax=plt.subplots(figsize=(9,5.6));colors=np.where(r.pearson<0,'#186b80','#c9782d')
    ax.barh(r.uf,r.pearson,color=colors);ax.axvline(0,color='#555',lw=.8);ax.set(xlabel='Correlação entre taxa de não autenticação e voto no PT',title='A associação não tem o mesmo sinal em todas as UFs')
    save(fig,'regional-correlation','Figura 3. Correlação de Pearson entre seções dentro de cada UF no segundo turno de 2026. AL: 0,463; CE: 0,338; SP: -0,131; RS: -0,156. As tabelas incluem também a comparação dentro de municípios. Heterogeneidade descritiva, sem identificação de preferência individual ou fraude.')
    e=pd.read_csv(review/'extreme-definition-sensitivity.csv').query('geography=="domestic"')
    fig,ax=plt.subplots(1,2,figsize=(10,4));years=[2014,2018,2022,2026];x=np.arange(4)
    for candidate,label,dx,col in [('PT','PT',-.18,'#c9782d'),('opponent','Adversário',.18,'#186b80')]:
        q=e[e.candidate==candidate].set_index('year').loc[years]
        for a,field,title in [(ax[0],'unanimous','Seções com 100% dos votos válidos'),(ax[1],'above90','Seções com mais de 90% dos votos válidos')]:
            a.bar(x+dx,q[field],width=.36,label=label,color=col);a.set(xticks=x,xticklabels=years,title=title,ylabel='Número de seções');a.legend(frameon=False)
    save(fig,'extreme-history','Figura 4. Segundo turno doméstico. O candidato do PT e seus adversários mudam entre eleições. Seções com zero voto válido são excluídas. A presença histórica de unanimidade não prova regularidade nem irregularidade de cada seção.')
    dg=pd.read_csv(source/'first-digit-diagnostics.csv').query('round==2 and minimum_count==1')
    fig,ax=plt.subplots(2,2,figsize=(10,7),sharex=True,sharey=True)
    for a,year in zip(ax.flat,years):
        for candidate,label,col in [('PT','PT','#c9782d'),('largest_other','Adversário','#186b80')]:
            q=dg.query('year==@year and candidate_group==@candidate').sort_values('digit');a.plot(q.digit,100*q.fraction,'o-',label=label,color=col)
        a.plot(np.arange(1,10),100*np.log10(1+1/np.arange(1,10)),'--',color='#555',label='Benford');a.set(title=str(year),xticks=range(1,10),xlabel='Primeiro dígito',ylabel='Frequência (%)')
    ax[0,0].legend(frameon=False,fontsize=9)
    save(fig,'first-digit-history','Figura 5. Primeiros dígitos de contagens positivas por candidato/seção, segundo turno doméstico. Desvios ocorrem para ambos os lados e em vários anos. Esta figura não é um teste validado de fraude: tamanhos limitados de seção e concentração de preferências afetam os dígitos.')
    pred=pd.read_csv(source/'out-of-municipality-prediction.csv').query('weighting=="equal_section"')
    fig,ax=plt.subplots(figsize=(9,4));ax.barh(['2022 + controles','+ 1º turno de 2026','+ biometria prévia','+ biometria do 2º turno'],pred.oof_rmse_pp,color=['#8ba8af','#4d8190','#186b80','#c9782d']);ax.invert_yaxis();ax.set(xlabel='Erro quadrático médio fora do município de treino (p.p.)',title='O histórico eleitoral concentra o poder preditivo')
    for i,v in enumerate(pred.oof_rmse_pp):ax.text(v+.035,i,f'{v:.4f}',va='center')
    ax.set_xlim(0,4.3)
    save(fig,'historical-prediction','Figura 6. Cinco partições por município, semente 20261031, 460.290 seções. A última inclusão reduz o erro de 2,3930 para 2,3925 p.p. É previsão retrospectiva descritiva, não causal; a primeira especificação também inclui UF, tamanho e comparecimento contemporâneo.')
    result={'at':now(),'output_folder':str(out.relative_to(ROOT)),'figures':figures,'source':s['output'],'code_sha256':sha(__file__)}
    save_json(ROOT/'reports/biometry-history-figures-state.json',result);save_json(out/'manifest.json',result);print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
