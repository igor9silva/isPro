"""Archive small public methodological and official reference documents."""
import hashlib,json,time
from concurrent.futures import ThreadPoolExecutor
import requests
from biometry_history_extension import ROOT,save_json,now,sha
SOURCES=[
 ('S1','Resolução TSE 23.751/2026, arts. 131-135 e 160','https://www.tse.jus.br/legislacao/compilada/res/2026/resolucao-no-23-751-de-26-de-fevereiro-de-2026','html'),
 ('S2','Justiça Eleitoral: histórico e identificação biométrica','https://www.justicaeleitoral.jus.br/biometria/','html'),
 ('S3','Mebane (2020), Inappropriate Applications of Benford’s Law','https://www.umich.edu/~wmebane/inapB.pdf','pdf'),
 ('S4','Cameron e Miller (2015), A Practitioner’s Guide to Cluster-Robust Inference; versão de trabalho 2014','https://www.econ.ucdavis.edu/faculty/cameron/research/Cameron_Miller_JHR_2014_July_09.pdf','pdf'),
 ('S5','Deckert, Myagkov e Ordeshook (2011), Benford’s Law and the Detection of Election Fraud','https://www.cambridge.org/core/services/aop-cambridge-core/content/view/3B1D64E822371C461AF3C61CE91AAF6D/S1047198700012808a.pdf/benfords_law_and_the_detection_of_election_fraud.pdf','pdf')]

def main():
 out=ROOT/'analysis/extensions/biometry-history-v1/sources'/('http-'+str(time.time_ns()));out.mkdir(parents=True)
 def get(item):
  sid,title,url,ext=item;record={'id':sid,'title':title,'url':url,'attempted_at':now()}
  try:
   response=requests.get(url,timeout=(20,60),stream=True);record['http_status']=response.status_code
   if response.status_code==200:
    content=bytearray()
    for block in response.iter_content(1024*1024):
     content.extend(block)
     if len(content)>20*1024**2:raise ValueError('Reference exceeds small-document limit')
    if ext=='pdf' and not content.startswith(b'%PDF'):raise ValueError('Not a PDF')
    p=out/(sid+'.'+ext);p.write_bytes(content);record.update(path=str(p.relative_to(ROOT)),bytes=len(content),sha256=sha(p),status='archived')
   else:record['status']='not_archived_http_error'
  except Exception as e:record.update(status='not_archived_error',error=repr(e))
  return record
 with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(get,SOURCES))
 save_json(out/'ledger.json',{'at':now(),'sources':results});save_json(ROOT/'reports/biometry-extension-source-state.json',{'at':now(),'path':str((out/'ledger.json').relative_to(ROOT)),'sources':results})
 print(json.dumps(results,ensure_ascii=False))

if __name__=='__main__':main()
