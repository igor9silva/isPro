"""Independent numerical checks of the exploratory extension, without raw writes."""
import json,time
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import t as student_t
from biometry_history_extension import ROOT,save_json,sha,now

def main():
    def state(name):return json.loads((ROOT/f'reports/{name}.json').read_text())
    source=ROOT/state('biometry-history-computation-state')['output']
    profile=ROOT/state('biometry-profile-analysis-state')['output']
    counts=ROOT/state('biometry-count-definition-state')['output']
    ps=state('biometry-profile-state');checks=[]
    def check(name,passed,**detail):
        checks.append({'name':name,'passed':bool(passed),**detail})
    check('84_profiles_complete_without_errors',ps['completed']==84 and ps['status']=='complete' and not ps['errors'])
    complete=list((ROOT/ps['output']).glob('*/*/complete.json'))
    check('84_unique_profile_archives',len(complete)==84)
    for p in complete:
        d=json.loads(p.read_text());check('profile_hash:'+d['source_path'],sha(ROOT/d['output'])==d['output_sha256'])
    models=pd.read_csv(profile/'profile-adjusted-models.csv');ufmodels=pd.read_csv(profile/'profile-uf-cluster-sensitivity.csv')
    count_table=pd.read_csv(counts/'count-versus-rate-correlations.csv')
    for year in [2018,2022,2026]:
        data=pd.read_parquet(profile/f'linked-profiles-{year}.parquet')
        check(f'unique_linked_section_round_{year}',not data.duplicated(['uf','municipality','zone','section','round']).any())
        features=['biometry_rate','log_eligible','turnout','invalid_fraction','profile_enrolled_share','profile_age60plus_share','profile_low_education_share']
        d=data[(data['round']==2)&data.profile_link_strict].dropna(subset=features+['pt_share']).copy()
        cols=['pt_share']+features
        # pandas group transformation and direct normal equations, independent of centered/cluster_ols.
        within=d[cols]-d.groupby('municipality_key')[cols].transform('mean')
        x=within[features].to_numpy(float);y=within.pt_share.to_numpy(float);n,k=x.shape
        beta=np.linalg.solve(x.T@x,x.T@y);resid=y-x@beta;bread=np.linalg.inv(x.T@x)
        r=models.query('year==@year and round==2 and subset=="strict_place_and_eligible_1pct" and weighting=="equal_section" and term=="biometry_rate"').iloc[0]
        check(f'profile_slope_independent_{year}',abs(beta[0]*10-r.effect_pp_per_10pp)<1e-9,value=float(beta[0]*10))
        absorbed=d.municipality_key.nunique()
        for group,target in [('municipality_key',r),('uf',ufmodels.query('year==@year and round==2 and subset=="strict_place_and_eligible_1pct" and weighting=="equal_section"').iloc[0])]:
            scores=pd.DataFrame(x*resid[:,None]);scores['group']=d[group].to_numpy()
            score=scores.groupby('group').sum().to_numpy();g=len(score)
            cov=bread@(score.T@score)@bread*(g/(g-1))*((n-1)/(n-k-absorbed))
            half=student_t.ppf(.975,g-1)*np.sqrt(cov[0,0])*10
            lo=target.lower_scaled if group=='municipality_key' else target.lower
            hi=target.upper_scaled if group=='municipality_key' else target.upper
            check(f'profile_interval_independent_{year}_{group}',abs(beta[0]*10-half-lo)<1e-8 and abs(beta[0]*10+half-hi)<1e-8,
                  lower=float(beta[0]*10-half),upper=float(beta[0]*10+half))
        original=pd.read_parquet(source/f'sections-{year}.parquet').query('round==2 and uf!="ZZ"').dropna(subset=['biometry_rate','pt_share'])
        r=count_table.query('year==@year and round==2 and x=="biometry_without_auth" and y=="pt_votes" and definition=="unadjusted"').iloc[0]
        check(f'raw_count_correlation_independent_{year}',abs(original.biometry_without_auth.corr(original.pt_votes)-r.pearson)<1e-12)
    p=pd.read_parquet(profile/'panel-2022-2t_to_2026-2t.parquet')
    c=pd.read_csv(profile/'panel-correlations.csv')
    r=c.query('comparison=="2022-2t_to_2026-2t" and subset=="exact_key" and x=="pt_share_a"').iloc[0]
    check('2022_2026_panel_correlation_independent',abs(p.pt_share_a.corr(p.pt_share_b)-r.pearson)<1e-12,n=len(p))
    w=p[['d_biometry','d_pt_share']]-p.groupby('municipality_key')[['d_biometry','d_pt_share']].transform('mean')
    r=c.query('comparison=="2022-2t_to_2026-2t" and subset=="exact_key" and x=="d_biometry" and level=="section_within_municipality"').iloc[0]
    check('within_changes_correlation_independent',abs(w.d_biometry.corr(w.d_pt_share)-r.pearson)<1e-12,value=r.pearson)
    pred=pd.read_parquet(source/'prediction-records.parquet');stats=pd.read_csv(source/'out-of-municipality-prediction.csv')
    check('no_municipality_across_prediction_folds',pred.groupby(['uf','municipality']).fold.nunique().max()==1)
    for r in stats.itertuples():
        weights=pred.attendance_b.to_numpy() if r.weighting=='attendance' else np.ones(len(pred))
        e=pred.pt_share_b-pred[r.weighting+'_'+r.spec]
        rmse=np.sqrt(np.average(e*e,weights=weights))*100
        check('prediction_rmse:'+r.weighting+':'+r.spec,abs(rmse-r.oof_rmse_pp)<1e-10,value=rmse)
    out=ROOT/'analysis/extensions/biometry-history-v1'/('final-review-'+str(time.time_ns()));out.mkdir()
    result={'at':now(),'status':'passed' if all(c['passed'] for c in checks) else 'failed','checks':checks,
            'tests_passed':7,'test_command':'PYTHONPATH=scripts metadata/cloud-venv/bin/python -m unittest test_biometry_history_extension test_biometry_profiles',
            'external_peer_review':False,'source':str(source.relative_to(ROOT)),'profile_analysis':str(profile.relative_to(ROOT)),
            'output':str(out.relative_to(ROOT)),'code_sha256':sha(__file__)}
    save_json(out/'numerical-review.json',result);save_json(ROOT/'reports/biometry-extension-final-review.json',result)
    print(json.dumps({'status':result['status'],'checks':len(checks),'failed':[c for c in checks if not c['passed']]}))
    if result['status']!='passed':raise ValueError('Independent review failed')

if __name__=='__main__':main()
