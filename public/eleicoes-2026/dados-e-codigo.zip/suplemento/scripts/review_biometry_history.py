"""Review explicit claim definitions and mathematical limits, preserving first run."""
import json,time
from pathlib import Path
import numpy as np
import pandas as pd
from biometry_history_extension import ROOT,sha,save_json,now,correlations,centered,weighted_corr

def main():
    source=ROOT/json.loads((ROOT/'reports/biometry-history-computation-state.json').read_text())['output']
    out=ROOT/'analysis/extensions/biometry-history-v1'/('review-'+str(time.time_ns()));out.mkdir()
    d=pd.read_parquet(source/'sections-2026.parquet').query('round==2'); rows=[]
    for geography,q in [('all',d),('domestic',d[d.uf!='ZZ'])]:
        for timing,x in [('raw_local',q.closed_elapsed_seconds),('ordinary_deadline_normalized',q.close_seconds_after_ordinary_deadline+61200)]:
            for label,m in [('exact_le_17',x<=61200),('through_minute_17_00',x<61260),('from_minute_17_01',x>=61260),
                ('17_01_through_17_15',x.between(61260,62159)),('17_16_through_18_59',x.between(62160,68399)),
                ('strict_after_19',x>68400),('at_or_after_19',x>=68400),('from_19_01',x>=68460)]:
                g=q[m]
                rows.append({'geography':geography,'clock_definition':timing,'cohort':label,'sections':len(g),'attendance':g.attendance.sum(),
                    'valid':g.nominal_votes.sum(),'pt_votes':g.pt_votes.sum(),'opponent_votes':g.opponent_votes.sum(),
                    'pt_share':g.pt_votes.sum()/g.nominal_votes.sum() if len(g) else np.nan,
                    'opponent_share':g.opponent_votes.sum()/g.nominal_votes.sum() if len(g) else np.nan,'pt_margin':g.pt_votes.sum()-g.opponent_votes.sum()})
    pd.DataFrame(rows).to_csv(out/'closure-definition-sensitivity.csv',index=False)
    ext=[]
    for year in [2014,2018,2022,2026]:
        f=pd.read_parquet(source/f'sections-{year}.parquet').query('round==2')
        for geography,g in [('all',f),('domestic',f[f.uf!='ZZ'])]:
            for candidate,c in [('PT','pt_share'),('opponent','opponent_share')]:
                ext.append({'year':year,'geography':geography,'candidate':candidate,'positive_valid_sections':int(g.nominal_votes.gt(0).sum()),
                    'unanimous':int(g[c].eq(1).sum()),'above90':int(g[c].gt(.9).sum()),'at_least90':int(g[c].ge(.9).sum()),
                    'median_valid_unanimous':g.loc[g[c].eq(1),'nominal_votes'].median()})
    pd.DataFrame(ext).to_csv(out/'extreme-definition-sensitivity.csv',index=False)
    regional=[]
    for year in [2018,2022,2026]:
        f=pd.read_parquet(source/f'sections-{year}.parquet').query('round==2 and uf!="ZZ"')
        for uf,g in f.groupby('uf'):
            for group in [None,'municipality_key']:
                regional.append(correlations(g,'biometry_rate','pt_share',{'year':year,'uf':uf,'level':'within_municipality' if group else 'within_uf'},group=group))
    pd.DataFrame(regional).to_csv(out/'regional-correlations.csv',index=False)
    q=d[(d.uf!='ZZ')&d.biometry_valid];margin=int(d.pt_votes.sum()-d.opponent_votes.sum())
    max_remove_winner=int(np.minimum(q.biometry_without_auth,q.pt_votes).sum())
    max_remove_runner=int(np.minimum(q.biometry_without_auth,q.opponent_votes).sum())
    bounds={'interpretation':'Logical envelope only. Hypothetical additional wrongful participants are an unknown subset of non-authenticated attendees. No empirical claim that any wrongful participant exists. No change in votes of remaining voters; no impersonation/switching model.',
        'observed_margin':margin,'observed_non_authenticated_attendees':int(q.biometry_without_auth.sum()),
        'max_possible_winner_removal':max_remove_winner,'max_possible_runner_removal':max_remove_runner,
        'counterfactual_margin_lower':margin-max_remove_winner,'counterfactual_margin_upper':margin+max_remove_runner,
        'minimum_net_additional_winner_votes_to_reverse':margin+1,
        'minimum_fraction_of_recorded_non_auth_count_to_reverse_if_all_helped_winner':(margin+1)/q.biometry_without_auth.sum(),
        'warning':'The interval is not a confidence interval, probability or estimate of fraud. It cannot be merged with the late-vote bound: different hypothesized mechanism.'}
    save_json(out/'hypothetical-biometry-margin-envelope.json',bounds)
    # Independent direct pandas checks of core CSV outputs and exact published totals.
    checks=[]
    checks.append({'test':'2026_attendance_all','passed':int(d.attendance.sum())==128236074})
    checks.append({'test':'2026_non_auth_count','passed':int(q.biometry_without_auth.sum())==8632488})
    checks.append({'test':'2026_candidate_margin','passed':margin==4430191})
    p=pd.read_parquet(source/'panel-2022-2t_to_2026-2t.parquet')
    observed=float(p.pt_share_a.corr(p.pt_share_b));expected=pd.read_csv(source/'panel-correlations.csv').query('comparison=="2022-2t_to_2026-2t" and subset=="exact_key" and x=="pt_share_a"').pearson.iloc[0]
    checks.append({'test':'independent_pandas_historical_correlation','passed':abs(observed-expected)<1e-12,'value':observed})
    for y in [2018,2022,2026]:
        f=pd.read_parquet(source/f'sections-{y}.parquet').query('round==2 and uf!="ZZ"').dropna(subset=['biometry_rate','pt_share'])
        expected=pd.read_csv(source/'correlations.csv').query('year==@y and round==2 and x=="biometry_rate" and level=="section"').pearson.iloc[0]
        checks.append({'test':f'independent_pandas_rate_correlation_{y}','passed':abs(float(f.biometry_rate.corr(f.pt_share))-expected)<1e-12})
    save_json(out/'numerical-review.json',{'at':now(),'checks':checks,'all_passed':all(c['passed'] for c in checks)})
    state={'at':now(),'status':'review_computed','source':str(source.relative_to(ROOT)),'output':str(out.relative_to(ROOT)),'code_sha256':sha(__file__),'checks_passed':all(c['passed'] for c in checks)}
    save_json(ROOT/'reports/biometry-history-review-state.json',state);save_json(out/'state.json',state);print(json.dumps(state))

if __name__=='__main__':main()
