"""Report unsupported state fixed effects in municipality-held-out validation."""
import json,time
import numpy as np
import pandas as pd
from biometry_history_extension import ROOT,save_json,sha,now

def main():
    source=ROOT/json.loads((ROOT/'reports/biometry-history-computation-state.json').read_text())['output']
    d=pd.read_parquet(source/'prediction-records.parquet');summary=pd.read_csv(source/'out-of-municipality-prediction.csv')
    supported=np.zeros(len(d),dtype=bool);unsupported=[]
    for fold in sorted(d.fold.unique()):
        train_ufs=set(d.loc[d.fold.ne(fold),'uf']);test=d.fold.eq(fold)
        supported|=(test&d.uf.isin(train_ufs)).to_numpy()
        for uf,g in d[test&~d.uf.isin(train_ufs)].groupby('uf'):
            unsupported.append({'fold':int(fold),'uf':uf,'sections':len(g),'attendance':int(g.attendance_b.sum())})
    results=[]
    for r in summary.itertuples():
        q=d[supported];w=q.attendance_b.to_numpy() if r.weighting=='attendance' else np.ones(len(q))
        e=q.pt_share_b-q[r.weighting+'_'+r.spec]
        results.append({'weighting':r.weighting,'spec':r.spec,'n':len(q),'municipalities':q.groupby(['uf','municipality']).ngroups,
                        'oof_rmse_pp':100*np.sqrt(np.average(e*e,weights=w)),'oof_mae_pp':100*np.average(abs(e),weights=w)})
    out=ROOT/'analysis/extensions/biometry-history-v1'/('prediction-review-'+str(time.time_ns()));out.mkdir()
    pd.DataFrame(results).to_csv(out/'supported-uf-prediction.csv',index=False)
    pd.DataFrame(unsupported).to_csv(out/'unsupported-uf-folds.csv',index=False)
    result={'at':now(),'output':str(out.relative_to(ROOT)),'code_sha256':sha(__file__),'unsupported':unsupported,
            'interpretation':'Original predictions preserved. UF-specific effect cannot be learned when that UF is absent from training; this sensitivity scores only supported UFs. No fitting or hyperparameter selection.'}
    save_json(out/'review.json',result);save_json(ROOT/'reports/biometry-prediction-coverage-state.json',result)
    print(json.dumps(result,ensure_ascii=False));print(pd.DataFrame(results).to_string(index=False))

if __name__=='__main__':main()
