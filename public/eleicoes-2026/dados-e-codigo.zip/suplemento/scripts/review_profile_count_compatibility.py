"""Sensitivity to conflicting biometry counts across two official products."""
import json,time
import pandas as pd
from biometry_history_extension import ROOT,save_json,sha,now,cluster_ols

def main():
    source=ROOT/json.loads((ROOT/'reports/biometry-profile-analysis-state.json').read_text())['output']
    out=ROOT/'analysis/extensions/biometry-history-v1'/('profile-compatibility-'+str(time.time_ns()));out.mkdir()
    features=['biometry_rate','log_eligible','turnout','invalid_fraction','profile_enrolled_share','profile_age60plus_share','profile_low_education_share']
    results=[];exceptions=[]
    for year in [2018,2022,2026]:
        d=pd.read_parquet(source/f'linked-profiles-{year}.parquet')
        q=d[(d['round']==2)&d.profile_link_strict].dropna(subset=features+['pt_share'])
        exc=q[q.observed_count_exceeds_enrolled_eligible]
        exceptions.append(exc[['uf','municipality','zone','section','year','round','attendance','eligible','registered','enrolled','biometry_without_auth','aggregated_sections']])
        q=q[~q.observed_count_exceeds_enrolled_eligible]
        for weighting in ['equal_section','attendance']:
            r=cluster_ols(q.pt_share,q[features],q.municipality_key,q.attendance if weighting=='attendance' else None,True)
            results.append({'year':year,'round':2,'subset':'strict_place_eligible_and_count_compatible','weighting':weighting,'n':r['n'],'clusters':r['clusters'],
                            'effect_pp_per_10pp_biometry':r['beta'][0]*10,'lower':r['lower'][0]*10,'upper':r['upper'][0]*10,'within_r2':r['r2']})
    pd.DataFrame(results).to_csv(out/'compatible-profile-models.csv',index=False)
    ex=pd.concat(exceptions,ignore_index=True);ex.to_csv(out/'profile-count-conflicts.csv',index=False);ex.to_parquet(out/'profile-count-conflicts.parquet',index=False,compression='zstd')
    result={'at':now(),'output':str(out.relative_to(ROOT)),'code_sha256':sha(__file__),'conflicts':ex.groupby('year').size().to_dict(),
            'interpretation':'Cross-product incompatibility is not assigned an administrative cause or classified as wrongdoing. Main raw BWeb estimates remain unchanged. Sensitivity excludes these profile matches only.'}
    save_json(out/'review.json',result);save_json(ROOT/'reports/biometry-profile-compatibility-state.json',result)
    print(json.dumps(result));print(pd.DataFrame(results).to_string(index=False))

if __name__=='__main__':main()
