"""Illustrative constrained-count simulation, never an estimated fraud detector."""
import json,time
import pandas as pd
import numpy as np
from biometry_history_extension import ROOT,save_json,now,sha

def summary(v):
    v=np.asarray(v,dtype='int64');v=v[v>0]
    first=(v//(10**np.floor(np.log10(v)).astype(int))).astype(int)
    counts=np.bincount(first,minlength=10)[1:10];p=counts/len(v);expected=np.log10(1+1/np.arange(1,10))
    return float(np.abs(p-expected).mean()),p.tolist(),len(v)

def main():
    src=ROOT/json.loads((ROOT/'reports/biometry-history-computation-state.json').read_text())['output'];out=ROOT/'analysis/extensions/biometry-history-v1'/('simulation-'+str(time.time_ns()));out.mkdir()
    records=[]
    for year in [2014,2018,2022,2026]:
        d=pd.read_parquet(src/f'sections-{year}.parquet').query('round==2 and uf!="ZZ" and nominal_votes>0')
        total=d.groupby('municipality_key').nominal_votes.transform('sum')-d.nominal_votes
        pt=d.groupby('municipality_key').pt_votes.transform('sum')-d.pt_votes
        p=pt/total;keep=p.between(0,1)&total.gt(0);d=d[keep];p=p[keep].to_numpy();n=d.nominal_votes.to_numpy('int64')
        for rep in range(5):
            rng=np.random.default_rng(np.random.SeedSequence([20261031,year,rep]));v=rng.binomial(n,p)
            for candidate,z in [('PT',v),('opponent',n-v)]:
                mad,digits,count=summary(z)
                records.append({'year':year,'replicate':rep,'candidate_group':candidate,'n_positive':count,'MAD':mad,'unanimous':int((z==n).sum()),'above90':int((z/n>.9).sum()),'first_digit_fractions':json.dumps(digits)})
    d=pd.DataFrame(records);d.to_csv(out/'illustrative-digit-simulations.csv',index=False);d.to_parquet(out/'illustrative-digit-simulations.parquet',index=False)
    result={'at':now(),'output':str(out.relative_to(ROOT)),'seed':20261031,'replications_per_year':5,'code_sha256':sha(__file__),
        'interpretation':'Artificial model preserves observed section sizes and estimates homogeneous municipal preference leaving each section out. No manipulation operation is introduced. This does not establish that source preferences are untainted, that the null is realistic or that the election is fraud-free. Demonstrates limits of inferring fraud from first-digit mismatch; unanimity mismatch must be retained.'}
    save_json(out/'state.json',result);save_json(ROOT/'reports/biometry-digit-simulation-state.json',result)
    print(d.groupby(['year','candidate_group']).agg(min_MAD=('MAD','min'),max_MAD=('MAD','max'),min_unanimous=('unanimous','min'),max_unanimous=('unanimous','max')).to_string())

if __name__=='__main__':main()
