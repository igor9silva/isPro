import unittest
import numpy as np
import pandas as pd
from biometry_history_extension import weighted_corr,centered,cluster_ols


class StatisticalTests(unittest.TestCase):
    def test_weighted_correlation_equals_expanded_integer_sample(self):
        x=np.array([1.,2.,4.,9.]); y=np.array([8.,4.,5.,1.]); w=np.array([2,1,4,3])
        self.assertAlmostEqual(weighted_corr(x,y,w),np.corrcoef(np.repeat(x,w),np.repeat(y,w))[0,1],places=13)
        self.assertTrue(np.isnan(weighted_corr([1,1],[2,4])))

    def test_weighted_within_transformation_has_zero_group_means(self):
        x=np.array([[1,3],[5,9],[8,2],[4,3]],float);g=np.array(['a','a','b','b']);w=np.array([1,2,3,4])
        z=centered(x,g,w)
        for group in ['a','b']:
            np.testing.assert_allclose(np.average(z[g==group],weights=w[g==group],axis=0),0,atol=1e-13)

    def test_fixed_effect_coefficient_equals_explicit_dummy_regression(self):
        rng=np.random.default_rng(472);g=np.repeat(np.arange(12),20);x=rng.normal(size=(240,2));w=rng.uniform(.2,3,240)
        y=2*x[:,0]-.6*x[:,1]+g*.7+rng.normal(size=240)
        res=cluster_ols(y,x,g,w,True)
        full=np.column_stack([x,pd.get_dummies(g,dtype=float).to_numpy()]);sw=np.sqrt(w)
        beta=np.linalg.lstsq(full*sw[:,None],y*sw,rcond=None)[0]
        np.testing.assert_allclose(res['beta'],beta[:2],rtol=1e-12)

    def test_cluster_sandwich_matches_direct_reference(self):
        rng=np.random.default_rng(99);g=np.repeat(np.arange(20),15);x=np.column_stack([np.ones(300),rng.normal(size=300)])
        y=x@np.array([3.,.8])+np.repeat(rng.normal(size=20),15)+rng.normal(size=300)
        result=cluster_ols(y,x,g)
        bread=np.linalg.inv(x.T@x);beta=bread@x.T@y;u=y-x@beta
        scores=np.stack([x[g==i].T@u[g==i] for i in range(20)])
        cov=bread@scores.T@scores@bread*20/19*299/298
        np.testing.assert_allclose(result['se'],np.sqrt(np.diag(cov)),rtol=1e-12)

    def test_rate_correlation_is_not_correlation_of_counts(self):
        n=np.array([100,200,300,400.]);auth=n*.1;y=np.array([.2,.4,.6,.8])
        self.assertAlmostEqual(weighted_corr(auth,y),1)
        self.assertTrue(np.isnan(weighted_corr(auth/n,y)))


if __name__=='__main__':unittest.main()
