import unittest
import pandas as pd
from extract_biometry_profiles import aggregate_chunk,KEY

class ProfileTests(unittest.TestCase):
    def test_aggregation_identity_ignores_padding_and_order(self):
        from analyze_biometry_profile_controls import normalized_aggregation
        self.assertEqual(normalized_aggregation('0038, 0071'),normalized_aggregation('71,38'))
        self.assertEqual(normalized_aggregation('#NULO#'),'')
        self.assertIsNone(normalized_aggregation(None))
    def test_weights_age100_and_missing(self):
        d=pd.DataFrame({k:['AC']*4 if k=='SG_UF' else ['1']*4 for k in KEY})
        d['QT_ELEITORES']=['10','2','3','5'];d['QT_ELEITORES_BIOMETRIA']=['4','1','0','5']
        d['CD_FAIXA_ETARIA']=['6064','9999','-1','2024'];d['DS_FAIXA_ETARIA']=['60 a 64 anos','100 anos ou mais','NÃO INFORMADO','20 a 24 anos']
        d['CD_GRAU_ESCOLARIDADE']=['3','8','-1','2'];d['CD_GENERO']=['4','2','4','2']
        x=aggregate_chunk(d).iloc[0]
        self.assertEqual(x.registered,20);self.assertEqual(x.enrolled,10)
        self.assertEqual(x.age60plus,12);self.assertEqual(x.age_unknown,3)
        self.assertEqual(x.low_education,15);self.assertEqual(x.education_unknown,3);self.assertEqual(x.female,13)

if __name__=='__main__':unittest.main()
